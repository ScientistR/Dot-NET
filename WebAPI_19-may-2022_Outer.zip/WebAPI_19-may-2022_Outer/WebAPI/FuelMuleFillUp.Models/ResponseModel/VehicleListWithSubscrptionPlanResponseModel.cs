﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models.ResponseModel
{
    public class VehicleListWithSubscrptionPlanResponseModel
    {
        public int VehicleId { get; set; }
        public string LicencePlateNumber { get; set; }
        public string MakeName { get; set; }
        public string ModelName { get; set; }

        public List<PlansResponseModel> Plans { get; set; }
    }
}
