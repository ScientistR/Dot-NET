﻿using FuelMuleFillUp.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models.ResponseModel
{
    public class VehicleResponseModel : VehicleDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ProductName { get; set; }
        public string Products { get; set; }
        public string FlueType { get; set; }

        public string MobileNo { get; set; }
        public string Address { get; set; }
        public string NoOfVehicles { get; set; }





    }
    public class UpcommingCustomer : VehicleDto
    {

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int StatusId { get; set; }
        public string DeliveryStatus { get; set; }
        public DateTime DeliveryDate { get; set; }


    }
}
