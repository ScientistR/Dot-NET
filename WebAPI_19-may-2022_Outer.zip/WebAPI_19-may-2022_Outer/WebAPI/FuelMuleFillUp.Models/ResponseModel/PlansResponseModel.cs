﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models.ResponseModel
{
    public class PlansResponseModel
    {
        public int Id { get; set; }
        public string PlanName { get; set; }
        public decimal Amount { get; set; }
        public decimal Discount { get; set; }
        public int NoOfTransation { get; set; }
      
        public int NumberOfStops { get; set; }
        public int SubscriptionDays { get; set; }
        public bool IsPrimary { get; set; }
        public decimal PerStopAmount { get; set; }
        public string GasUsage { get; set; }
        public bool DiscountPlan { get; set; }
        public bool IsPlanSelected { get; set; }
        public bool IsVehicleSubscribed { get; set; }
        public DateTime? SubscribeDate { get; set; }
        public DateTime? RenewalDate { get; set; }
    }
}
