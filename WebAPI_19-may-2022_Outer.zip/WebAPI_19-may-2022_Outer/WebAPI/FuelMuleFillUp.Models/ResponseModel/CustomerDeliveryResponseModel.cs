﻿using System;

namespace FuelMuleFillUp.Models.ResponseModel
{
    public class CustomerDeliveryResponseModel
    {
        public int DeliveryId { get; set; }
        public string LicencePlateNumber { get; set; }
        public double? TankSize { get; set; }
        public int StatusId { get; set; }
        public string Status { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public int NumberOfVehicles { get; set; }
        public string MobileNumber { get; set; }
    }
}
