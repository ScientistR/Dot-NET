﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models.ResponseModel
{
    public class FaqResponseModel
    {
        public int FaqId { get; set; }
        public string Question { get; set; }
        public int Seq { get; set; }
        public int AnswerId { get; set; }
        public string Answer { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

    }
}
