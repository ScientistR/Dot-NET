﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models
{
  public class EmailSource
    {
        public string EmailTo { get; set; }
        public string UserName { get; set; }
    }
}
