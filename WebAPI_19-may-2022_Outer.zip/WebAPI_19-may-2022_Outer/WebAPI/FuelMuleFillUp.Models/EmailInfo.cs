﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models
{
   public class EmailInfo
    {

        public string EmailTo { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<Attachment> Attachments { get; set; }

    }
    //public class EmailSource
    //{
    //    public string EmailTo { get; set; }
    //    public string UserName { get; set; }
    //}
}
