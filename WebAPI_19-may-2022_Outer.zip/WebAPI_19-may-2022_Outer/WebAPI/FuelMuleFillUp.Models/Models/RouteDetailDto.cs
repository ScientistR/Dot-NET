﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class RouteDetailDto
    {
        public int Id { get; set; }
        public string RouteName { get; set; }
        public string DriverId { get; set; }
        public string SourceAddress { get; set; }
        public string DestinationAddress { get; set; }
        public string Days { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public int AssignedUsersCount { get; set; }
        public int UnassignedUsersCount { get; set; }
    }
}
