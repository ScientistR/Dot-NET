﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class VehicleDto
    {

        public int VehicleId { get; set; }
        public int AspNetUserId { get; set; }
        public string LicencePlateNumber { get; set; }
        public string Color { get; set; }
        public double? TankSize { get; set; }
        public string MakeName { get; set; }
        public string ModelName { get; set; }
        public string ParkingNumber { get; set; }
        public int ProductId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool IsDeleted { get; set; }
        public string BarCode { get; set; }
        public string ImageUrl { get; set; }
        public string GateCode { get; set; }
        public string OtherInstructions { get; set; }
        public string ProductName { get; set; }
        public string FuleType { get; set; }
    }
}




