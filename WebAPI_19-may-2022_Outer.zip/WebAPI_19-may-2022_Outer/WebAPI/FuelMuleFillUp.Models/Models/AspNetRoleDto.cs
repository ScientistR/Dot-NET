﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class AspNetRoleDto
    {
        public AspNetRoleDto()
        {
            AspNetRoleClaims = new HashSet<AspNetRoleClaimDto>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string NormalizedName { get; set; }
        public string ConcurrencyStamp { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

        public virtual ICollection<AspNetRoleClaimDto> AspNetRoleClaims { get; set; }
    }
}
