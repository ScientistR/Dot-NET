﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class TruckDto
    {
        public int TruckId { get; set; }
        public string LicencePlateNumber { get; set; }
        public string TruckColor { get; set; }
        public string MakeName { get; set; }
        public string TankSize { get; set; }
        public string ModelName { get; set; }
        public string VehicleNo { get; set; }
        public string VinNumber { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
