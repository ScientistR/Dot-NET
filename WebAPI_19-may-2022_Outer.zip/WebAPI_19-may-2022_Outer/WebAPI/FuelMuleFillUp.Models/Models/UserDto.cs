﻿using FuelMuleFillUp.Entities.Models;
using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class UserDto
    {
        public UserDto()
        {
            Vehicles = new List<VehicleDto>();
        }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int RoleId { get; set; }
        public int? RouteId { get; set; }
        public bool IsAssign { get; set; }
        public string ReferralCode { get; set; }
        public string PasswordHash { get; set; }
        public string MobileNo { get; set; }
        public string PhoneNumber { get; set; }
        public bool TwoFactorEnabled { get; set; }
        public string Address1 { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string OTP { get; set; }
        public DateTime? OTPCreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string LisenseNumber { get; set; }
        public string LicenseExpiryDate { get; set; }
        public string JoiningDate { get; set; }
        public string AuthorizeCustomerProfileId { get; set; }
        public int? ZipCode { get; set; }
        public string DeviceToken { get; set; }
        public bool? IsNotification { get; set; }
        public bool IsActive { get; set; }
        public bool? IsDeleted { get; set; }     
        public string RoleName { get; set; }
        public string AccessToken { get; set; }
        public int? SubscriptionId { get; set; }
        public List<VehicleDto> Vehicles { get; set; }
    }
    
}
