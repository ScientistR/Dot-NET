﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class UserTokenDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string DeviceId { get; set; }
        public string DeviceToken { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
    }
}
