﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Models.Models
{
    public partial class SubscriptionPlanDto
    {
        //public SubscriptionPlanDto()
        //{
        //    AssignSubscriptions = new HashSet<AssignSubscriptionDto>();
        //}

        public int Id { get; set; }
        public int? CustomerId { get; set; }
        public string PlanName { get; set; }
        public double Amount { get; set; }
        public int NoOfTransation { get; set; }
        public double Discount { get; set; }
        public bool DefaultPlan { get; set; }
        public int NumberOfStops { get; set; }
        public double PerStopAmount { get; set; }
        public int SubscriptionDays { get; set; }
        public string GasUsage { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool IsDeleted { get; set; } = false;
        public string CustomerName { get; set; }

        //public virtual ICollection<AssignSubscriptionDto> AssignSubscriptions { get; set; }
    }
}
