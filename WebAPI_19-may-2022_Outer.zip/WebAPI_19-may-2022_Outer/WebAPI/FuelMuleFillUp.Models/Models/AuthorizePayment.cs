﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Models.Models
{
    public class AuthorizePayment
    {
        public int customerId { get; set; }
        public string Email { get; set; }
        public string Address1 { get; set; }
        public string customerType { get; set; }
        public string city { get; set; }
        public string zip { get; set; }
        public string CardNumber { get; set; }
        public string State { get; set; }
        public string expirationDate { get; set; }
        public string CVV { get; set; }
        public bool IsDefoult { get; set; }
    }
    public class AddCustomerCardDetails
    {
        public int customerId { get; set; }
        public string cardNumber { get; set; }
        public string expirationDate { get; set; }
        public string cvv { get; set; }
        public bool defaultPaymentProfile { get; set; } = true;
        public string validationMode { get; set; }
    }
    public class AuthorizeGetCustomerProfileResponse
    {
        public List<CreditCard> creditCard { get; set; }
    }
    public class CreditCard
    {
        public string customerProfileId { get; set; }
        public string cardNumber { get; set; }
        public string expirationDate { get; set; }
        public string cardType { get; set; }
        public string issuerNumber { get; set; }
        public bool isDefault { get; set; }
    }

    public class PaymentCard
    {
        public CreditCard creditCard { get; set; }
    }

    public class PaymentProfile
    {
        public string customerPaymentProfileId { get; set; }
        public PaymentCard payment { get; set; }
        public string customerType { get; set; }
    }

    public class ShipToList
    {
        public string customerAddressId { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string zip { get; set; }
    }

    public class Profile
    {
        public List<PaymentProfile> paymentProfiles { get; set; }
        public List<ShipToList> shipToList { get; set; }
        public string profileType { get; set; }
        public string customerProfileId { get; set; }
        public string merchantCustomerId { get; set; }
        public string email { get; set; }
    }
    public class CustomerPayment
    {
        public string ProfileId { get; set; }
        public decimal Amount { get; set; }
        public int userId { get; set; }
        public int vehicleId { get; set; }
        public int? PlanId { get; set; }
        public string PaymentType { get; set; }
    }
    public class DeleteCustomerCard
    {
        public int UserID { get; set; }
        public string ProfileID { get; set; }
    }
    public class Message
    {
        public string code { get; set; }
        public string text { get; set; }
    }

    public class Messages
    {
        public string resultCode { get; set; }
        public List<Message> message { get; set; }
    }

}
