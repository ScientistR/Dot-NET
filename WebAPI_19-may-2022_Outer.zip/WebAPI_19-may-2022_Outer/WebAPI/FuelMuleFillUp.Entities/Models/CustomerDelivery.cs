﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class CustomerDelivery
    {
        public int Id { get; set; }
        public int VehicleId { get; set; }
        public int UserId { get; set; }
        public int StatusId { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool IsDeleted { get; set; }

        public virtual DeliveryStatus Status { get; set; }
        public virtual AspNetUser User { get; set; }
        public virtual Vehicle Vehicle { get; set; }
    }
}
