﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class OrderDetail
    {
        public int Id { get; set; }
        public int VehicleId { get; set; }
        public int UserId { get; set; }
        public string ModelName { get; set; }
        public int? ProductId { get; set; }
        public double FuelQuantity { get; set; }
        public double Amount { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public bool IsDelivered { get; set; }
        public bool IsPayment { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

        public virtual Vehicle Vehicle { get; set; }
    }
}
