﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class UserToken
    {
        public int Id { get; set; }
        public int AspNetUserId { get; set; }
        public string DeviceId { get; set; }
        public string DeviceToken { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

        public virtual AspNetUser AspNetUser { get; set; }
    }
}
