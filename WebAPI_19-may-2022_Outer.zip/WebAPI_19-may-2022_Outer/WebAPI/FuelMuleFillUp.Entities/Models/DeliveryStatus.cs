﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class DeliveryStatus
    {
        public DeliveryStatus()
        {
            CustomerDeliveries = new HashSet<CustomerDelivery>();
        }

        public int Id { get; set; }
        public string StatusName { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

        public virtual ICollection<CustomerDelivery> CustomerDeliveries { get; set; }
    }
}
