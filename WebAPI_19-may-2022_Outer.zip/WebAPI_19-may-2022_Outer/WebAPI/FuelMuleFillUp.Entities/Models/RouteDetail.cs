﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class RouteDetail
    {
        public RouteDetail()
        {
            AspNetUsers = new HashSet<AspNetUser>();
        }

        public int Id { get; set; }
        public string RouteName { get; set; }
        public string DriverId { get; set; }
        public string SourceAddress { get; set; }
        public string DestinationAddress { get; set; }
        public string Days { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool IsDeleted { get; set; }

        public virtual ICollection<AspNetUser> AspNetUsers { get; set; }
    }
}
