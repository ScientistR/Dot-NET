﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class PerStopAmount
    {
        public int Id { get; set; }
        public double StopAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
    }
}
