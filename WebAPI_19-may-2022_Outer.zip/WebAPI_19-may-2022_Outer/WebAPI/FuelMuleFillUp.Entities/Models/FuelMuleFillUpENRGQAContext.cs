﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class FuelMuleFillUpENRGQAContext : DbContext
    {
        public FuelMuleFillUpENRGQAContext()
        {
        }

        public FuelMuleFillUpENRGQAContext(DbContextOptions<FuelMuleFillUpENRGQAContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AspNetRole> AspNetRoles { get; set; }
        public virtual DbSet<AspNetRoleClaim> AspNetRoleClaims { get; set; }
        public virtual DbSet<AspNetUser> AspNetUsers { get; set; }
        public virtual DbSet<AspNetUserLogin> AspNetUserLogins { get; set; }
        public virtual DbSet<AspNetUserToken> AspNetUserTokens { get; set; }
        public virtual DbSet<AssignSubscription> AssignSubscriptions { get; set; }
        public virtual DbSet<CustomerDelivery> CustomerDeliveries { get; set; }
        public virtual DbSet<CustomerRoute> CustomerRoutes { get; set; }
        public virtual DbSet<DeliveryStatus> DeliveryStatuses { get; set; }
        public virtual DbSet<Faq> Faqs { get; set; }
        public virtual DbSet<FaqAnswer> FaqAnswers { get; set; }
        public virtual DbSet<OrderDetail> OrderDetails { get; set; }
        public virtual DbSet<Payment> Payments { get; set; }
        public virtual DbSet<PerStopAmount> PerStopAmounts { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<RouteDetail> RouteDetails { get; set; }
        public virtual DbSet<ScheduleStatus> ScheduleStatuses { get; set; }
        public virtual DbSet<State> States { get; set; }
        public virtual DbSet<SubscriptionPlan> SubscriptionPlans { get; set; }
        public virtual DbSet<Truck> Trucks { get; set; }
        public virtual DbSet<UserToken> UserTokens { get; set; }
        public virtual DbSet<Vehicle> Vehicles { get; set; }
        public virtual DbSet<ZipCode> ZipCodes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=dbprod\\sql2019;Initial Catalog=FuelMuleFillUp-ENRG-QA;Persist Security Info=True;User ID= FuelMuleFillUp-ENRG;Password=ASde@#32;Trusted_Connection=false;MultipleActiveResultSets=true;Connection Timeout=15;Connection Lifetime=0;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<AspNetRole>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ConcurrencyStamp).HasMaxLength(250);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.NormalizedName)
                    .IsRequired()
                    .HasMaxLength(256);
            });

            modelBuilder.Entity<AspNetRoleClaim>(entity =>
            {
                entity.HasIndex(e => e.RoleId, "IX_AspNetRoleClaims_RoleId");

                entity.Property(e => e.RoleId).IsRequired();
            });

            modelBuilder.Entity<AspNetUser>(entity =>
            {
                entity.Property(e => e.Address).HasMaxLength(200);

                entity.Property(e => e.Address1).HasMaxLength(200);

                entity.Property(e => e.AuthorizeCustomerProfileId).HasMaxLength(50);

                entity.Property(e => e.City).HasMaxLength(50);

                entity.Property(e => e.Country).HasMaxLength(50);

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeviceToken).IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsAssign).HasDefaultValueSql("((0))");

                entity.Property(e => e.JoiningDate).HasMaxLength(100);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Latitude).HasMaxLength(50);

                entity.Property(e => e.LicenseExpiryDate).HasMaxLength(100);

                entity.Property(e => e.LisenseNumber).HasMaxLength(100);

                entity.Property(e => e.Longitude).HasMaxLength(50);

                entity.Property(e => e.MobileNo).HasMaxLength(15);

                entity.Property(e => e.ModifyBy).HasDefaultValueSql("((0))");

                entity.Property(e => e.Otp)
                    .HasMaxLength(20)
                    .HasColumnName("OTP");

                entity.Property(e => e.OtpcreatedDate).HasColumnName("OTPCreatedDate");

                entity.Property(e => e.PasswordHash).HasMaxLength(500);

                entity.Property(e => e.PhoneNumber).HasMaxLength(15);

                entity.Property(e => e.ReferralCode)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.State)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TwoFactorEnabled).HasDefaultValueSql("((0))");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.AspNetUsers)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AspNetUsers_AspNetRoles");

                entity.HasOne(d => d.Route)
                    .WithMany(p => p.AspNetUsers)
                    .HasForeignKey(d => d.RouteId)
                    .HasConstraintName("FK_AspNetUsers_RouteDetails");
            });

            modelBuilder.Entity<AspNetUserLogin>(entity =>
            {
                entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });

                entity.HasIndex(e => e.UserId, "IX_AspNetUserLogins_UserId");
            });

            modelBuilder.Entity<AspNetUserToken>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });
            });

            modelBuilder.Entity<AssignSubscription>(entity =>
            {
                entity.ToTable("AssignSubscription");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SubscribeDate).HasColumnType("datetime");

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.AspNetUser)
                    .WithMany(p => p.AssignSubscriptions)
                    .HasForeignKey(d => d.AspNetUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssignSubscription_AspNetUsers");

                entity.HasOne(d => d.Plan)
                    .WithMany(p => p.AssignSubscriptions)
                    .HasForeignKey(d => d.PlanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssignSubscription_SubscriptionPlan");

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.AssignSubscriptions)
                    .HasForeignKey(d => d.VehicleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssignSubscription_Vehicles");
            });

            modelBuilder.Entity<CustomerDelivery>(entity =>
            {
                entity.ToTable("CustomerDelivery");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeliveryDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.CustomerDeliveries)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CustomerDelivery_DeliveryStatus");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.CustomerDeliveries)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CustomerDeliveryUserId_PKAspnetUserId");

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.CustomerDeliveries)
                    .HasForeignKey(d => d.VehicleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CustomerDelivery_Vehicle");
            });

            modelBuilder.Entity<CustomerRoute>(entity =>
            {
                entity.ToTable("CustomerRoute");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Days).HasMaxLength(50);

                entity.Property(e => e.DriverId).HasMaxLength(450);
            });

            modelBuilder.Entity<DeliveryStatus>(entity =>
            {
                entity.ToTable("DeliveryStatus");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifyBy).HasMaxLength(100);

                entity.Property(e => e.StatusName)
                    .IsRequired()
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<Faq>(entity =>
            {
                entity.ToTable("FAQs");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifyBy).HasDefaultValueSql("((0))");

                entity.Property(e => e.ModifyDate).HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<FaqAnswer>(entity =>
            {
                entity.HasKey(e => e.AnswerId);

                entity.ToTable("FaqAnswer");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Faq)
                    .WithMany(p => p.FaqAnswers)
                    .HasForeignKey(d => d.FaqId)
                    .HasConstraintName("FK_FaqAnswer_FaqAnswer");
            });

            modelBuilder.Entity<OrderDetail>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeliveryDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModelName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.VehicleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OrderDetails_Vehicles");
            });

            modelBuilder.Entity<Payment>(entity =>
            {
                entity.ToTable("Payment");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PaymentType)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionId).HasMaxLength(100);

                entity.HasOne(d => d.AspNetUser)
                    .WithMany(p => p.Payments)
                    .HasForeignKey(d => d.AspNetUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Payment_AspNetUsers");

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.Payments)
                    .HasForeignKey(d => d.VehicleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Payment_Vehicle");
            });

            modelBuilder.Entity<PerStopAmount>(entity =>
            {
                entity.ToTable("PerStopAmount");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Product");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FuelType)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(e => e.ProductName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.Products)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_AspNetUser");
            });

            modelBuilder.Entity<RouteDetail>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Days)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.DestinationAddress).HasMaxLength(50);

                entity.Property(e => e.DriverId).HasMaxLength(450);

                entity.Property(e => e.RouteName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.SourceAddress).HasMaxLength(50);
            });

            modelBuilder.Entity<ScheduleStatus>(entity =>
            {
                entity.ToTable("ScheduleStatus");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.StatusName)
                    .IsRequired()
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.StateAbbreviation)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.StateName)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SubscriptionPlan>(entity =>
            {
                entity.ToTable("SubscriptionPlan");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DefaultPlan)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.GasUsage)
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.Property(e => e.PlanName)
                    .IsRequired()
                    .HasMaxLength(70)
                    .IsUnicode(false);

                entity.HasOne(d => d.Customer)
                    .WithMany(p => p.SubscriptionPlans)
                    .HasForeignKey(d => d.CustomerId)
                    .HasConstraintName("FK_SubscriptionPlan_AspNetUsers");
            });

            modelBuilder.Entity<Truck>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LicencePlateNumber).HasMaxLength(100);

                entity.Property(e => e.MakeName).HasMaxLength(50);

                entity.Property(e => e.ModelName).HasMaxLength(50);

                entity.Property(e => e.TankSize).HasMaxLength(50);

                entity.Property(e => e.TruckColor).HasMaxLength(50);

                entity.Property(e => e.VehicleNo).HasMaxLength(50);

                entity.Property(e => e.VinNumber).HasMaxLength(100);
            });

            modelBuilder.Entity<UserToken>(entity =>
            {
                entity.ToTable("UserToken");

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeviceId)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.DeviceToken)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.HasOne(d => d.AspNetUser)
                    .WithMany(p => p.UserTokens)
                    .HasForeignKey(d => d.AspNetUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserToken_AspNetUsers");
            });

            modelBuilder.Entity<Vehicle>(entity =>
            {
                entity.Property(e => e.BarCode)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Color).HasMaxLength(20);

                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.GateCode)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ImageUrl)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LicencePlateNumber)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.MakeName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ModelName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.OtherInstructions).IsUnicode(false);

                entity.Property(e => e.ParkingNumber).HasMaxLength(50);

                entity.HasOne(d => d.AspNetUser)
                    .WithMany(p => p.Vehicles)
                    .HasForeignKey(d => d.AspNetUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Vehicles_AspNetUser");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.Vehicles)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Vehicles_Product");
            });

            modelBuilder.Entity<ZipCode>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Zip)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
