﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class CustomerRoute
    {
        public int Id { get; set; }
        public string DriverId { get; set; }
        public int RouteId { get; set; }
        public int CustomerId { get; set; }
        public string Days { get; set; }
        public bool IsAssign { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
    }
}
