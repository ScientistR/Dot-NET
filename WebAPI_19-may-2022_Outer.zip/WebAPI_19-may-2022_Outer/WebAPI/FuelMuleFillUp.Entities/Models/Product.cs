﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class Product
    {
        public Product()
        {
            Vehicles = new HashSet<Vehicle>();
        }

        public int Id { get; set; }
        public string FuelType { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool IsDeleted { get; set; }

        public virtual AspNetUser CreatedByNavigation { get; set; }
        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}
