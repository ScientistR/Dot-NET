﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class AspNetUser
    {
        public AspNetUser()
        {
            AssignSubscriptions = new HashSet<AssignSubscription>();
            CustomerDeliveries = new HashSet<CustomerDelivery>();
            Payments = new HashSet<Payment>();
            Products = new HashSet<Product>();
            SubscriptionPlans = new HashSet<SubscriptionPlan>();
            UserTokens = new HashSet<UserToken>();
            Vehicles = new HashSet<Vehicle>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int RoleId { get; set; }
        public int? RouteId { get; set; }
        public bool? IsAssign { get; set; }
        public string ReferralCode { get; set; }
        public string PasswordHash { get; set; }
        public string MobileNo { get; set; }
        public string PhoneNumber { get; set; }
        public bool? TwoFactorEnabled { get; set; }
        public string Address1 { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Otp { get; set; }
        public DateTime? OtpcreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string LisenseNumber { get; set; }
        public string LicenseExpiryDate { get; set; }
        public string JoiningDate { get; set; }
        public string AuthorizeCustomerProfileId { get; set; }
        public int? ZipCode { get; set; }
        public string DeviceToken { get; set; }
        public bool IsNotification { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDeleted { get; set; }

        public virtual AspNetRole Role { get; set; }
        public virtual RouteDetail Route { get; set; }
        public virtual ICollection<AssignSubscription> AssignSubscriptions { get; set; }
        public virtual ICollection<CustomerDelivery> CustomerDeliveries { get; set; }
        public virtual ICollection<Payment> Payments { get; set; }
        public virtual ICollection<Product> Products { get; set; }
        public virtual ICollection<SubscriptionPlan> SubscriptionPlans { get; set; }
        public virtual ICollection<UserToken> UserTokens { get; set; }
        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}
