﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class AssignSubscription
    {
        public int Id { get; set; }
        public int AspNetUserId { get; set; }
        public int PlanId { get; set; }
        public int VehicleId { get; set; }
        public DateTime? SubscribeDate { get; set; }
        public DateTime? RenewalDate { get; set; }
        public double SubscribeAmount { get; set; }
        public string Type { get; set; }
        public bool IsPrimary { get; set; }
        public bool CancelPlan { get; set; }
        public bool IsPlanSelected { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

        public virtual AspNetUser AspNetUser { get; set; }
        public virtual SubscriptionPlan Plan { get; set; }
        public virtual Vehicle Vehicle { get; set; }
    }
}
