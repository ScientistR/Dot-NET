﻿using System;
using System.Collections.Generic;

#nullable disable

namespace FuelMuleFillUp.Entities.Models
{
    public partial class Payment
    {
        public int Id { get; set; }
        public int VehicleId { get; set; }
        public int AspNetUserId { get; set; }
        public string TransactionId { get; set; }
        public double Amount { get; set; }
        public string PaymentType { get; set; }
        public bool IsTransactionComplete { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public int? ModifyBy { get; set; }
        public DateTime? ModifyDate { get; set; }

        public virtual AspNetUser AspNetUser { get; set; }
        public virtual Vehicle Vehicle { get; set; }
    }
}
