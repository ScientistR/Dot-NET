﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.ViewModel.ViewModels
{
   public class VehiclesVM
    {
        [Key]
        public int VehicleId { get; set; }
        public Guid UserId { get; set; }
        // public string SerialNumber { get; set; }
        public string LicencePlateNumber { get; set; }
        public string Color { get; set; }
        public string MakeName { get; set; }
        public string TankSize { get; set; }
        public string ModelName { get; set; }
        public string ParkingNumber { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.Now;
        public string ModifyBy { get; set; }
        public DateTime? ModifyOn { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsDeleted { get; set; } = false;
    }
}
