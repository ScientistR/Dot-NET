﻿//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Models.ResponseModel;
//using FuelMuleFillUp.Utilities;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Logging;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Security.Claims;
//using System.Text;
//using System.Threading.Tasks;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class Driver : IDriver
//    {
//        private readonly FuelMuleFillUpContext _dbContext;
//        private readonly ILogger<Driver> _logger;
//        private readonly UserManager<ApplicationUser> _userManager;

//        public Driver(FuelMuleFillUpContext dbContext, UserManager<ApplicationUser> userManager, ILogger<Driver> logger) 
//        {
//            _dbContext = dbContext;
//            _userManager = userManager;
//             _logger = logger;
//        }

//        /// <summary>
//        /// DriverRegistrationUpdate
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> DriverRegistrationUpdate(DriverRegistrationModel model)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                // var roleDetails = _dbContext.Roles.Where(res => res.Id == "08a7bfa9-cddf-412b-8b08-2456bc3fe08d").FirstOrDefault();

//                if (string.IsNullOrEmpty(model.Id))
//                {
//                    var userExists = _userManager.FindByEmailAsync(model.UserName).Result;
//                    if (userExists != null)
//                    {
//                        response.Data = null;
//                        response.Message = TKMessages.Alreadyexists;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    }
//                    else
//                    {
//                        ApplicationUser user = new()
//                        {
//                            SecurityStamp = Guid.NewGuid().ToString(),
//                            UserName = model.UserName.ToLower().Trim(),
//                            PasswordHash = model.Password,
//                            FirstName = model.FirstName.Trim(),
//                            LastName = model.LastName.Trim(),
//                            MobileNo = model.MobileNo.Trim(),
//                            LicenseExpiryDate = model.LicenseExpiryDate,
//                            LisenseNumber = model.LisenseNumber,
//                            Address = model.Address.Trim(),
//                            JoiningDate = model.JoiningDate,
//                            // JoiningDate=DateTime.UtcNow,
//                            Status = model.Status.Trim(),
//                            CreateDate = DateTime.UtcNow,
//                            Email = model.UserName.ToLower().Trim(),
//                            Role = model.Role.Trim()
//                        };
//                        var result = await _userManager.CreateAsync(user, model.Password).ConfigureAwait(false);
//                        if (result.Succeeded)
//                        {
//                            response.Data = null;
//                            response.Message = TKMessages.Addemployee;
//                            response.StatusCode = (int)HttpStatusCode.OK;
//                        }
//                        else
//                        {
//                            response.Data = null;
//                            response.Message = TKMessages.invalid;
//                            response.StatusCode = (int)HttpStatusCode.BadRequest;
//                        }
//                    }
//                }
//                else
//                {
//                    var driverDetails = _userManager.FindByIdAsync(model.Id).Result;
//                    driverDetails.UserName = model.UserName.Trim();
//                   // driverDetails.PasswordHash = model.Password.Trim();
//                    driverDetails.FirstName = model.FirstName.Trim();
//                    driverDetails.LastName = model.LastName.Trim();
//                    driverDetails.MobileNo = model.MobileNo.Trim();
//                    driverDetails.Address = model.Address.Trim();
//                    driverDetails.Status = model.Status.Trim();
//                    driverDetails.LicenseExpiryDate = model.LicenseExpiryDate;
//                    driverDetails.LisenseNumber = model.LisenseNumber;
//                    driverDetails.ModifyDate = DateTime.UtcNow;
//                    _dbContext.Users.Update(driverDetails);
//                    var res = _dbContext.SaveChanges();
//                    if (res > 0)
//                    {
//                        response.Data = null;
//                        response.Message = TKMessages.Employeeupdate;
//                        response.StatusCode = (int)HttpStatusCode.OK;
//                    }
//                    else
//                    {
//                        response.Data = null;
//                        response.Message = TKMessages.invalid;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//            }
//            return response;
//        }

//     //   public async Task<CommonResponseModel> GetEmployeeList()
//     //   {
//     //       CommonResponseModel response = new();
//     //       try
//     //       {
//     //           var uses = from a in (from ur in _dbContext.Users
//     //                                 join r in _dbContext.Roles on ur.Role equals r.Id
//     //                                 where Convert.ToString(r.Name).ToLower() != Convert.ToString("customer").ToLower()
//     //                                 select new User()
//     //                                 {
//     //                                     Id = r.Id,
//     //                                     FirstName = ur.FirstName,
//     //                                     LastName = ur.LastName,
//     //                                     Role = ur.Role,
//     //                                     MobileNo = ur.MobileNo,
//     //                                     LisenseNumber = ur.LisenseNumber,
//     //                                     Email = ur.Email,
//     //                                     Status = ur.State,
//     //                                     JoiningDate = ur.JoiningDate,
//     //                                     Address = ur.Address,
//     //                                 }).ToList()
//     //                      select a;
//     //           response.Data = uses;
//     //           response.StatusCode = (int)(HttpStatusCode.OK);
//     //           response.Message = TKMessages.Faqs;
//     //       }
//     //       catch (Exception ex)
//     //       {
//     //           _logger.LogError(ex.Message);
//     //           response.Data = null;
//     //           response.Message = TKMessages.CommonFailed;
//     //           response.StatusCode = (int)HttpStatusCode.InternalServerError;
//     //       }
//     //       return response;
//     //   }
//     //
//        /// <summary>
//        /// ListOfEmployee
//        /// </summary>
//        /// <returns></returns>
        
//        public async Task<CommonResponseModel> ListOfEmployee()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var uses = from a in (from ur in _dbContext.Users
//                                      join r in _dbContext.Roles on ur.Role equals r.Id
//                                      where Convert.ToString(r.Name).ToLower() != Convert.ToString("customer").ToLower()
//                                      select new DriverListForDropdownResponse()
//                                      {
//                                          Id = ur.Id,
//                                          FirstName = ur.FirstName,
//                                          LastName = ur.LastName,
//                                          Role = ur.Role,
//                                          Name=r.Name,
//                                          MobileNo = ur.MobileNo,
//                                          LisenseNumber = ur.LisenseNumber,
//                                          Email = ur.Email,
//                                          Status = ur.State,
//                                          JoiningDate = ur.JoiningDate,
//                                          Address = ur.Address,
//                                      }).ToList()
//                           select a;
           
//                response.Data = uses;
//                response.StatusCode = (int)(HttpStatusCode.OK);
//                response.Message = TKMessages.Faqs;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
           
            
            
//            return response;

//        }

//        /// <summary>
//        /// DeleteEmployeeDetails
//        /// </summary>
//        /// <param name="EmployeeId"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> DeleteEmployeeDetails(string EmployeeId)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                if (EmployeeId !=null)
//                {
//                    var employeeDeatils = await _dbContext.Users.Where(t => t.Id ==EmployeeId && t.IsDeleted==false).FirstOrDefaultAsync().ConfigureAwait(true);//&& t.IsDeleted == false
//                    if (employeeDeatils != null)
//                    {
//                         employeeDeatils.IsDeleted = true;
//                        _dbContext.Update(employeeDeatils);
//                        var result = _dbContext.SaveChanges();
//                        if (result > 0)
//                        {
//                            response.Data = null;
//                            response.StatusCode = (int)HttpStatusCode.OK;
//                            response.Message = TKMessages.employeeDelete;
//                        }
//                        else
//                        {
//                            response.Data = null;
//                            response.StatusCode = (int)HttpStatusCode.BadRequest;
//                            response.Message = TKMessages.CommonFailed;
//                        }
//                    }
//                    else
//                    {
//                        response.Data = null;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                        response.Message = TKMessages.employeedeleted;
//                    }
//                }
//                else
//                {
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    response.Message = TKMessages.CommonFailed;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        /// <summary>
//        /// VehicleDetailsByPlatNo
//        /// </summary>
//        /// <param name="LicencePlateNumber"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> VehicleDetailsByPlatNo(string LicencePlateNumber)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                if (LicencePlateNumber != null)
//                {
//                    var employeeDeatils = await _dbContext.Vehicles.Where(t => t.LicencePlateNumber == LicencePlateNumber && t.IsDeleted == false).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (employeeDeatils != null)
//                    {
//                        var LicenceDetails = await (from p in _dbContext.Vehicles
//                                                    join u in _dbContext.Users on p.UserId.ToString() equals u.Id
//                                                    join vc in _dbContext.Product on p.ProductId equals vc.Id
//                                                    where p.LicencePlateNumber==LicencePlateNumber && p.IsDeleted==false
//                                                    select new VehicleDetailsByLicenceNo
//                                                    {
//                                                        UserId= Convert.ToString(p.UserId),
//                                                        VehicleId=p.VehicleId,
//                                                        LicencePlateNumber = p.LicencePlateNumber,
//                                                        Color = p.Color,
//                                                        BarCode=p.BarCode,
//                                                        MakeName = p.MakeName,
//                                                        ModelName = p.ModelName,
//                                                        FirstName=u.FirstName,
//                                                        LastName=u.LastName,
//                                                        ProductName=vc.ProductName,
//                                                        FuelType = vc.FuelType,
//                                                        Id=vc.Id,
//                                                    }).FirstOrDefaultAsync().ConfigureAwait(true);
//                        response.Data = LicenceDetails;
//                        response.StatusCode = (int)HttpStatusCode.OK;
//                        response.Message = TKMessages.vehiclelicence;
//                    }
//                }
//          //  }
//                else
//                {
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                    response.Message = TKMessages.employeeDelete;
//                }
//           }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        /// <summary>
//        /// GetVehicleDetailsByScanBarCode
//        /// </summary>
//        /// <param name="BarCode"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> GetVehicleDetailsByScanBarCode(string BarCode)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                    var GetBarCodeDetails = await _dbContext.Vehicles.Where(t => t.BarCode == BarCode && t.IsDeleted == false).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (GetBarCodeDetails != null)
//                    {
//                        var BarCodeDetails = await (from p in _dbContext.Vehicles
//                                                     join u in _dbContext.Users on p.UserId.ToString() equals u.Id
//                                                     join vc in _dbContext.Product on p.ProductId equals vc.Id
//                                                     where p.BarCode == BarCode && p.IsDeleted == false
//                                                     select new VehicleDetailsByLicenceNo
//                                                     {
//                                                         UserId = Convert.ToString(p.UserId),
//                                                         VehicleId = p.VehicleId,
//                                                         LicencePlateNumber = p.LicencePlateNumber,
//                                                         Color = p.Color,
//                                                         MakeName = p.MakeName,
//                                                         ModelName = p.ModelName,
//                                                         FirstName = u.FirstName,
//                                                         LastName = u.LastName,
//                                                         BarCode=p.BarCode,
//                                                         ProductName = vc.ProductName,
//                                                         FuelType = vc.FuelType,
//                                                         Id = vc.Id,
//                                                     }).FirstOrDefaultAsync().ConfigureAwait(true);
//                        response.Data = BarCodeDetails;
//                        response.StatusCode = (int)HttpStatusCode.OK;
//                        response.Message = TKMessages.msgbarcode;
//                    }
//                else
//                {
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                    response.Message = TKMessages.CommonFailed;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }

//        public async Task<CommonResponseModel> GetCustomerVehicleDetailsById(int vehicleId)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var VehicleDetails = (from p in _dbContext.Vehicles
//                                      join pd in _dbContext.Product on p.ProductId equals pd.Id
//                                      // orderby p.BarCode ascending
//                                      where p.VehicleId == vehicleId && !p.IsDeleted
//                                      select new GetCustomerVehicleDetailsByIdResponseModel
//                                      {
//                                          LicencePlateNumber = p.LicencePlateNumber,
//                                          MakeName = p.MakeName,
//                                          ModelName = p.ModelName,
//                                          Color = p.Color,
//                                          ParkingNumber = p.ParkingNumber,
//                                          TankSize = p.TankSize,
                                        
//                                           VehicleId = p.VehicleId,
//                                          FuelType = pd.FuelType,
//                                          ProductName = pd.ProductName
//                                      }).FirstOrDefault();
//                    response.Data = VehicleDetails;
//                    response.Message = "Get Vehicle Details";
//                    response.StatusCode = (int)HttpStatusCode.OK;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }

//        public async Task<CommonResponseModel> VehicleDetailsByPlatNoAndBarcode(string PlatOrBarCode)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                //if (LicencePlateNumber != null)
//                //{
//                    var employeeDeatils = await _dbContext.Vehicles.Where(t => t.LicencePlateNumber == PlatOrBarCode || t.BarCode == PlatOrBarCode && t.IsDeleted == false).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (employeeDeatils != null)
//                    {
//                        var LicenceDetails = await(from p in _dbContext.Vehicles
//                                                   join u in _dbContext.Users on p.UserId.ToString() equals u.Id
//                                                   join vc in _dbContext.Product on p.ProductId equals vc.Id
//                                                   where p.LicencePlateNumber == PlatOrBarCode || p.BarCode== PlatOrBarCode && !p.IsDeleted

//                                                   //t.LicencePlateNumber == LicencePlateNumber || t.BarCode==Barcode &&

//                                                   select new VehicleDetailsByLicenceNo
//                                                   {
//                                                       UserId = Convert.ToString(p.UserId),
//                                                       VehicleId = p.VehicleId,
//                                                       LicencePlateNumber = p.LicencePlateNumber,
//                                                       Color = p.Color,
//                                                       MakeName = p.MakeName,
//                                                       ModelName = p.ModelName,
//                                                       FirstName = u.FirstName,
//                                                       LastName = u.LastName,
//                                                       ProductName = vc.ProductName,
//                                                       FuelType = vc.FuelType,
//                                                       Id = vc.Id,
//                                                   }).FirstOrDefaultAsync().ConfigureAwait(true);
//                        response.Data = LicenceDetails;
//                        response.StatusCode = (int)HttpStatusCode.OK;
//                        response.Message = TKMessages.vehiclelicence;
//                    }
//                //}
//                //  }
//                else
//                {
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                    response.Message = TKMessages.employeeDelete;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//    }
//    public class Datass
//    {
//        public string Id { get; set; }
//    }
//}


