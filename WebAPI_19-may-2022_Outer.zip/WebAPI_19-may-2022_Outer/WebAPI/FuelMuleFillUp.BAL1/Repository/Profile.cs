﻿//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Models;
////using FuelMuleFillUp.Models.RequestModel;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class Profile : IProfile
//    {
//        public Task<APIResponseModel> ProfileDetails(CustomerVehicleDeatils customerVehicle)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
