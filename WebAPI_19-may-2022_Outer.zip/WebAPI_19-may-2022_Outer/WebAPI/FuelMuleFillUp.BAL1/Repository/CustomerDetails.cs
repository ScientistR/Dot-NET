﻿using Microsoft.Extensions.Configuration;
using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Entities.DBTables;
using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
using FuelMuleFillUp.Utilities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
//using FuelMuleFillUp.Models.ResponseModel;
//using FuelMuleFillUp.ViewModel.ViewModels;
using FuelMuleFillUp.DAL.IDAL;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;
//using FuelMuleFillUp.Entities.Stored_Procedule;
using Microsoft.Data.SqlClient;



namespace FuelMuleFillUp.BAL.Repository
{
    //public class CustomerDetails : ICustomerDetails
    //{

    //    private readonly FuelMuleFillUpContext _dbContext;
    //    private readonly IGenericDAL<tblOrders> _genericDAL;
    //    private readonly IGenericDAL<Vehicles> _genericVehiclesDAL;
    //    private readonly IGenericDAL<Assignsubscription> _genericSubscriptionDAL;
    //    private readonly IGenericDAL<CustomerDelivery> _genericCustomerDeliveryDAL;
    //    private readonly IGenericDAL<Order> _genericCustomerOrdersDAL;
    //    private readonly ILogger<CustomerDetails> _logger;
    //    private readonly IConfiguration _config;

    //    public object Id { get; private set; }

    //    //private readonly IEmailService _mailService;

    //    public CustomerDetails(FuelMuleFillUpContext dbContext, IGenericDAL<Order> genericCustomerOrdersDAL, IGenericDAL<CustomerDelivery> genericCustomerDeliveryDAL, IGenericDAL<Assignsubscription> genericSubscriptionDAL, IConfiguration config, ILogger<CustomerDetails> logger, IGenericDAL<Vehicles> genericVehiclesDAL, IGenericDAL<tblOrders> genericDAL) //, , IConfiguration config, UserManager<ApplicationUser> userManager
    //    {
    //        _dbContext = dbContext;
    //        _genericDAL = genericDAL;
    //        _genericVehiclesDAL = genericVehiclesDAL;
    //        _genericCustomerDeliveryDAL = genericCustomerDeliveryDAL;
    //        _genericSubscriptionDAL = genericSubscriptionDAL;
    //        _genericCustomerOrdersDAL = genericCustomerOrdersDAL;
    //        _logger = logger;
    //        _config = config;
    //    }

    //    /// <summary>
    //    /// AddOrderForCustomer
    //    /// </summary>
    //    /// <param name="orderModel"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> AddOrderForCustomer(OrderModel orderModel)
    //    {
    //        var responseResult = new CommonResponseModel();
    //        try
    //        {
    //            var tblOrder = Mapper.MapData<OrderModel, tblOrders>(orderModel);
    //            var result = await _genericDAL.Save(tblOrder);
    //            if (result)
    //            {
    //                responseResult.Data = tblOrder;
    //                responseResult.StatusCode = (int)HttpStatusCode.OK;
    //                responseResult.Message = TKMessages.addorder;
    //            }
    //            else
    //            {
    //                responseResult.Data = null;
    //                responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
    //                responseResult.Message = TKMessages.rejectorder;
    //            }
    //        }
    //        catch (Exception ex)
    //        {

    //            _logger.LogError(ex.Message);
    //            responseResult.Data = null;
    //            responseResult.Message = TKMessages.CommonFailed;
    //            responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }

    //        return responseResult;
    //    }

    //    /// <summary>
    //    /// CustomerDeatilsId
    //    /// </summary>
    //    /// <param name="customerDeatilsModel"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> CustomerDeatilsId(string CustomerId)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (CustomerId != null)
    //            {
    //                var CustomerDeatils = await _dbContext.Users.Where(t => t.Id == CustomerId).FirstOrDefaultAsync().ConfigureAwait(true);
    //                var UserDeatils = new CustomerResponseByIdModel();
    //                UserDeatils.id = CustomerDeatils.Id;
    //                UserDeatils.UserName = CustomerDeatils.UserName;
    //                UserDeatils.FirstName = CustomerDeatils.FirstName;
    //                UserDeatils.LastName = CustomerDeatils.LastName;
    //                UserDeatils.MobileNo = CustomerDeatils.PhoneNumber;
    //                UserDeatils.Address = CustomerDeatils.Address;
    //                UserDeatils.City = CustomerDeatils.City;
    //                UserDeatils.Country = CustomerDeatils.Country;
    //                UserDeatils.CreatedDate = CustomerDeatils.CreateDate;
    //                response.Data = UserDeatils;
    //                response.Message = TKMessages.customerdetails;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.InvalidId;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    /// <summary>
    //    /// CustomerAddVehicles
    //    /// </summary>
    //    /// <param name="customerVehicle"></param>
    //    /// <returns></returns>
    //    /// 
    //    public async Task<CommonResponseModel> AddVehicles(VehicleModel vehicles)
    //    {
    //        var responseResult = new CommonResponseModel();
    //        try
    //        {

    //            var Vehicle = Mapper.MapData<VehicleModel, Vehicles>(vehicles);
    //            //if (_dbContext.Vehicles.Any(vc => vc.IsPrimary && vc.UserId==vehicles.UserId))
    //            //{
    //            //    vehicles.IsPrimary = false;
    //            //}
    //            //else
    //            //{
    //            //    vehicles.IsPrimary = true;
    //            //}
    //            var result = await _genericVehiclesDAL.Save(Vehicle);
    //            if (result)
    //            {
    //                responseResult.Data = Vehicle;
    //                responseResult.StatusCode = (int)HttpStatusCode.OK;
    //                responseResult.Message = TKMessages.AddVehicles;
    //            }
    //            else
    //            {
    //                responseResult.Data = null;
    //                responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
    //                responseResult.Message = TKMessages.CommonFailed;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            responseResult.Data = null;
    //            responseResult.Message = TKMessages.CommonFailed;
    //            responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }

    //        return responseResult;
    //    }
    //    /// <summary>
    //    /// CustomerVehiclesId
    //    /// </summary>
    //    /// <param name="CustomerId"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> CustomerVehiclesId(Guid? CustomerId)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (CustomerId != null)
    //            {
    //                response.Data = (from a in _dbContext.Vehicles
    //                                 join b in _dbContext.Product on a.ProductId equals b.Id
    //                                 where CustomerId == a.UserId && a.IsDeleted == false
    //                                 select new CustomerVehiclesDeatilsResponse
    //                                 {
    //                                     LicencePlateNumber = a.LicencePlateNumber,
    //                                     MakeName = a.MakeName,
    //                                     ModelName = a.ModelName,
    //                                     Color = a.Color,
    //                                     ProductId = a.ProductId,
    //                                     Id = a.VehicleId,
    //                                     TankSize = a.TankSize,
    //                                     ParkingNumber = a.ParkingNumber,
    //                                     FuelType = b.FuelType,
    //                                     ProductName = b.ProductName
    //                                 }).Distinct().ToList();
    //                response.Message = TKMessages.GetById;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.InvalidId;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// DeleteCustomerVehicles
    //    /// </summary>
    //    /// <param name="CustomerId"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> DeleteCustomerVehicles(int vehicleId)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (vehicleId > 0)
    //            {
    //                var CustomerDeatils = await _dbContext.Vehicles.Where(t => t.VehicleId == vehicleId && t.IsDeleted == false).FirstOrDefaultAsync().ConfigureAwait(true);
    //                if (CustomerDeatils != null)
    //                {
    //                    CustomerDeatils.IsDeleted = true;
    //                    _dbContext.Update(CustomerDeatils);
    //                    var result = _dbContext.SaveChanges();
    //                    if (result > 0)
    //                    {
    //                        response.Data = CustomerDeatils;
    //                        response.StatusCode = (int)HttpStatusCode.OK;
    //                        response.Message = TKMessages.Delete;
    //                    }
    //                    else
    //                    {
    //                        response.Data = null;
    //                        response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                        response.Message = TKMessages.CommonFailed;
    //                    }
    //                }
    //                else
    //                {
    //                    response.Data = null;
    //                    response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                    response.Message = TKMessages.VehicleDeleted;
    //                }
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                response.Message = TKMessages.CommonFailed;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    /// <summary>
    //    /// Method for get CustomerDelivery
    //    /// </summary>
    //    /// <param name="UserId"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> CustomerDelivery(Guid? userId)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (userId != null)
    //            {
    //                var data = (from cd in _dbContext.CustomerDelivery
    //                                //join cr in _dbContext.CustomerRoute on cd.CustomerRouteId equals cr.Id
    //                                //join r in _dbContext.RouteDetails on cr.RouteId equals r.Id
    //                                //join cr in _dbContext.CustomerRoute on cd.CreatedBy equals cr.CustomerId
    //                                //join c in _dbContext.Users on cr.CustomerId equals c.Id
    //                            join ds in _dbContext.DeliveryStatus on cd.StatusId equals ds.Id
    //                            join ss in _dbContext.ScheduleStatus on cd.IsAccepted equals ss.Id
    //                            join cv in _dbContext.Vehicles on cd.VehicleId equals cv.VehicleId
    //                            // join od in _dbContext.Order on cv.UserId.ToString() equals od.UserId
    //                            where !cv.IsDeleted && !cd.IsDeleted && cv.UserId == userId
    //                            orderby cd.Id
    //                            select new DeliveryRM()
    //                            {
    //                                UserId = cv.UserId,
    //                                DeliveryId = cd.Id,
    //                                LicencePlateNumber = cv.LicencePlateNumber,
    //                                TankSize = cv.TankSize,
    //                                VehicleId = cd.VehicleId,
    //                                DeliveryDate = cd.DeliveryDate,
    //                                Day = cd.CreatedDate.ToString("dddd"),
    //                                Status = ds.StatusName,
    //                                IsPastDelivery = cd.StatusId == 3,
    //                                IsAccepted = cd.IsAccepted,
    //                                IsAcceptedName = ss.StatusName
    //                                //ProductName = od.ProductName,
    //                                //ProductType = od.ProductType,
    //                                //FuelUse=od.FuelQuantity,
    //                                //Amount = od.Amount,
    //                                //.OrderByDescending(x=>x.DeliveryDate).Take(5);
    //                            }).Distinct().ToList();
    //                //  var res = data.Distinct().ToList();
    //                //.GroupBy(res => new { res.UserId, res.IsPastDelivery, res.IsAccepted, res.IsAcceptedName, res.LicencePlateNumber, res.FuleQty, res.DeliveryDate, res.Day, res.Status }).ToList();
    //                response.Data = data;
    //                response.Message = TKMessages.Delivery;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.CommonFailed;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// AcceptCustomerDelivery
    //    /// </summary>
    //    /// <param name="model"></param>
    //    /// <returns></returns>

    //    public async Task<CommonResponseModel> AcceptCustomerDelivery(AcceptCustomerDeliveryRequestModel model)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (model.DeliveryId > 0 && model.Action > 0)
    //            {
    //                var getCustomerDelivery = _dbContext.CustomerDelivery.Where(res => res.Id == model.DeliveryId).FirstOrDefault();
    //                if (getCustomerDelivery != null)
    //                {
    //                    getCustomerDelivery.IsAccepted = model.Action;
    //                    if (model.Action == 2)
    //                    {
    //                        getCustomerDelivery.StatusId = 2;
    //                    }
    //                    if (model.Action == 3)
    //                    {
    //                        getCustomerDelivery.IsDeleted = true;
    //                    }
    //                    getCustomerDelivery.ModifyDate = DateTime.UtcNow;
    //                    var result = await _genericCustomerDeliveryDAL.Save(getCustomerDelivery);
    //                    if (result)
    //                    {
    //                        response.Data = getCustomerDelivery;
    //                        response.StatusCode = (int)HttpStatusCode.OK;
    //                        response.Message = TKMessages.Deliverystatus;
    //                    }
    //                    else
    //                    {
    //                        response.Data = null;
    //                        response.Message = TKMessages.ErrorMessage;
    //                        response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                    }
    //                }
    //                else
    //                {
    //                    response.Data = null;
    //                    response.Message = TKMessages.ErrorMessage;
    //                    response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                }
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.NoDeliveryFoundMessage;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    /// <summary>
    //    /// DeliveryByUserIdAndDate
    //    /// </summary>
    //    /// <param name="UserId"></param>
    //    /// <param name="dateTime"></param>
    //    /// <returns></returns>
    //    //public async Task<CommonResponseModel> DeliveryByUserIdAndDate(Guid? UserId, DateTime dateTime)
    //    //{
    //    //    CommonResponseModel response = new();

    //    //    try
    //    //    {
    //    //        if (UserId != null)
    //    //        {
    //    //            var data = await (from cd in _dbContext.CustomerDelivery
    //    //                                  //join cr in _dbContext.CustomerRoute on cd.CustomerRouteId equals cr.Id
    //    //                              join cr in _dbContext.CustomerRoute on cd.CreatedBy equals cr.CustomerId
    //    //                              // join r in _dbContext.RouteDetails on cr.RouteId equals r.Id
    //    //                              join c in _dbContext.Users on cr.CustomerId equals c.Id
    //    //                              join ds in _dbContext.DeliveryStatus on cd.StatusId equals ds.Id
    //    //                              join ss in _dbContext.ScheduleStatus on cd.IsAccepted equals ss.Id
    //    //                              join cv in _dbContext.Vehicles on cd.VehicleId equals cv.VehicleId
    //    //                              join od in _dbContext.Order on c.Id equals od.UserId
    //    //                              where !cv.IsDeleted && !cd.IsDeleted && !cr.IsDeleted && cv.UserId == UserId && cd.DeliveryDate==dateTime.Date //|| od.DeliveryDate==dateTime.Date
    //    //                              orderby cd.Id
    //    //                              select new DeliveryRM()
    //    //                              {
    //    //                                  UserId = cv.UserId,
    //    //                                  DeliveryId = cd.Id,
    //    //                                  LicencePlateNumber = cv.LicencePlateNumber,
    //    //                                  TankSize = cv.TankSize,
    //    //                                  DeliveryDate = cd.DeliveryDate,
    //    //                                  Day = cd.DeliveryDate.ToString("dddd"), //CreatedDate.ToString("dddd"),
    //    //                                  Status = ds.StatusName,
    //    //                                  ProductName =od.ProductName,
    //    //                                  ProductType=od.ProductType,
    //    //                                  FuleQty=od.FuelQuantity,
    //    //                                  Amount=od.Amount


    //    //                              }).Distinct().ToListAsync().ConfigureAwait(false);
    //    //            response.Data = data; //.GroupBy(res => new { res.UserId, res.DeliveryId, res.LicencePlateNumber, res.FuleQty, res.DeliveryDate, res.Day, res.Status }).ToList();
    //    //            //var DeliverySchedule = await _dbContext.DeliverySchedule.Where(t => t.UserId == UserId && t.DeliveryDate == dateTime).Select(a => new DeliveryRM()
    //    //            //{
    //    //            //    UserId = a.UserId,
    //    //            //    DeliveryId = a.DeliveryId,
    //    //            //    LicencePlateNumber = a.LicencePlateNumber,
    //    //            //    DeliveryDate = a.DeliveryDate,
    //    //            //    Status = a.Status,
    //    //            //    FuleQty = a.FuleQty,
    //    //            //    Day = a.Day

    //    //            //}).ToListAsync().ConfigureAwait(false);
    //    //            response.Message = TKMessages.Delivery;
    //    //            response.StatusCode = (int)HttpStatusCode.OK;
    //    //        }
    //    //        else
    //    //        {
    //    //            response.Data = null;
    //    //            response.Message = TKMessages.CommonFailed;
    //    //            response.StatusCode = (int)HttpStatusCode.BadRequest;
    //    //        }
    //    //    }
    //    //    catch (Exception ex)
    //    //    {
    //    //        _logger.LogError(ex.Message);
    //    //        response.Data = null;
    //    //        response.Message = TKMessages.CommonFailed;
    //    //        response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //    //    }
    //    //    return response;
    //    //}



    //    public async Task<CommonResponseModel> DeliveryByUserIdAndDate(Guid UserId, DateTime dateTime)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (UserId != null)
    //            {
    //                var data = (from cd in _dbContext.CustomerDelivery
    //                            join ds in _dbContext.DeliveryStatus on cd.StatusId equals ds.Id
    //                            join ss in _dbContext.ScheduleStatus on cd.IsAccepted equals ss.Id
    //                            join cv in _dbContext.Vehicles on new { x1 = cd.CreatedBy, cd.VehicleId } equals new { x1 = cv.UserId.ToString(), cv.VehicleId }
    //                            join od in _dbContext.Order on new { x1 = cd.CreatedBy, x2 = cd.VehicleId, x3 = cd.DeliveryDate.Date } equals new { x1 = od.UserId, x2 = od.VehicleId, x3 = od.DeliveryDate.Date } into ot
    //                            from fgi in ot.DefaultIfEmpty()
    //                            where !cv.IsDeleted && !cd.IsDeleted && cd.DeliveryDate.Date == dateTime.Date && cd.CreatedBy == UserId.ToString()
    //                            orderby cd.Id  
    //                            select new DeliveryRM()
    //                            {
    //                                UserId = cv.UserId,
    //                                DeliveryId = cd.Id,
    //                                LicencePlateNumber = cv.LicencePlateNumber,
    //                                TankSize = cv.TankSize,
    //                                DeliveryDate = cd.DeliveryDate,
    //                                Day = cd.DeliveryDate.ToString("dddd"), 
    //                                Status = ds.StatusName,
    //                                ProductName =(fgi!=null? fgi.ProductName:null) ,
    //                                ProductType = (fgi != null ? fgi.ProductType : null),
    //                                FuleQty = (fgi != null ? fgi.FuelQuantity : null),
    //                                Amount = (fgi != null ? fgi.Amount : null)
    //                            }).ToList().GroupBy(res => new { res.LicencePlateNumber }).Select(a => a.FirstOrDefault()).ToList();
    //                response.Data = data; 
    //                response.Message = TKMessages.Delivery;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.CommonFailed;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }


    //    /// <summary>
    //    /// DeliverySchedule
    //    /// </summary>
    //    /// <param name="UserId"></param>
    //    /// <param name="dateTime"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> DeliverySchedule()
    //    {
    //        CommonResponseModel response = new();
    //        List<SourceAndDestinationModel> sources = new();
    //        try
    //        {
    //            response.Data = await _dbContext.Users.Where(a => !String.IsNullOrEmpty(a.Latitude) && !String.IsNullOrEmpty(a.Longitude)).Select(a => new SourceAndDestinationModel()
    //            {
    //                Latitude = a.Latitude,
    //                Longitude = a.Longitude
    //            }).OrderBy(a => Convert.ToDouble(a.Latitude)).ToListAsync().ConfigureAwait(false);
    //            response.Message = TKMessages.Delivery;
    //            response.StatusCode = (int)HttpStatusCode.OK;
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// SendCustomerReferralCode
    //    /// </summary>
    //    /// <param name="model"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> SendCustomerReferralCode(SendCustomerReferralCodeModel model)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (model != null)
    //            {
    //                var UserDeatils = await _dbContext.Users.Where(t => t.Id == model.UserId).FirstOrDefaultAsync().ConfigureAwait(true);
    //                var referral = UserDeatils.ReferralCode;
    //                var emailid = model.Email;
    //                EmailSettings emailSettings = new();
    //                emailSettings.Email = _config.GetValue<string>("EmailConfiguration:From");
    //                emailSettings.Password = _config.GetValue<string>("EmailConfiguration:Password");
    //                emailSettings.Host = _config.GetValue<string>("EmailConfiguration:ServerAddress");
    //                emailSettings.Port = _config.GetValue<int>("EmailConfiguration:ServerPort");
    //                UtilityFunction function = new();
    //                EmailInfo emailInfo = new();
    //                emailInfo.EmailTo = emailid;
    //                emailInfo.Subject = TKMessages.subject;
    //                emailInfo.Body = TKMessages.Registrationmessage + referral;
    //                function.SendEmailAsync(emailInfo, emailSettings);
    //                response.Data = null;
    //                response.Message = TKMessages.referralcodesend;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.InvalidId;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    /// <summary>
    //    /// GetCustomersDetails
    //    /// </summary>
    //    /// <param name="page"></param>
    //    /// <returns></returns>

    //    public async Task<CommonUserResponseModel> GetCustomersDetails(int? Id)
    //    {
    //        CommonUserResponseModel response = new();
    //        try
    //        {
             




    //            // object userDetails = null;
    //            var userRoles = await _dbContext.Roles.Where(t => t.Name == "Customer").FirstOrDefaultAsync().ConfigureAwait(true);
    //            var totalCount = await _dbContext.Users.Where(t => t.Role == userRoles.Id).ToListAsync().ConfigureAwait(true);
    //            if (Id != null)
    //            {
    //                var route = await (from p in _dbContext.CustomerRoute
    //                                   join u in _dbContext.Users on p.CustomerId equals u.Id
    //                                   where p.RouteId == Id
    //                                   select new RegistrationResponse
    //                                   {
    //                                       Id = u.Id,
    //                                       FirstName = u.FirstName,
    //                                       LastName = u.LastName,
    //                                       Address = u.Address,
    //                                       MobileNo = u.MobileNo,
    //                                       Email = u.Email
    //                                   }).ToListAsync().ConfigureAwait(true);

    //                response.Data = route;
    //                response.TotalCount = route.Count;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                //if (page > 1)
    //                //{
    //                //    var skip = (page - 1) * 20;
    //                //    userDetails = await _dbContext.Users.Where(t => t.Role == userRoles.Id).Skip(skip).Take(20).ToListAsync().ConfigureAwait(true);
    //                //}
    //                //else
    //                //{
    //                //    userDetails = await _dbContext.Users.Where(t => t.Role == userRoles.Id).Take(20).ToListAsync().ConfigureAwait(true);
    //                //}
    //                if (totalCount != null)
    //                {

    //                    response.Data = totalCount;
    //                    response.TotalCount = totalCount.Count;
    //                    response.Message = TKMessages.CustomersDetails;
    //                    response.StatusCode = (int)HttpStatusCode.OK;
    //                }
    //                else
    //                {
    //                    response.Data = null;
    //                    response.TotalCount = 0;
    //                    response.Message = TKMessages.ListErrorMessages;
    //                    response.StatusCode = (int)HttpStatusCode.OK;
    //                }
    //                response.Message = TKMessages.CommonFailed;
    //                response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.TotalCount = 0;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// CustomersSubscriptiomPlanList
    //    /// </summary>
    //    /// <param name="customerId"></param>
    //    /// <returns></returns>

    //    public async Task<CommonUserResponseModel> CustomersSubscriptiomPlanList(string customerId)
    //    {
    //        CommonUserResponseModel response = new();
    //        try
    //        {
    //            var plans = _dbContext.Subscriptionplan.Where(a => !a.IsDeleted).ToList();
    //            var data = await (from vc in _dbContext.Vehicles
    //                              where vc.UserId == Guid.Parse(customerId) && !vc.IsDeleted
    //                              group new { vc } by new { vc.LicencePlateNumber, vc.MakeName, vc.ModelName, vc.VehicleId, } into grp
    //                              select new VehicleListWithSubscrptionPlanResponseModel()
    //                              {
    //                                  VehicleId = grp.Key.VehicleId,
    //                                  LicencePlateNumber = grp.Key.LicencePlateNumber,
    //                                  MakeName = grp.Key.MakeName,
    //                                  ModelName = grp.Key.ModelName
    //                              }).ToListAsync().ConfigureAwait(false);
    //            int rowcount = 0;
    //            if (data.Count() > 0)
    //            {
    //                foreach (var item in data)
    //                {
    //                    if (plans != null)
    //                    {
    //                        List<PlansResponseModel> planList = (from p in plans
    //                                                             join sp in _dbContext.Assignsubscription on new { X1 = p.Id, X2 = item.VehicleId, X3 = customerId } equals new { X1 = sp.PlanId, X2 = sp.vehicleId, X3 = sp.UserId } into spp
    //                                                             from n in spp.Where(a => a.RenewalDate >= DateTime.UtcNow).OrderBy(x => x.IsPrimary).DefaultIfEmpty()
    //                                                             select new PlansResponseModel()
    //                                                             {
    //                                                                 Id = p.Id,
    //                                                                 Amount = (rowcount > 0 ? Convert.ToDecimal(p.Amount) / 2 : Convert.ToDecimal(p.Amount)),
    //                                                                 PlanName = p.PlanName,
    //                                                                 Discount = Convert.ToDecimal(p.Discount),
    //                                                                 NoOfTransation = p.NoOfTransation,
    //                                                                 PerStopAmount = Convert.ToDecimal(p.PerStopAmount),
    //                                                                 SubscriptionDays = p.SubscriptionDays,
    //                                                                 NumberOfStops = p.NumberOfStops,
    //                                                                 GasUsage = p.GasUsage,
    //                                                                 SubscribeDate = (n != null ? n.SubscribeDate : null),
    //                                                                 RenewalDate = (n != null ? n.RenewalDate : null),
    //                                                                 IsPlanSelected = (n != null ? n.IsPlanSelected ? n.SubscribeDate < DateTime.UtcNow : false : false),
    //                                                             }).ToList(); //.OrderBy(x => x.IsPrimary)
    //                        item.Plans = planList;
    //                        rowcount++;
    //                    }
    //                }
    //                response.Data = data;
    //                response.Message = TKMessages.ListofSubscrption;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.InvalidId;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.InvalidId;
    //            response.StatusCode = (int)HttpStatusCode.BadRequest;
    //        }
    //        return response;
    //    }

    //    /// <summary>
    //    /// AssignSubscriptionplan
    //    /// </summary>
    //    /// <param name="assign"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> AssignSubscriptionplan(CustomerAssignSubscriptionplan assign)
    //    {
    //        var responseResult = new CommonResponseModel();
    //        try
    //        {
    //            if (_dbContext.Assignsubscription.Any(ass => ass.UserId == assign.UserId && ass.PlanId == assign.PlanId && ass.vehicleId == assign.VehicleId && ass.RenewalDate > DateTime.UtcNow))
    //            {
    //                responseResult.Data = null;
    //                responseResult.StatusCode = (int)HttpStatusCode.OK;
    //                responseResult.Message = "Already subscribed!";//TKMessages.assignplan;
    //            }
    //            else
    //            {
    //                var assignSubscription = Mapper.MapData<CustomerAssignSubscriptionplan, Assignsubscription>(assign);
    //                ///
    //              //  var CheckPlanDetails = _dbContext.Assignsubscription.Where(res => res.UserId == assign.UserId && res.IsPrimary).FirstOrDefault();

    //                //
    //                var test = _dbContext.Assignsubscription.Where(res => res.vehicleId == assign.VehicleId && res.UserId == assign.UserId && (res.RenewalDate > DateTime.UtcNow && (res.SubscribeDate < DateTime.UtcNow))).FirstOrDefault(); //
    //                TimeSpan extraDays = new TimeSpan();
    //                if (test != null)
    //                {
    //                    if (test.RenewalDate > DateTime.UtcNow)
    //                    {
    //                        extraDays = test.RenewalDate - DateTime.UtcNow;
    //                    }
    //                    else
    //                    {
    //                        extraDays = new TimeSpan();
    //                    }
    //                }
    //                else
    //                {
    //                    extraDays = new TimeSpan();
    //                }
    //                assignSubscription.SubscribeDate = DateTime.UtcNow.Add(extraDays);
    //                var planDetails = _dbContext.Subscriptionplan.Where(res => res.Id == assign.PlanId).FirstOrDefault();
    //                assignSubscription.RenewalDate = assignSubscription.SubscribeDate.AddDays(planDetails.SubscriptionDays);
    //                var result = await _genericSubscriptionDAL.Save(assignSubscription);
    //                if (result)
    //                {
    //                    responseResult.Data = null;
    //                    responseResult.StatusCode = (int)HttpStatusCode.OK;
    //                    responseResult.Message = TKMessages.assignplan;
    //                }
    //                else
    //                {
    //                    responseResult.Data = null;
    //                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
    //                    responseResult.Message = TKMessages.CommonFailed;
    //                }

    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            responseResult.Data = null;
    //            responseResult.Message = TKMessages.CommonFailed;
    //            responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return responseResult;
    //    }

    //    /// <summary>
    //    /// CancelSubscriptionPlan
    //    /// </summary>
    //    /// <param name="Id"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> CancelSubscriptionPlan(CustomerAssignSubscriptionplan customerAssignSubscriptionplan)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (customerAssignSubscriptionplan != null)
    //            {
    //                var CustomerDeatils = await _dbContext.Assignsubscription.Where(t => t.UserId == customerAssignSubscriptionplan.UserId && t.vehicleId == customerAssignSubscriptionplan.VehicleId && t.PlanId == customerAssignSubscriptionplan.PlanId && !t.CancelPlan).FirstOrDefaultAsync().ConfigureAwait(true);
    //                if (CustomerDeatils != null)
    //                {
    //                    if (CustomerDeatils.IsPrimary)
    //                    {
    //                        var PrimaryCustomerDeatils = await _dbContext.Assignsubscription.Where(t => t.UserId == customerAssignSubscriptionplan.UserId && t.vehicleId == customerAssignSubscriptionplan.VehicleId && !t.CancelPlan && !t.IsPrimary && t.SubscribeDate <= DateTime.UtcNow && t.RenewalDate >= DateTime.UtcNow).FirstOrDefaultAsync().ConfigureAwait(true);
    //                        if (PrimaryCustomerDeatils != null)
    //                        {
    //                            PrimaryCustomerDeatils.IsPrimary = true;
    //                            PrimaryCustomerDeatils.SubscribeAmount = PrimaryCustomerDeatils.SubscribeAmount * 2;
    //                            _dbContext.Update(PrimaryCustomerDeatils);
    //                        }
    //                    }
    //                    else
    //                    {
    //                        CustomerDeatils.IsPrimary = false;
    //                    }
    //                    CustomerDeatils.CancelPlan = true;
    //                    _dbContext.Update(CustomerDeatils);
    //                    var result = _dbContext.SaveChanges();
    //                    if (result > 0)
    //                    {
    //                        response.Data = null;
    //                        response.StatusCode = (int)HttpStatusCode.OK;
    //                        response.Message = TKMessages.cancelplan;
    //                    }
    //                    else
    //                    {
    //                        response.Data = null;
    //                        response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                        response.Message = TKMessages.CommonFailed;
    //                    }
    //                }
    //                else
    //                {
    //                    response.Data = null;
    //                    response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                    response.Message = TKMessages.Plancancel;
    //                }
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //                response.Message = TKMessages.CommonFailed;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// GetExcelSheetDetails
    //    /// </summary>
    //    /// <param name="Date"></param>
    //    /// <returns></returns>
    //    public Task<CommonResponseModel> GetExcelSheetDetails(DateTime Date)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {

    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return null;
    //        //ExcelSheetResponseModel
    //    }
    //    /// <summary>
    //    /// AcceptCustomerDeliveryList
    //    /// </summary>
    //    /// <param name="DeliveryDate"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> AcceptCustomerDeliveryList(DateTime DeliveryDate)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            response.Data = (from p in _dbContext.CustomerDelivery
    //                             join u in _dbContext.Users on p.CreatedBy equals u.Id
    //                             join vc in _dbContext.Vehicles on p.VehicleId equals vc.VehicleId
    //                             where p.DeliveryDate.Date == DeliveryDate.Date && p.StatusId != 3 && p.IsAccepted == 2
    //                             select new
    //                             {
    //                                 FirstName = u.FirstName,
    //                                 LastName = u.LastName,
    //                                 Address = u.Address + "," + u.Address1 + "," + u.City + u.State,
    //                                 CustomerId = u.Id,
    //                                 VehicleId = vc.VehicleId.ToString(),
    //                                 NumberPlate = vc.LicencePlateNumber,
    //                                 MobileNo = u.MobileNo
    //                             }).ToList().GroupBy(a => a.CustomerId).Select(a => new AcceptCustomerDeliveryListResponse()
    //                             {
    //                                 NoOfVehicles = a.Count().ToString(),
    //                                 FirstName = a.FirstOrDefault().FirstName,
    //                                 LicencePlate = string.Join(",", a.Select(a => a.NumberPlate)),
    //                                 LastName = a.FirstOrDefault().LastName,
    //                                 Address = a.FirstOrDefault().Address,
    //                                 MobileNo = a.FirstOrDefault().MobileNo
    //                             }).ToList();
    //            response.StatusCode = (int)HttpStatusCode.OK;
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            response.Message = "Failed";
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// CustomerAddOrder
    //    /// </summary>
    //    /// </summary>
    //    /// <param name="customerOrderRequestModel"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> CustomerAddOrder1(CustomerOrderRequestModel customerOrderRequestModel)
    //    {
    //        var responseResult = new CommonResponseModel();
    //        try
    //        {
    //            var CustomerOrders = Mapper.MapData<CustomerOrderRequestModel, Order>(customerOrderRequestModel);
    //            var result = await _genericCustomerOrdersDAL.Save(CustomerOrders);
    //            if (result)
    //            {
    //                responseResult.Data = null;
    //                responseResult.StatusCode = (int)HttpStatusCode.OK;
    //                responseResult.Message = TKMessages.msgorder;
    //            }
    //            else
    //            {
    //                responseResult.Data = null;
    //                responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
    //                responseResult.Message = TKMessages.CommonFailed;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            responseResult.Data = null;
    //            responseResult.Message = TKMessages.CommonFailed;
    //            responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return responseResult;
    //    }

    //    /// <summary>
    //    /// API method to get customer details
    //    /// </summary>
    //    /// <param name="userId"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> GetCustomerOrderDetails(string userId)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            response.Data = await _dbContext.Order.Where(res => res.UserId == userId).Select(aa => new CustomerOrderResponseModel()
    //            {

    //                FirstName = aa.FirstName,
    //                LastName = aa.LastName,
    //                LicencePlateNo = aa.LicencePlateNo,
    //                MakeName = aa.MakeName,
    //                ModelName = aa.ModelName,
    //                ProductName = aa.ProductName,
    //                ProductType = aa.ProductType,
    //                FuelQuantity = Convert.ToDouble(aa.FuelQuantity),
    //                Amount = Convert.ToDouble(aa.Amount),
    //                DeliveryDate = aa.DeliveryDate.Date,
    //            }).OrderByDescending(x => x.DeliveryDate).ToListAsync().ConfigureAwait(false);
    //            response.StatusCode = (int)HttpStatusCode.OK;
    //            response.Message = "show of all customer order details";

    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }
    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    /// <param name="customerOrderRequestModel"></param>
    //    /// <returns></returns>
    //    public async Task<CommonResponseModel> CustomerAddOrder(CustomerOrderRequestModel customerOrderRequestModel)
    //    {
    //        var responseResult = new CommonResponseModel();
    //        try
    //        {
    //            Order order = new Order();
    //            order.UserId = customerOrderRequestModel.UserId;
    //            order.VehicleId = customerOrderRequestModel.VehicleId;
    //           // order.LicencePlateNo = customerOrderRequestModel.LicencePlateNo;
    //           // order.MakeName = customerOrderRequestModel.MakeName;
    //           // order.ModelName = customerOrderRequestModel.ModelName;
    //           // order.FirstName = customerOrderRequestModel.FirstName;
    //           // order.LastName = customerOrderRequestModel.LastName;
    //           //  order.ProductName = customerOrderRequestModel.ProductName;
    //           // order.ProductType = customerOrderRequestModel.ProductType;
    //            order.FuelQuantity = customerOrderRequestModel.FuelQuantity;
    //            order.MobileNo = customerOrderRequestModel.MobileNo;
    //            order.DeliveredBy = customerOrderRequestModel.DeliveredBy;
    //            order.Amount = customerOrderRequestModel.Amount;
    //            order.CreatedBy = customerOrderRequestModel.UserId;
    //            order.CreatedDate = customerOrderRequestModel.CreatedDate = DateTime.UtcNow;
    //            order.DeliveryDate = customerOrderRequestModel.DeliveryDate = DateTime.UtcNow;
    //            order.ModifyDate = customerOrderRequestModel.ModifyDate = DateTime.UtcNow;
    //            order.ModifyBy = customerOrderRequestModel.UserId;
    //            order.IsDelivered = customerOrderRequestModel.IsDelivered = true;
    //            order.IsPayment = customerOrderRequestModel.IsPayment = true;
    //            _dbContext.Order.Add(order);
    //            _dbContext.SaveChanges();
    //            responseResult.Data = null;
    //            responseResult.StatusCode = (int)HttpStatusCode.OK;
    //            responseResult.Message = "Delivered sucessfully";
    //            var customerDelivery = await _dbContext.Order.Where(res => res.UserId == customerOrderRequestModel.UserId && res.IsDelivered).FirstOrDefaultAsync();
    //            if (customerDelivery != null)
    //            {
    //                //var delivery = _dbContext.CustomerDelivery.Where(de => de.CreatedBy == customerDelivery.UserId && de.VehicleId == customerOrderRequestModel.VehicleId && de.DeliveryDate.Date == customerDelivery.DeliveryDate.Date).FirstOrDefault(); //&& de.DeliveryDate.Date==DateTime.UtcNow.Date
    //                var delivery = _dbContext.CustomerDelivery.Where(de => de.VehicleId == customerOrderRequestModel.VehicleId && de.DeliveryDate.Date == customerDelivery.DeliveryDate.Date).FirstOrDefault(); //&& de.DeliveryDate.Date==DateTime.UtcNow.Date
    //                if (delivery != null)
    //                {
    //                     delivery.StatusId = 3;
    //                    _dbContext.CustomerDelivery.Update(delivery);
    //                    _dbContext.SaveChanges();
    //                    var userDetails = _dbContext.Users.Where(res => res.Id == customerOrderRequestModel.UserId && !res.IsNotification).FirstOrDefault();
    //                    var deviceTokens = _dbContext.UserToken.Where(res => res.UserId == customerOrderRequestModel.UserId).ToList();
    //                    if (deviceTokens != null)
    //                    {
    //                        foreach (var token in deviceTokens)
    //                        {
    //                            //UtilityFunction.SendNotification(token.DeviceToken, customerRoute.CustomerId, 1, userDetails.FirstName,"Message","Delivery");
    //                            UtilityFunction.SendNotification(token.DeviceToken, customerOrderRequestModel.UserId, 1, userDetails.FirstName, "Hi, Your delivery is completed" + " " + customerDelivery.DeliveryDate.Date, "Delivered");
    //                        }
    //                    }
    //                    responseResult.Data = null;
    //                    responseResult.StatusCode = (int)HttpStatusCode.OK;
    //                    responseResult.Message = "Added sucessfully";

    //                }
    //                else
    //                {
    //                    responseResult.Data = null;
    //                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
    //                    responseResult.Message = TKMessages.CommonFailed;
    //                }
    //            }
    //            else
    //            {
    //                responseResult.Data = null;
    //                responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
    //                responseResult.Message = TKMessages.CommonFailed;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            responseResult.Data = null;
    //            responseResult.Message = TKMessages.CommonFailed;
    //            responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return responseResult;
    //    }

    //    public async Task<CommonResponseModel> GetCustomerListWithVehicleDetails(bool IsBarcode)
    //    {
    //        CommonResponseModel response = new();
    //        //var VehicleDetails;
    //        try
    //        {
    //            if (IsBarcode)
    //            {
    //                var VehicleDetails = await (from p in _dbContext.Vehicles
    //                                            join u in _dbContext.Users on p.UserId.ToString() equals u.Id
    //                                            //join pd in _dbContext.Product
    //                                            where !p.IsDeleted && p.BarCode != null
    //                                            select new GetCustomerDetailsWithVehicleResponseModel
    //                                            {
    //                                                FirstName = u.FirstName,
    //                                                LastName = u.LastName,
    //                                                LicencePlateNumber = p.LicencePlateNumber,
    //                                                MakeName = p.MakeName,
    //                                                ModelName = p.ModelName,
    //                                                Color = p.Color,
    //                                                BarCode = p.BarCode,
    //                                                TankSize = p.TankSize,
    //                                                VehicleId = p.VehicleId
    //                                            }).ToListAsync();
    //                response.Data = VehicleDetails;
    //            }
    //            else
    //            {
    //                var VehicleDetails1 = await (from p in _dbContext.Vehicles
    //                                             join u in _dbContext.Users on p.UserId.ToString() equals u.Id
    //                                             //join pd in _dbContext.Product
    //                                             where !p.IsDeleted && p.BarCode == null
    //                                             select new GetCustomerDetailsWithVehicleResponseModel
    //                                             {
    //                                                 FirstName = u.FirstName,
    //                                                 LastName = u.LastName,
    //                                                 LicencePlateNumber = p.LicencePlateNumber,
    //                                                 MakeName = p.MakeName,
    //                                                 ModelName = p.ModelName,
    //                                                 Color = p.Color,
    //                                                 BarCode = p.BarCode,
    //                                                 TankSize = p.TankSize,
    //                                                 VehicleId = p.VehicleId
    //                                             }).ToListAsync();
    //                response.Data = VehicleDetails1;
    //            }

    //            //response.Data = VehicleDetails;
    //            response.Message = "list of Vehicles Details";
    //            response.StatusCode = (int)HttpStatusCode.OK;
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    public async Task<CommonResponseModel> GetCustomerVehicleList()
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            var VehicleDetails = await (from p in _dbContext.Vehicles
    //                                        join u in _dbContext.Users on p.UserId.ToString() equals u.Id
    //                                        join pd in _dbContext.Product on p.ProductId equals pd.Id
    //                                        orderby p.BarCode ascending
    //                                        where !p.IsDeleted
    //                                        select new GetCustomerDetailsWithVehicleResponseModel
    //                                        {
    //                                            FirstName = u.FirstName,
    //                                            LastName = u.LastName,
    //                                            LicencePlateNumber = p.LicencePlateNumber,
    //                                            MakeName = p.MakeName,
    //                                            ModelName = p.ModelName,
    //                                            Color = p.Color,
    //                                            BarCode = p.BarCode,
    //                                            TankSize = p.TankSize,
    //                                            VehicleId = p.VehicleId,
    //                                            FuelType = pd.FuelType,
    //                                            ProductName = pd.ProductName

    //                                        }).ToListAsync();
    //            response.Data = VehicleDetails;
    //            response.Message = "list of Vehicles Details";
    //            response.StatusCode = (int)HttpStatusCode.OK;

    //        }
    //        catch (Exception ex)
    //        {

    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    public async Task<CommonResponseModel> GetCustomerDeliveryPastFive(Guid userId)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            if (userId != null)
    //            {
    //                var data = (from cd in _dbContext.CustomerDelivery
    //                                //join cr in _dbContext.CustomerRoute on cd.CustomerRouteId equals cr.Id
    //                                //join r in _dbContext.RouteDetails on cr.RouteId equals r.Id
    //                                // join cr in _dbContext.CustomerRoute on cd.CreatedBy equals cr.CustomerId
    //                                // join c in _dbContext.Users on cr.CustomerId equals c.Id
    //                            join ds in _dbContext.DeliveryStatus on cd.StatusId equals ds.Id
    //                            join ss in _dbContext.ScheduleStatus on cd.IsAccepted equals ss.Id
    //                            join cv in _dbContext.Vehicles on cd.VehicleId equals cv.VehicleId
    //                            //  join od in _dbContext.Order on cv.UserId.ToString() equals od.UserId
    //                            where !cv.IsDeleted && !cd.IsDeleted && cd.StatusId == 3 && cv.UserId == userId
    //                            orderby cd.Id
    //                            select new DeliveryRM()
    //                            {
    //                                UserId = cv.UserId,
    //                                DeliveryId = cd.Id,
    //                                LicencePlateNumber = cv.LicencePlateNumber,
    //                                TankSize = cv.TankSize,
    //                                VehicleId = cd.VehicleId,
    //                                DeliveryDate = cd.DeliveryDate,
    //                                Day = cd.CreatedDate.ToString("dddd"),
    //                                Status = ds.StatusName,
    //                                IsPastDelivery = cd.StatusId == 3,
    //                                IsAccepted = cd.IsAccepted,
    //                                IsAcceptedName = ss.StatusName,
    //                                //ProductName = od.ProductName,
    //                                //ProductType = od.ProductType,
    //                                //FuelUse = od.FuelQuantity,
    //                                //Amount = od.Amount,
    //                                //.OrderByDescending(x=>x.DeliveryDate).Take(5);
    //                            }).Distinct().ToList().OrderByDescending(x => x.DeliveryDate).Take(5);//.GroupBy(res => new { res.UserId, res.IsPastDelivery, res.IsAccepted, res.IsAcceptedName, res.LicencePlateNumber, res.FuleQty, res.DeliveryDate, res.Day, res.Status }).ToList();
    //                response.Data = data;
    //                response.Message = TKMessages.Delivery;
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.CommonFailed;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            _logger.LogError(ex.Message);
    //            response.Data = null;
    //            response.Message = TKMessages.CommonFailed;
    //            response.StatusCode = (int)HttpStatusCode.InternalServerError;
    //        }
    //        return response;
    //    }

    //    public async Task<CommonResponseModel> CustomerNotification(Customer customer)
    //    {
    //        CommonResponseModel response = new();
    //        try
    //        {
    //            var userDetails = _dbContext.Users.Where(res => res.Id == customer.Id).FirstOrDefault();
    //            if(userDetails!=null)
    //            {
    //                userDetails.IsNotification = customer.IsNotification;
    //                _dbContext.Entry(userDetails).State = EntityState.Modified;
    //                var result = _dbContext.SaveChanges();
    //                response.Data = userDetails;
    //                response.Message = "sucess";
    //                response.StatusCode = (int)HttpStatusCode.OK;
    //            }
    //            else
    //            {
    //                response.Data = null;
    //                response.Message = TKMessages.CommonFailed;
    //                response.StatusCode = (int)HttpStatusCode.BadRequest;
    //            }
    //        }
    //        catch (Exception ex)
    //        {

    //            throw ex;
    //        }
    //        return response;
    //    }
    //}
}























//public async Task<CommonUserResponseModel> CustomersSubscriptiomPlanList(string customerId)
//{
//    CommonUserResponseModel response = new();
//    try
//    {
//        var user = _dbContext.Users.Where(userId => userId.Id == customerId).FirstOrDefault();
//        if (user != null)
//        {
//            var vech = _dbContext.Vehicles.Where(res => res.UserId == Guid.Parse(customerId) && !res.IsDeleted).FirstOrDefault();
//            if (vech != null)
//            {
//                var plans = _dbContext.Subscriptionplan.Where(a => !a.IsDeleted).ToList();
//                //PlansResponseModel plansResponse = new PlansResponseModel();
//                //List<PlansResponseModel> lstPlansResponse = new List<PlansResponseModel>();
//                //foreach (var planItem in plans)
//                //{
//                //    plansResponse = new PlansResponseModel();
//                //    plansResponse.Id = planItem.Id;
//                //    plansResponse.Amount = Convert.ToDecimal(planItem.Amount);
//                //    plansResponse.PlanName = planItem.PlanName;
//                //    plansResponse.Discount = Convert.ToDecimal(planItem.Discount);
//                //    plansResponse.NoOfTransation = planItem.NoOfTransation;
//                //    plansResponse.PerStopAmount = Convert.ToDecimal(planItem.PerStopAmount);
//                //    plansResponse.SubscriptionDays = planItem.SubscriptionDays;
//                //    plansResponse.NumberOfStops = planItem.NumberOfStops;
//                //    plansResponse.GasUsage = planItem.GasUsage;
//                //    lstPlansResponse.Add(plansResponse);
//                //}

//                var data = await (from vc in _dbContext.Vehicles
//                                  join sb in _dbContext.Subscriptionplan on vc.IsDeleted! equals false
//                                  //join ssc in _dbContext.Assignsubscription on sb.Id equals ssc.PlanId
//                                  where vc.UserId == Guid.Parse(customerId)
//                                  group new { vc } by new { vc.LicencePlateNumber, vc.MakeName, vc.ModelName, vc.VehicleId, } into grp
//                                  select new VehicleListWithSubscrptionPlanResponseModel()
//                                  {
//                                      VehicleId = grp.Key.VehicleId,
//                                      LicencePlateNumber = grp.Key.LicencePlateNumber,
//                                      MakeName = grp.Key.MakeName,
//                                      ModelName = grp.Key.ModelName
//                                  }).ToListAsync().ConfigureAwait(false);
//                int rowcount = 0;
//                if (data != null)
//                {
//                    foreach (var item in data)
//                    {
//                        if (plans != null)
//                        {
//                            List<PlansResponseModel> planList = plans.Select(a => new PlansResponseModel()
//                            {
//                                Id = a.Id,
//                                Amount = Convert.ToDecimal(a.Amount),
//                                PlanName = a.PlanName,
//                                Discount = Convert.ToDecimal(a.Discount),
//                                NoOfTransation = a.NoOfTransation,
//                                PerStopAmount = Convert.ToDecimal(a.PerStopAmount),
//                                SubscriptionDays = a.SubscriptionDays,
//                                NumberOfStops = a.NumberOfStops,
//                                GasUsage = a.GasUsage,
//                                SubscribeDate = _dbContext.Assignsubscription.Where(res => res.PlanId == a.Id && res.vehicleId == item.VehicleId).Select(b => b.SubscribeDate).FirstOrDefault(),
//                                RenewalDate = _dbContext.Assignsubscription.Where(res => res.PlanId == a.Id && res.vehicleId == item.VehicleId).Select(b => b.RenewalDate).FirstOrDefault(),
//                            }).ToList();
//                            foreach (var planitem in planList)
//                            {
//                                if (_dbContext.Assignsubscription.Any(a => a.UserId == customerId && a.vehicleId == item.VehicleId && a.PlanId == planitem.Id && a.IsPlanSelected && (a.SubscribeDate < DateTime.UtcNow && a.RenewalDate > DateTime.UtcNow))) //&& !a.IsDeleted 
//                                {
//                                    planitem.IsPlanSelected = true;
//                                }
//                                else
//                                {
//                                    planitem.IsPlanSelected = false;
//                                }
//                            }
//                            if (rowcount > 0)
//                            {
//                                foreach (var planitem in planList)  //foreach (var planitem in item.Plans)
//                                {
//                                    planitem.Amount = planitem.Amount / 2;
//                                }
//                            }
//                            rowcount++;
//                            item.Plans = planList;
//                        }
//                    }

//                    //foreach (var item in data)
//                    //{
//                    //    if (rowcount > 0)
//                    //    {
//                    //        foreach (var planitem in item.Plans)
//                    //        {
//                    //            planitem.Amount = planitem.Amount / 2;
//                    //        }
//                    //    }
//                    //    rowcount++;
//                    //}
//                }
//                response.Data = data;
//                response.Message = TKMessages.ListofSubscrption;
//                response.StatusCode = (int)HttpStatusCode.OK;
//            }
//            else
//            {
//                response.Data = null;
//                response.Message = TKMessages.vehiclesissue;
//                response.StatusCode = (int)HttpStatusCode.BadRequest;
//            }
//        }
//        else
//        {
//            response.Data = null;
//            response.Message = TKMessages.InvalidId;
//            response.StatusCode = (int)HttpStatusCode.BadRequest;
//        }
//    }
//    catch (Exception ex)
//    {
//        _logger.LogError(ex.Message);
//        response.Data = null;
//        response.Message = TKMessages.InvalidId;
//        response.StatusCode = (int)HttpStatusCode.BadRequest;
//    }
//    return response;
//}










//public async Task<CommonResponseModel> AssignSubscriptionplan(CustomerAssignSubscriptionplan assign)
//{
//    var responseResult = new CommonResponseModel();
//    try
//    {
//        var assignSubscription = Mapper.MapData<CustomerAssignSubscriptionplan, Assignsubscription>(assign);
//        var test = _dbContext.Assignsubscription.Where(res => res.vehicleId == assign.VehicleId && res.UserId == assign.UserId && (res.RenewalDate > DateTime.UtcNow && (res.SubscribeDate < DateTime.UtcNow))).FirstOrDefault(); //
//                                                                                                                                                                                                                                  //foreach (var item in test)
//                                                                                                                                                                                                                                  //{
//        TimeSpan extraDays = new TimeSpan();
//        if (test.RenewalDate > DateTime.UtcNow)
//        {
//            extraDays = test.RenewalDate - DateTime.UtcNow;
//        }
//        //}
//        assignSubscription.SubscribeDate = DateTime.UtcNow.Add(extraDays);
//        var planDetails = _dbContext.Subscriptionplan.Where(res => res.Id == assign.PlanId).FirstOrDefault();
//        assignSubscription.RenewalDate = assignSubscription.SubscribeDate.AddDays(planDetails.SubscriptionDays);
//        var result = await _genericSubscriptionDAL.Save(assignSubscription);
//        if (result)
//        {
//            responseResult.Data = null;
//            responseResult.StatusCode = (int)HttpStatusCode.OK;
//            responseResult.Message = TKMessages.assignplan;
//        }
//        else
//        {
//            responseResult.Data = null;
//            responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//            responseResult.Message = TKMessages.CommonFailed;
//        }
//    }
//    catch (Exception ex)
//    {
//        _logger.LogError(ex.Message);
//        responseResult.Data = null;
//        responseResult.Message = TKMessages.CommonFailed;
//        responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//    }
//    return responseResult;
//}














//public async Task<CommonResponseModel> AssignSubscriptionplan(CustomerAssignSubscriptionplan assign)
//{
//    CommonResponseModel response = new();
//    try
//    {
//        var userdeatils = _dbContext.Users.Where(a => a.Id == assign.UserId).FirstOrDefault();
//        {
//            if (userdeatils != null)
//            {

//                //var subplan = _dbContext.Assignsubscription.Any(a => a.UserId == assign.UserId && a.vehicleId == assign.vehicleId && a.PlanId == assign.PlanId && !a.IsDeleted);
//                var subplan = _dbContext.Assignsubscription.Any(a => a.UserId == assign.UserId && a.vehicleId == assign.vehicleId && !a.IsDeleted);
//                if (subplan == true)
//                {
//                    Assignsubscription res = new Assignsubscription();
//                    {
//                        // res.UserId = assign.UserId;
//                        // res.vehicleId = assign.vehicleId;
//                        res.PlanId = assign.PlanId;
//                        _dbContext.Assignsubscription.Update(res);
//                        _dbContext.SaveChanges();
//                    };
//                    response.StatusCode = (int)(HttpStatusCode.OK);
//                    response.Message = TKMessages.ApplyDiscount;
//                }
//                else
//                {
//                    Assignsubscription res1 = new Assignsubscription();
//                    _dbContext.Assignsubscription.Add(res1);
//                    _dbContext.SaveChanges();
//                    response.StatusCode = (int)(HttpStatusCode.OK);
//                    response.Message = TKMessages.ApplyDiscount;
//                }
//            }
//            else
//            {
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//        }
//    }
//    catch (Exception ex)
//    {
//        // _logger.LogError(ex.Message);
//        response.Data = null;
//        response.Message = TKMessages.CommonFailed;
//        response.StatusCode = (int)HttpStatusCode.InternalServerError;
//    }
//    return response;
//}




//public async Task<CommonUserResponseModel> CustomersSubscriptiomPlanList(string customerId)
//{
//    CommonUserResponseModel response = new();
//    // VehicleModel vehicle = new();
//    var customerDetails = _dbContext.Users.Where(res => res.Id == customerId).FirstOrDefault();
//    if (customerDetails != null)
//    {
//        var VehiclesDetails = await (
//        from p in _dbContext.Vehicles
//        join u in _dbContext.Assignsubscription on p.UserId equals Guid.Parse(u.UserId)
//        where p.UserId == Guid.Parse(customerId)
//        select new SubscriptiomPlanListResponse
//        {
//            LicencePlateNumber = p.LicencePlateNumber,
//            Amount = u.Amount,
//            ModelName = p.ModelName,
//            PlanName = u.PlanName,
//            Discount = u.Discount
//        }).ToListAsync().ConfigureAwait(true);
//        response.Data = VehiclesDetails;
//        response.Message = TKMessages.ListofSubscrption;
//        response.StatusCode = (int)HttpStatusCode.OK;
//    }
//    else
//    {
//        response.Data = null;
//        response.Message = TKMessages.InvalidId;
//        response.StatusCode = (int)HttpStatusCode.BadRequest;
//    }
//    return null;
//}

//public async Task<CommonUserResponseModel> CustomersSubscriptiomPlanList(string customerId)
//{
//    CommonUserResponseModel response = new();
//    VehicleModel vehicle = new();
//    var customerDetails = _dbContext.Users.Where(res => res.Id == customerId).FirstOrDefault();
//    if (customerDetails != null)
//    {
//        //var totalCount = await _dbContext.Users.Where(t => t.Role == userRoles.Id).ToListAsync().ConfigureAwait(true);
//        var vehicleDetails = await _dbContext.Vehicles.Where(veh => veh.UserId == Guid.Parse(customerId)).ToListAsync().ConfigureAwait(true);
//        if (vehicleDetails.Count > 0)
//        {
//            foreach (var item in vehicleDetails)
//            {
//                vehicle.VehicleId = item.VehicleId;
//                vehicle.MakeName = item.MakeName;
//                vehicle.LicencePlateNumber = item.LicencePlateNumber;


//            }
//        }
//        else
//        {
//            response.Data = null;
//            response.Message = TKMessages.InvalidId;
//            response.StatusCode = (int)HttpStatusCode.BadRequest;
//        }

//    }
//    else
//    {
//        response.Data = null;
//        response.Message = TKMessages.InvalidId;
//        response.StatusCode = (int)HttpStatusCode.BadRequest;
//    }
//    return null;
//}



















