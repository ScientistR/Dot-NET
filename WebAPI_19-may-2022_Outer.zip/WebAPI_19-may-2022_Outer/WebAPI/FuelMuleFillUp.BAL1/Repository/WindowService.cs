﻿//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Models;
//using Microsoft.Extensions.Configuration;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class WindowService: IWindowService
//    {
//        private readonly IConfiguration Config;
//        private readonly FuelMuleFillUpContext _dbContext;

//        public WindowService(FuelMuleFillUpContext dbContext,IConfiguration config)
//        {
//            // _config = config;
//              Config = config;
//            _dbContext = dbContext;
//        }
//        public Task<CommonResponseModel> RenewalSubscriptionPlanCheck()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var plans = _dbContext.Subscriptionplan.Where(a => !a.IsDeleted).ToList();

//                var userDetails = _dbContext.Assignsubscription.Where(res =>!res.CancelPlan && res.RenewalDate.Date == DateTime.UtcNow.Date).ToList();
//                if (userDetails != null)
//                {
//                    foreach (var item in userDetails)
//                    {
//                        //var planchek=_dbContext.Subscriptionplan.Where(res=>item.PlanId)
//                    }
//                }
//            }
//            catch (Exception)
//            {

//                throw;
//            }
//            return null;
//        }
//    }
//}
