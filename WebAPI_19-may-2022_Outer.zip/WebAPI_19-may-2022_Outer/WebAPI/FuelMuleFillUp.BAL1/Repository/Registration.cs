﻿//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Interfaces;
//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Utilities;
//using FuelMuleFillUp.Entities;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.IdentityModel.Tokens;
//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using Microsoft.Extensions.Configuration;
//using Microsoft.AspNetCore.Identity;
//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Entities.DBTables;
//using System.Net;
//using FuelMuleFillUp.Models.ResponseModel;
//using FuelMuleFillUp.DAL.IDAL;
//using Microsoft.Extensions.Logging;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Primitives;
//using Org.BouncyCastle.Security;
//using System.Data;
//using ClosedXML.Excel;
//using System.IO;
//using FuelMuleFillUp.Entities.Models;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class Registration : IRegistration
//    {
//        private readonly UserManager<AspNetUser> _userManager;
//        private readonly IConfiguration Config;
//      //  private readonly FuelMuleFillUpContext _dbContext;
//        private readonly IGenericDAL<Driver> _genericDriverDAL;
//        private readonly IGenericDAL<Product> _genericProductDAL;
//        private readonly IGenericDAL<PerStopAmount> _genericPerStopAmountDAL;
//        private readonly ILogger<Registration> _logger;


//        public Registration(FuelMuleFillUpENRGQAContext dbContext, IGenericDAL<Driver> genericDriverDAL, IGenericDAL<PerStopAmount> genericPerStopAmountDAL, IGenericDAL<Product> genericProductDAL, ILogger<Registration> logger, IConfiguration config, UserManager<ApplicationUser> userManager)
//        {
//            // _config = config;
//            Config = config;
//            _dbContext = dbContext;
//            _userManager = userManager;
//            _genericDriverDAL = genericDriverDAL;
//            _genericProductDAL = genericProductDAL;
//            _genericPerStopAmountDAL = genericPerStopAmountDAL;
//            _logger = logger;
//        }

        
    

//            /// <summary>
//            /// login customer & admin
//            /// </summary>
//            /// <param name="login"></param>
//            /// <returns></returns>
//            public async Task<CommonResponseModel> loginUser(LoginModel login)
//        {
//            CommonResponseModel response = new();
//            try
//            {

//                if (!string.IsNullOrEmpty(login.UserName) && !string.IsNullOrEmpty(login.Password))
//                {
                    

//                    var user = await _userManager.FindByNameAsync(login.UserName).ConfigureAwait(false);
//                    var Data = await _userManager.CheckPasswordAsync(user, login.Password).ConfigureAwait(false);
//                    if(Data)
//                    {
//                        //var zipverify = _dbContext.ZipCodes.Where(zip => zip.Zip == user.ZipCode).ToList();
//                        //if(zipverify.Count>0)
//                        //{
//                        var UserRole = _dbContext.Roles.Where(res => res.Id == user.Role).FirstOrDefault();
//                        var UserDeatils = new RegistrationModel();
//                        var loginResponseModel = new LoginResponseModel();
//                        var loginResponseToken = new LoginResponseToken();
//                        loginResponseModel.UserId = user.Id;
//                        loginResponseModel.EmailAddress = user.UserName;
//                        loginResponseModel.FirstName = user.FirstName;
//                        loginResponseModel.LastName = user.LastName;
//                        loginResponseModel.Address = user.Address;
//                        loginResponseModel.Address1 = user.Address1;
//                        loginResponseModel.MobileNo = user.MobileNo;
//                        loginResponseModel.City = user.City;
//                        loginResponseModel.ZipCode = user.ZipCode;
//                        loginResponseModel.Country = user.Country;
//                        loginResponseModel.RoleId = user.Role;
//                        loginResponseModel.RoleName = UserRole.Name;
//                        loginResponseModel.ReferralCode = user.ReferralCode;
//                        loginResponseModel.IsNotification = user.IsNotification;
//                        loginResponseModel.Token = GenerateJSONWebToken(login, user.Role);

//                        UserToken userToken = new UserToken();
//                        userToken.DeviceId = login.DeviceId;
//                        userToken.DeviceToken = login.DeviceToken;
//                        userToken.UserId = user.Id;
//                        userToken.ModifyBy = user.Id;
//                        userToken.CreatedBy = user.FirstName + " " + user.LastName;
//                        userToken.CreatedDate = loginResponseToken.CreatedDate = DateTime.UtcNow.Date;
//                        userToken.ModifyDate = loginResponseToken.ModifyDate = DateTime.UtcNow.Date;
//                        _dbContext.Update(userToken);
//                        _dbContext.SaveChanges();
//                        var DeviceInfo = _dbContext.UserToken.Where(a => a.UserId == user.Id && a.DeviceId == login.DeviceId).FirstOrDefault();
//                        if (DeviceInfo != null)
//                        {
//                            DeviceInfo.DeviceId = login.DeviceId;
//                            DeviceInfo.UserId = user.Id;
//                            DeviceInfo.DeviceToken = login.DeviceToken;
//                            DeviceInfo.CreatedBy = user.FirstName;
//                            DeviceInfo.CreatedDate = DateTime.UtcNow;
//                            _dbContext.Update(DeviceInfo);
//                            _dbContext.SaveChanges();
//                        }
//                        else
//                        {
//                            UserToken usertoken = new UserToken();
//                            userToken.DeviceId = login.DeviceId;
//                            userToken.UserId = user.Id;
//                            userToken.DeviceToken = login.DeviceToken;
//                            userToken.CreatedBy = user.FirstName;
//                            userToken.CreatedDate = DateTime.UtcNow;
//                            _dbContext.UserToken.Add(userToken);
//                            _dbContext.SaveChanges();
//                        }
//                        response.Data = loginResponseModel;
//                        response.Message = TKMessages.login;
//                        response.StatusCode = (int)HttpStatusCode.OK;


//                        //}
//                        //else
//                        //{
//                        //    response.Data = null;
//                        //    response.Message = TKMessages.ZipMessage;
//                        //    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                        //}

//                    }

//                    else
//                    {
//                        response.Data = null;
//                        response.Message = TKMessages.invaliduser;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    }
//                }
//                else
//                {
//                    response.Data = null;
//                    response.Message = TKMessages.failed;
//                    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.failed;
//                response.StatusCode = (int)HttpStatusCode.BadGateway;
//            }
//            return response;
//        }
//        /// <summary>
//        /// GenerateJSONWebToken
//        /// </summary>
//        /// <param name="login"></param>
//        /// <returns></returns>
//        private string GenerateJSONWebToken(LoginModel login,string roleId)
//        {
//            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Config["Jwt:Key"]));
//            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

//            var claims = new[] {
//                new Claim(JwtRegisteredClaimNames.Sub, login.UserName.ToString()),
//                //new Claim(JwtRegisteredClaimNames., userInfo.Password),
//                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
//                new Claim("Role",roleId)
//            };

//            var token = new JwtSecurityToken(Config["Jwt:Issuer"],
//                Config["Jwt:Issuer"],
//                claims,
//                expires: DateTime.Now.AddDays(365),
//                signingCredentials: credentials);

//            return new JwtSecurityTokenHandler().WriteToken(token);
//        }

//        /// <summary>
//        /// OtpResetPassword
//        /// </summary>
//        /// <param name="OtpResetPassword"></param>
//        /// <returns></returns>
//        public async Task<APIResponseModel> OtpSend(SendOtpModel sendOtp, EmailSettings emailSettings)
//        {
//            UtilityFunction function = new();
//            APIResponseModel response = new();
//            LoginResponse retdata = new();
//            // int status = 0;
//            try
//            {
//                if (!string.IsNullOrEmpty(sendOtp.UserName))
//                {
//                    var userDetails = await _dbContext.Users.Where(x => x.UserName == sendOtp.UserName).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (userDetails != null)
//                    {
//                        var otpDetails = GenerateRandomOTP();
//                        /// save otp from database
//                        userDetails.OTP = otpDetails;
//                        userDetails.OTPCreatedDate = DateTime.UtcNow;
//                        _dbContext.Update(userDetails);
//                        var result = await _dbContext.SaveChangesAsync();
//                        EmailInfo emailInfo = new();
//                        emailInfo.EmailTo = userDetails.UserName;
//                        emailInfo.Subject = TKMessages.subject;  // "Test";
//                        //emailInfo.Body = "Hi This is your otp" + otpDetails;
//                        emailInfo.Body = TKMessages.otpbodymessage + otpDetails;
//                        function.SendEmailAsync(emailInfo, emailSettings);
//                        return response = function.DataResponse(retdata, true, TKMessages.OTP, (int)HttpStatusCode.OK);
//                    }
//                    else
//                    {
//                        return response = function.DataResponse(retdata, true, TKMessages.invalidemail, (int)HttpStatusCode.BadRequest);
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//            }
//            return response = function.DataResponse(retdata, true, TKMessages.failed, (int)HttpStatusCode.BadRequest);
//        }

//        /// <summary>
//        /// GenerateRandomOTP
//        /// </summary>
//        /// <returns></returns>
//        public string GenerateRandomOTP()
//        {
//            string[] saAllowedCharacters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
//            string sOTP = String.Empty;
//            string sTempChars = String.Empty;
//            Random rand = new();
//            for (int i = 0; i < 4; i++)
//            {
//                // int p = rand.Next(0, saAllowedCharacters.Length);

//                sTempChars = saAllowedCharacters[rand.Next(0, saAllowedCharacters.Length)];
//                sOTP += sTempChars;
//            }
//            return sOTP;
//        }

//        /// <summary>
//        /// GenrateReferralRandomCode
//        /// </summary>
//        /// <returns></returns>
//        public string GenrateReferralRandomCode()
//        {
//            char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890".ToCharArray();
//            StringBuilder sb = new(); //StringBuilder
//            Random random = new SecureRandom();
//            for (int i = 0; i < 6; i++)
//            {
//                char c = chars[random.Next(chars.Length)];
//                sb.Append(c);
//            }
//            String output = sb.ToString();
//            return output;
//        }

//        /// <summary>
//        ///  add customer order by admin
//        /// </summary>
//        /// <param name="order"></param>
//        /// <returns></returns>
//        /// 
//        public async Task<CommonResponseModel> AddOrder(OrderModel order)
//        {
//            var responseResult = new CommonResponseModel();
//            var tblOrder = Mapper.MapData<OrderModel, tblOrders>(order);
//            await _dbContext.Orders.AddAsync(tblOrder).ConfigureAwait(false);

//            var save = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
//            if (save != -1)
//            {
//                responseResult.Data = tblOrder;
//                responseResult.Message = TKMessages.addorder;
//                responseResult.StatusCode = (int)HttpStatusCode.OK;
//            }
//            else
//            {
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.rejectorder;
//                responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//            }
//            return responseResult;
//        }

//        /// <summary>
//        /// logout
//        /// </summary>
//        /// <param name="logout"></param>
//        /// <returns></returns>
//        public Task<APIResponseModel> logout(SendOtpModel sendOtp)
//        {
//            throw new NotImplementedException();
//        }
//        /// <summary>
//        /// VerifyOtp
//        /// </summary>
//        /// <param name="order"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> VerifyOtp(VerifyOtpModel verifyOtpModel)
//        {
//            CommonResponseModel response = new();
//            if (verifyOtpModel != null)
//            {
//                var verifyOTP = await _dbContext.Users.Where(res => res.UserName == verifyOtpModel.UserName && res.OTP == verifyOtpModel.OTP).FirstOrDefaultAsync().ConfigureAwait(true);
//                if (verifyOTP != null)
//                {
//                    if (Convert.ToDateTime(verifyOTP.OTPCreatedDate).AddMinutes(15) >= DateTime.UtcNow)
//                    {
//                        response.Data = null;
//                        response.Message = TKMessages.validateotp;
//                        response.StatusCode = (int)HttpStatusCode.OK;
//                    }
//                    else
//                    {
//                        response.Data = null;
//                        response.Message = TKMessages.expired;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    }
//                }
//                else
//                {
//                    response.Data = null;
//                    response.Message = TKMessages.InvalidOtp;
//                    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                }

//            }
//            else
//            {
//                response.Data = null;
//                response.Message = TKMessages.Otpfailed;
//                response.StatusCode = (int)HttpStatusCode.BadRequest;
//            }

//            return response;
//        }
//        /// <summary>
//        /// ResetPassword
//        /// </summary>
//        /// <param name="resetPasswordModel"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> ResetPassword(ResetPasswordModel resetPasswordModel)
//        {
//            var responseResult = new CommonResponseModel();
//            try
//            {
//                if (resetPasswordModel != null)
//                {
//                    var Resetpassword = await _dbContext.Users.Where(res => res.UserName == resetPasswordModel.UserName).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (Resetpassword != null)
//                    {
//                        Resetpassword.PasswordHash = _userManager.PasswordHasher.HashPassword(Resetpassword, resetPasswordModel.Password);
//                        _dbContext.Update(Resetpassword);
//                        var result = await _dbContext.SaveChangesAsync();
//                        responseResult.Data = null;
//                        responseResult.Message = TKMessages.resetpassword;
//                        responseResult.StatusCode = (int)HttpStatusCode.OK;
//                    }
//                    else
//                    {
//                        responseResult.Data = null;
//                        responseResult.Message = TKMessages.resetfaild;
//                        responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                    }

//                }
//                else
//                {
//                    responseResult.Data = null;
//                    responseResult.Message = TKMessages.resetfaild;
//                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//            }
//            return responseResult;
//        }
//        /// <summary>
//        /// Updateproduct
//        /// </summary>
//        /// <param name="productRequestModel"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> AddUpdateProduct(ProductRequestModel productRequestModel)
//        {
//            var responseResult = new CommonResponseModel();
//            var tblProduct = Mapper.MapData<ProductRequestModel, Product>(productRequestModel);
//            //await _dbContext.Product.AddAsync(tblProduct).ConfigureAwait(false);
//            var result = await _genericProductDAL.Save(tblProduct);

//            // var save = await _dbContext.SaveChangesAsync().ConfigureAwait(false);
//            if (result)
//            {
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.productAdd;
//                responseResult.StatusCode = (int)HttpStatusCode.OK;
//            }
//            else
//            {
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//            }
//            return responseResult;
//        }
//        /// <summary>
//        /// DeleteProduct
//        /// </summary>
//        /// <param name="ProductId"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> DeleteProduct(int ProductId)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                if (ProductId > 0)
//                {
//                    var ProductDeatils = await _dbContext.Product.Where(t => t.Id == ProductId && t.IsDeleted == false).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (ProductDeatils != null)
//                    {
//                        ProductDeatils.IsDeleted = true;
//                        _dbContext.Update(ProductDeatils);
//                        var result = _dbContext.SaveChanges();
//                        if (result > 0)
//                        {
//                            response.Data = null;
//                            response.StatusCode = (int)HttpStatusCode.OK;
//                            response.Message = TKMessages.deleteproduct;
//                        }
//                        else
//                        {
//                            response.Data = null;
//                            response.StatusCode = (int)HttpStatusCode.BadRequest;
//                            response.Message = TKMessages.CommonFailed;
//                        }
//                    }
//                    else
//                    {
//                        response.Data = null;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                        response.Message = TKMessages.alreadydeleteproduct;
//                    }
//                }
//                else
//                {
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    response.Message = TKMessages.CommonFailed;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        /// <summary>
//        /// GetAllProduct
//        /// </summary>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> GetAllProduct()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                response.Data = await _dbContext.Product.Where(res => res.IsDeleted == false).Select(a => new ProductResponseModel()
//                {
//                    Id = a.Id,
//                    FuelType = a.FuelType,
//                    ProductName = a.ProductName,
//                    Price = Convert.ToDecimal(a.Price),
//                }).ToListAsync().ConfigureAwait(false);
//                //response.Data= await(from p in _dbContext.Vehicles
//                //                     join u in _dbContext.Users on p.UserId equals Guid.Parse(u.Id)
//                //                     where !p.IsDeleted
//                //                     select new ProductResponseModel
//                //                     {
//                //                         //Id = u.Id,
//                //                         //VehicleId=p.VehicleId,
//                //                         //UserId=u.Id,
//                //                         //FirstName = u.FirstName,
//                //                         //LastName = u.LastName,
//                //                         //Address = u.Address,
//                //                         //MobileNo = u.MobileNo,
//                //                         //Price = Convert.ToDecimal(a.Price)
//                //                     }).ToListAsync().ConfigureAwait(true);



//                response.StatusCode = (int)(HttpStatusCode.OK);
//                response.Message = TKMessages.productList;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        /// <summary>
//        /// GetAllCustomerPaymentDetails
//        /// </summary>
//        /// <returns></returns>


//        //public async Task<CommonResponseModel> GetAllCustomerPaymentDetails()
//        //{
//        //    CommonResponseModel response = new();
//        //    try
//        //    {
//        //        var route = await (from p in _dbContext.Payment
//        //                           join u in _dbContext.Users on p.Userid equals u.Id
//        //                           join vc in _dbContext.Assignsubscription on p.Userid equals vc.UserId
//        //                           //join sp in _dbContext.Subscriptionplan on vc.PlanId equals sp.Id
//        //                           where p.IsTransactionComplete //&& !vc.CancelPlan
//        //                           select new CustomerPaymentListResponse
//        //                           {
//        //                               FirstName = u.FirstName,
//        //                               LastName = u.LastName,
//        //                               Amount = Convert.ToDouble(p.Amount),
//        //                               // PlanName = sp.PlanName,
//        //                               Date = vc.SubscribeDate.Date
//        //                               //Date=vc.SubscribeDate.Date
//        //                           }).ToListAsync();
//        //        response.Data = route;
//        //        response.Message = "list of payment Details";
//        //        response.StatusCode = (int)HttpStatusCode.OK;
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        _logger.LogError(ex.Message);
//        //        response.Data = null;
//        //        response.Message = "failed";
//        //        response.StatusCode = (int)HttpStatusCode.BadRequest;
//        //    }
//        //    return response;
//        //}



//        public async Task<CommonResponseModel> GetAllCustomerPaymentDetails()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var route = await (from p in _dbContext.Payment
//                                   join u in _dbContext.Users on p.Userid equals u.Id
//                                   //join vc in _dbContext.Assignsubscription on p.Userid equals vc.UserId
//                                   // join sp in _dbContext.Subscriptionplan on vc.PlanId equals sp.Id
//                                   where p.IsTransactionComplete //&& !vc.CancelPlan
//                                   select new CustomerPaymentListResponse
//                                   {
//                                       FirstName = u.FirstName,
//                                       LastName = u.LastName,
//                                       Amount = Convert.ToDouble(p.Amount),
//                                       //PlanName = sp.PlanName,
//                                       Date = p.CreatedOn.Date
//                                       //Date=vc.SubscribeDate.Date
//                                   }).ToListAsync();
//                response.Data = route;
//                response.Message = "list of payment Details";
//                response.StatusCode = (int)HttpStatusCode.OK;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = "failed";
//                response.StatusCode = (int)HttpStatusCode.BadRequest;
//            }
//            return response;
//        }
//        /// <summary>
//        /// AddVehicleBarCode
//        /// </summary>
//        /// <param name="addBarCodeRequestModel"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> AddVehicleBarCode(AddBarCodeRequestModel addBarCodeRequestModel)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var check_vehicleBarcode = (from item in _dbContext.Vehicles where item.BarCode == addBarCodeRequestModel.BarCode select item).ToList();

//                if (check_vehicleBarcode.Count() > 0)
//                {
//                    response.Data = null;
//                    response.Message = "already Exist !";
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                }
//                else
//                {
//                    if (addBarCodeRequestModel.VehicleId > 0)
//                    {
//                        var c = await (from x in _dbContext.Vehicles
//                                 where x.VehicleId == addBarCodeRequestModel.VehicleId
//                                 select x).FirstOrDefaultAsync();
//                        c.BarCode = addBarCodeRequestModel.BarCode;
//                        _dbContext.SaveChanges();

//                        response.Data = null;
//                        response.Message = TKMessages.msgbarcodeadd;
//                        response.StatusCode = (int)HttpStatusCode.OK;
//                    }
//                    else
//                    {
//                        response.Data = null;
//                        response.Message = "failed";
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = "failed";
//                response.StatusCode = (int)HttpStatusCode.BadRequest;
//            }
//            return response;
//        }


//        //public async Task<CommonResponseModel> AddVehicleBarCode(AddBarCodeRequestModel addBarCodeRequestModel)
//        //{
//        //    CommonResponseModel response = new();
//        //    try
//        //    {
//        //        //if (addBarCodeRequestModel.VehicleId > 0)
//        //        //{
//        //        //    var vehicleBarcode = await _dbContext.Vehicles.Where(res => res.VehicleId == addBarCodeRequestModel.VehicleId && !res.IsDeleted).FirstOrDefaultAsync().ConfigureAwait(true);
//        //        //}
//        //        //else
//        //        //{

//        //        //}
//        //        var vehicleBarcode = await _dbContext.Vehicles.Where(res => res.VehicleId == addBarCodeRequestModel.VehicleId && !res.IsDeleted && res.BarCode == null).FirstOrDefaultAsync().ConfigureAwait(true);
//        //        if (vehicleBarcode != null)
//        //        {
//        //            vehicleBarcode.BarCode = addBarCodeRequestModel.BarCode;
//        //            _dbContext.Vehicles.Update(vehicleBarcode);
//        //            _dbContext.SaveChanges();
//        //            response.Data = null;
//        //            response.Message = TKMessages.msgbarcodeadd;
//        //            response.StatusCode = (int)HttpStatusCode.OK;
//        //        }
//        //        else
//        //        {
//        //            response.Data = null;
//        //            response.Message = "failed";
//        //            response.StatusCode = (int)HttpStatusCode.BadRequest;
//        //            //}
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        _logger.LogError(ex.Message);
//        //        response.Data = null;
//        //        response.Message = "failed";
//        //        response.StatusCode = (int)HttpStatusCode.BadRequest;
//        //    }
//        //    return response;
//        //}
//        /// <summary>
//        /// PerStopDeliveryAmount
//        /// </summary>
//        /// <param name="perStopDeliveryAmountRequestModel"></param>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> PerStopDeliveryAmount(PerStopDeliveryAmountRequestModel perStopDeliveryAmountRequestModel)
//        {
//            var responseResult = new CommonResponseModel();
//            try
//            {

//                var Perstopamount = Mapper.MapData<PerStopDeliveryAmountRequestModel, PerStopAmount>(perStopDeliveryAmountRequestModel);
//                var result = await _genericPerStopAmountDAL.Save(Perstopamount);
//                if (result)
//                {
//                    responseResult.Data = null;
//                    responseResult.StatusCode = (int)HttpStatusCode.OK;
//                    responseResult.Message = TKMessages.perstop;
//                }
//                else
//                {
//                    responseResult.Data = null;
//                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                    responseResult.Message = TKMessages.CommonFailed;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }

//            return responseResult;
//        }
//        /// <summary>
//        /// GetALLDeliveryStopAmountDetails
//        /// </summary>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> GetALLDeliveryStopAmountDetails()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                response.Data = await _dbContext.PerStopAmount.Where(res => res.IsDeleted == false).Select(a => new PerStopDeliveryAmountResponseModel()
//                {
//                    StopAmount = Convert.ToDouble(a.StopAmount),
//                }).FirstOrDefaultAsync().ConfigureAwait(false);
//                response.StatusCode = (int)(HttpStatusCode.OK);
//                response.Message = TKMessages.msgliststopamount;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="From"></param>
//        /// <param name="To"></param>
//        /// <returns></returns>

        
//        public async Task<CommonResponseModel> GetCustomerPaymentDetailsDateWise(DateTime From, DateTime To)
//        {
//            CommonResponseModel responseResult = new CommonResponseModel();
//            try
//            {
//                var getPaymentDetails = (from p in _dbContext.Payment
//                                         join u in _dbContext.Users on p.Userid equals u.Id
//                                         join vc in _dbContext.Vehicles on u.Id equals vc.UserId.ToString()
//                                         //join sc in _dbContext.Assignsubscription on vc.UserId.ToString() equals sc.UserId
//                                         orderby p.CreatedOn descending
//                                         where p.IsTransactionComplete && p.CreatedOn.Date <= From && p.CreatedOn.Date >= To && p.VehicleId == vc.VehicleId //&& !vc.CancelPlan
//                                                                                                                                                            // where p.IsTransactionComplete && p.CreatedOn.Date>= From && p.CreatedOn.Date<=To //&& !vc.CancelPlan
//                                         select new CustomerPaymentListResponse
//                                         {

//                                             FirstName = u.FirstName,
//                                             LastName = u.LastName,
//                                             Amount = Convert.ToDouble(p.Amount),
//                                             LicencePlateNumber = vc.LicencePlateNumber,
//                                             Date = p.CreatedOn.Date
//                                         }).ToList();
//                //var getPaymentDetails =  (from p in _dbContext.Payment
//                //                               join u in _dbContext.Users on p.Userid equals u.Id
//                //                               join vc in _dbContext.Vehicles on u.Id equals vc.UserId.ToString() 
//                //                               //join sc in _dbContext.Assignsubscription on vc.UserId.ToString() equals sc.UserId
//                //                               orderby p.CreatedOn descending
//                //                               where p.IsTransactionComplete && p.CreatedOn.Date <= From && p.CreatedOn.Date >= To //&& !vc.CancelPlan
//                //                               // where p.IsTransactionComplete && p.CreatedOn.Date>= From && p.CreatedOn.Date<=To //&& !vc.CancelPlan
//                //                               select new CustomerPaymentListResponse
//                //                               {
//                //                                   FirstName = u.FirstName,
//                //                                   LastName = u.LastName,
//                //                                   Amount = Convert.ToDouble(p.Amount),
//                //                                   LicencePlateNumber=vc.LicencePlateNumber,
//                //                                   Date = p.CreatedOn.Date
//                //                               }).ToList().GroupBy(res=> new { res.LicencePlateNumber }).Select(a=>a.FirstOrDefault()).ToList();
//                //.GroupBy(res => new { res.LicencePlateNumber }).Select(a => a.FirstOrDefault()).ToList();
//                responseResult.Data = getPaymentDetails;
//                responseResult.StatusCode = (int)HttpStatusCode.OK;
//                responseResult.Message = "Get sucessfully !";
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return responseResult;
//        }


//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="From"></param>
//        /// <param name="To"></param>
//        /// <returns></returns>

//        public async Task<CommonResponseModel> CustomerPaymentFailedDateWise(DateTime From, DateTime To)
//        {
//            CommonResponseModel responseResult = new CommonResponseModel();
//            try
//            {
//                var getPaymentDetails = await (from p in _dbContext.Payment
//                                               join u in _dbContext.Users on p.Userid equals u.Id
//                                               orderby p.CreatedOn descending
//                                               where !p.IsTransactionComplete && p.CreatedOn.Date <= From && p.CreatedOn.Date >= To
//                                               // where !p.IsTransactionComplete && p.CreatedOn.Date >= From && p.CreatedOn.Date <= To //&& !vc.CancelPlan
//                                               select new CustomerPaymentListResponse
//                                               {
//                                                   FirstName = u.FirstName,
//                                                   LastName = u.LastName,
//                                                   Amount = Convert.ToDouble(p.Amount),
//                                                   Date = p.CreatedOn.Date
//                                               }).ToListAsync();
//                responseResult.Data = getPaymentDetails;
//                responseResult.StatusCode = (int)HttpStatusCode.OK;
//                responseResult.Message = "Get sucessfully !";
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return responseResult;
//        }

//        //public async Task<CommonResponseModel> GenrateExcleSheetForAcceptedCustomer(DateTime DeliveryDate)
//        //{
//        //    CommonResponseModel response = new();
//        //    try
//        //    {
//        //        //  DataTable dt = getData();
//        //        DataTable dt = new DataTable();

//        //        List<AcceptCustomerDeliveryListResponse> acceptCustomerDeliveries = (from p in _dbContext.CustomerDelivery
//        //                               join u in _dbContext.Users on p.CreatedBy equals u.Id
//        //                               join vc in _dbContext.Vehicles on p.VehicleId equals vc.VehicleId
//        //                               where p.DeliveryDate.Date == DeliveryDate.Date && p.StatusId != 3 && p.IsAccepted == 2
//        //                               select new AcceptCustomerDeliveryListResponse
//        //                               {
//        //                                   FirstName = u.FirstName,
//        //                                   LastName = u.LastName,
//        //                                   Address = u.Address + "," + u.Address1 + "," + u.City + u.State

//        //                               }).ToList<AcceptCustomerDeliveryListResponse>();

//        //        //dt.TableName = "CustomerDetails";

//        //        //dt.Columns.Add("ID", typeof(int));
//        //        //dt.Columns.Add("FirstName", typeof(string));
//        //        //dt.Columns.Add("LastName", typeof(string));
//        //        //dt.Columns.Add("Address", typeof(string));
//        //        //dt.Columns.Add("NoOfVehicles", typeof(string));
//        //        //Add Rows in DataTable

//        //        //dt.Rows.Add(1, "Anoop Kumar Sharma", "Delhi");
//        //        //dt.Rows.Add(2, "Andrew", "U.P.");

//        //       // dt.Rows.Add(1, "Anoop Kumar Sharma", "Delhi");
//        //        //dt.Rows.Add("FirstName", typeof(string));
//        //        //dt.Rows.Add("LastName", typeof(string));
//        //        //dt.Rows.Add("Address", typeof(string));
//        //        //dt.Rows.Add("NoOfVehicles", typeof(string));

//        //       // dt.AcceptChanges();



//        //        //string fileName = "Sample.xlsx";
//        //        //  using (XLWorkbook wb = new XLWorkbook())
//        //        //  {
//        //        //      //Add DataTable in worksheet  
//        //        //      wb.Worksheets.Add(dt);
//        //        //      using (MemoryStream stream = new MemoryStream())
//        //        //      {
//        //        //          wb.SaveAs(stream);
//        //        //          //Return xlsx Excel File  
//        //        //           return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
//        //        //          //return null;
//        //        //      }
//        //        ////  E:\FuelMuleFillUp - ENRG\WebAPI\FuelMuleFillUp.BAL1\FuelMuleFillUp.BAL.csproj
//        //        //  }

//        //        //List<DataTable> dts = dt.AsEnumerable()
//        //        //    .GroupBy(row => row.Field<string>("Ref_ID"))
//        //        //    .Select(g => g.CopyToDataTable()).ToList();

//        //        //string path = "D:\\Excel\\";
//        //        //if (!Directory.Exists(path))
//        //        //{
//        //        //    Directory.CreateDirectory(path);
//        //        //}
//        //        //using (XLWorkbook wb = new XLWorkbook())
//        //        //{
//        //        //    //for (int i = 0; i < dts.Count; i++)
//        //        //    //{
//        //        //    //    if (!string.IsNullOrEmpty(dts[i].Rows[0][0].ToString()))
//        //        //    //    {
//        //        //    //        wb.Worksheets.Add(dts[i], dts[i].Rows[0][0].ToString());
//        //        //    //    }
//        //        //    //}
//        //        //    wb.Worksheets.Add(dt);
//        //        //    wb.SaveAs(path + "OrderDetails.xlsx" + DateTime.UtcNow.Date);
//        //        //}

//        //        //////To day//////
//        //        ///

//        //        StringBuilder sb = new StringBuilder();
//        //        sb.Append("SI No " + ',');
//        //        sb.Append("First Name" + ',');
//        //        sb.Append("Last Name" + ',');
//        //        sb.Append("Address" + ',');

//        //        foreach (var customer in acceptCustomerDeliveries)
//        //        {
//        //            sb.Append(customer.FirstName + ',');
//        //            sb.Append(customer.LastName.ToString() + ',');
//        //            sb.Append(customer.Address + ',');
//        //            sb.Append("\r\n");
//        //        }
//        //        return null;
//        //        //return sb.ToString();

//        //        /////////////




//        //    }
//        //    catch (Exception ex)
//        //    {

//        //        throw;
//        //    }
//        //    return response;
//        //}

//        //------------------------------------

////        DataTable dt = GetData();
////        dt.TableName = "data";  
////            using(XLWorkbook wb = new XLWorkbook())  
////            {  
////                wb.Worksheets.Add(dt);  
////                using(MemoryStream memoryStream = new MemoryStream())  
////                {  
////                    wb.SaveAs(memoryStream);  
////                    byte[] bytes = memoryStream.ToArray();
////        memoryStream.Close();  
////                    using(MailMessage Msg = new MailMessage())  
////                    {  
////                        Msg.From = new MailAddress("YOUR MAIL ID .com");
////        Msg.To.Add(txtTo.Text);  
////                        Msg.Subject = "DATA Exported Excel";  
////                        Msg.Body = "DATA Exported Excel Attachment";  
////                        Msg.Attachments.Add(new Attachment(new MemoryStream(bytes), "DATA.xlsx"));  
////                        Msg.IsBodyHtml = true;  
////                        SmtpClient smtp = new SmtpClient();
////        smtp.Host = "smtp.gmail.com";  
////                        smtp.EnableSsl = true;  
////                        System.Net.NetworkCredential credentials = new System.Net.NetworkCredential();
////        credentials.UserName = "YOUR MAIL ID . com";  
////                        credentials.Password = "YOUR MAIL ID PASSWORD";  
////                        smtp.UseDefaultCredentials = true;  
////                        smtp.Credentials = credentials;  
////                        smtp.Port = 587;  
////                        smtp.Send(Msg);  
////                        MessageBox.Show("MAIL SENT SUCCESSFULLY TO " + txtTo.Text);  
////                        txtTo.Text = "";  
////                    }
////}
//        public async Task<CommonResponseModel> GenrateExcleSheetForAcceptedCustomer(DateTime DeliveryDate)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                DataTable dt = getData(DeliveryDate);
//                string path = "E:\\Excel\\";
//                if (!Directory.Exists(path))
//                {
//                    Directory.CreateDirectory(path);
//                }
//                using (XLWorkbook wb = new XLWorkbook())
//                {
//                    wb.Worksheets.Add(dt);
//                    wb.SaveAs(path + "AcceptedDeliveries.xlsx");//+ DateTime.UtcNow.Date
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                    response.Message = "sucessfully !";
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        public DataTable getData(DateTime DeliveryDate)
//        {
//            DataTable dt = new DataTable();
//            dt.TableName = "EmployeeData";
//            var acceptCustomerDeliveries = (from p in _dbContext.CustomerDelivery
//                                            join u in _dbContext.Users on p.CreatedBy equals u.Id
//                                            join vc in _dbContext.Vehicles on p.VehicleId equals vc.VehicleId
//                                            where p.DeliveryDate.Date == DeliveryDate.Date && p.StatusId != 3 && p.IsAccepted == 2
//                                            select new
//                                            {
//                                                FirstName = u.FirstName,
//                                                LastName = u.LastName,
//                                                Address = u.Address + "," + u.Address1 + "," + u.City + u.State,
//                                                CustomerId = u.Id,
//                                                MobileNo=u.MobileNo,
//                                                VehicleId = vc.VehicleId.ToString(),
//                                                NumberPlate = vc.LicencePlateNumber
//                                            }).ToList().GroupBy(a => a.CustomerId).Select(a => new AcceptCustomerDeliveryListResponse()
//                                            {
//                                                NoOfVehicles = a.Count().ToString(),
//                                                FirstName = a.FirstOrDefault().FirstName,
//                                                LicencePlate = string.Join(",", a.Select(a => a.NumberPlate)),
//                                                LastName=a.FirstOrDefault().LastName,
//                                                Address=a.FirstOrDefault().Address,
//                                                MobileNo=a.FirstOrDefault().MobileNo
//                                            }).ToList();
//            dt.Columns.Add("SI", typeof(int));
//            dt.Columns.Add("FirstName", typeof(string));
//            dt.Columns.Add("LastName", typeof(string));
//            dt.Columns.Add("Address", typeof(string));
//            dt.Columns.Add("NoOfVehicles", typeof(string));
//            dt.Columns.Add("LicencePlates", typeof(string));
//            dt.Columns.Add("MobileNo", typeof(string));
//            if (acceptCustomerDeliveries != null)
//            {
//                int i = 1;
//                foreach (var item in acceptCustomerDeliveries)
//                {
//                    dt.Rows.Add(i, item.FirstName, item.LastName,item.Address,item.NoOfVehicles,item.LicencePlate,item.MobileNo);
//                    i++;
//                }
//            }
//            dt.AcceptChanges();
//            return dt;
//        }

//        public async Task<CommonResponseModel> GetRoll()
//        {
//            CommonResponseModel responseModel = new();
//            try
//            {
//                var getPaymentDetails = (from p in _dbContext.UserRole

//                                         select new AspNetRoleResonse
//                                         {
//                                             Id = p.Id,
//                                             Name = p.Name
//                                         }).ToList();
//                responseModel.Data = getPaymentDetails;
//                responseModel.StatusCode = (int)(HttpStatusCode.OK);
//                responseModel.Message = "Get Roll";
//            }
//            catch (Exception)
//            {

//                throw;
//            }
//            return responseModel;
//        }
//        public async Task<CommonResponseModel> GenrateExcleSheetCustomerPaymentList(DateTime To, DateTime From)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                DataTable dt = GetCustomerPaymentList(To, From);
//                string path = "E:\\PaymentList\\";
//                if (!Directory.Exists(path))
//                {
//                    Directory.CreateDirectory(path);
//                }
//                using (XLWorkbook wb = new XLWorkbook())
//                {
//                    wb.Worksheets.Add(dt);
//                    wb.SaveAs(path + "CustomerPaymentList.xlsx");//+ DateTime.UtcNow.Date
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                    response.Message = "sucessfully !";
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }




//        public DataTable GetCustomerPaymentList(DateTime To, DateTime From)
//        {
//            DataTable dt = new DataTable();
//            dt.TableName = "EmployeeData";
//            var getPaymentDetails = (from p in _dbContext.Payment
//                                          join u in _dbContext.Users on p.Userid equals u.Id
//                                          join vc in _dbContext.Vehicles on u.Id equals vc.UserId.ToString()
//                                          //join sc in _dbContext.Assignsubscription on vc.UserId.ToString() equals sc.UserId
//                                          orderby p.CreatedOn descending
//                                          where p.IsTransactionComplete && p.CreatedOn.Date <= From && p.CreatedOn.Date >= To && p.VehicleId==vc.VehicleId //&& !vc.CancelPlan
//                                                                                                                              // where p.IsTransactionComplete && p.CreatedOn.Date>= From && p.CreatedOn.Date<=To //&& !vc.CancelPlan
//                                          select new CustomerPaymentListResponse
//                                          {
                                             
//                                              FirstName = u.FirstName,
//                                              LastName = u.LastName,
//                                              Amount = Convert.ToDouble(p.Amount),
//                                              LicencePlateNumber = vc.LicencePlateNumber,
//                                              Date = p.CreatedOn.Date
//                                          }).ToList();

//            List<CustomerPaymentListResponse> getPaymentDetails1 = getPaymentDetails.Except(getPaymentDetails.GroupBy(i => i.FirstName).Select(ss => ss.FirstOrDefault())).ToList();
//            //var distinctItems = getPaymentDetails.GroupBy(x => x.FirstName).Select(y=>y.Key).ToList();
//            //List<Employee> duplicateEmployees = employees.Except(employees.GroupBy(i => i.Name)
//            //                                 .Select(ss => ss.FirstOrDefault()))
//            //                                .ToList();

//            //responseResult.Data = getPaymentDetails;
//            //responseResult.StatusCode = (int)HttpStatusCode.OK;
//            //responseResult.Message = "Get sucessfully !";
//            dt.Columns.Add("SI", typeof(int));
//            dt.Columns.Add("FirstName", typeof(string));
//            dt.Columns.Add("LastName", typeof(string));
//            dt.Columns.Add("Amount", typeof(string));
//            dt.Columns.Add("LicencePlateNumber", typeof(string));
//            dt.Columns.Add("Date", typeof(string));
//            if (getPaymentDetails != null)
//            {
//                int i = 1;
//                foreach (var item in getPaymentDetails)
//                {
//                    dt.Rows.Add(i, item.FirstName, item.LastName, item.Amount, item.LicencePlateNumber, item.Date);
//                    i++;
//                }
//            }
//            dt.AcceptChanges();
//            return dt;
//        }

      
//    }
//}





///// GenrateExcleSheetForAcceptedCustomer

////public async Task<CommonResponseModel> GenrateExcleSheetForAcceptedCustomer(DateTime DeliveryDate)
////{
////    CommonResponseModel response = new();
////    try
////    {
////        DataTable dt = getData(DeliveryDate);
////        //DataTable dt = getData(DeliveryDate);

////        //var acceptCustomerDeliveries = await (from p in _dbContext.CustomerDelivery
////        //                                 join u in _dbContext.Users on p.CreatedBy equals u.Id
////        //                                 join vc in _dbContext.Vehicles on p.VehicleId equals vc.VehicleId
////        //                                 where p.DeliveryDate.Date == DeliveryDate.Date && p.StatusId != 3 && p.IsAccepted == 2
////        //                                 select new AcceptCustomerDeliveryListResponse
////        //                                 {
////        //                                     FirstName = u.FirstName,
////        //                                     LastName = u.LastName,
////        //                                     Address = u.Address + "," + u.Address1 + "," + u.City + u.State
////        //                                 }).ToListAsync().ConfigureAwait(true);

////        //dt.TableName = "CustomerDetails";

////        //dt.Columns.Add("ID", typeof(int));
////        //dt.Columns.Add("FirstName", typeof(string));
////        //dt.Columns.Add("LastName", typeof(string));
////        //dt.Columns.Add("Address", typeof(string));
////        //dt.Columns.Add("NoOfVehicles", typeof(string));
////        //Add Rows in DataTable

////        //dt.Rows.Add(1, "Anoop Kumar Sharma", "Delhi");
////        //dt.Rows.Add(2, "Andrew", "U.P.");

////        // dt.Rows.Add(1, "Anoop Kumar Sharma", "Delhi");
////        //dt.Rows.Add("FirstName", typeof(string));
////        //dt.Rows.Add("LastName", typeof(string));
////        //dt.Rows.Add("Address", typeof(string));
////        //dt.Rows.Add("NoOfVehicles", typeof(string));

////        // dt.AcceptChanges();



////        //string fileName = "Sample.xlsx";
////        //  using (XLWorkbook wb = new XLWorkbook())
////        //  {
////        //      //Add DataTable in worksheet  
////        //      wb.Worksheets.Add(dt);
////        //      using (MemoryStream stream = new MemoryStream())
////        //      {
////        //          wb.SaveAs(stream);
////        //          //Return xlsx Excel File  
////        //           return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
////        //          //return null;
////        //      }
////        ////  E:\FuelMuleFillUp - ENRG\WebAPI\FuelMuleFillUp.BAL1\FuelMuleFillUp.BAL.csproj
////        //  }

////        //List<DataTable> dts = dt.AsEnumerable()
////        //    .GroupBy(row => row.Field<string>("Ref_ID"))
////        //    .Select(g => g.CopyToDataTable()).ToList();

////        string path = "D:\\Excel\\";
////        if (!Directory.Exists(path))
////        {
////            Directory.CreateDirectory(path);
////        }
////        using (XLWorkbook wb = new XLWorkbook())
////        {
////            //for (int i = 0; i < dts.Count; i++)
////            //{
////            //    if (!string.IsNullOrEmpty(dts[i].Rows[0][0].ToString()))
////            //    {
////            //        wb.Worksheets.Add(dts[i], dts[i].Rows[0][0].ToString());
////            //    }
////            //}
////            wb.Worksheets.Add(dt);
////            wb.SaveAs(path + "OrderDetails.xlsx");//+ DateTime.UtcNow.Date
////        }

////        //////To day//////
////        ///

////        //StringBuilder sb = new StringBuilder();
////        //sb.Append("SI No " + ',');
////        //sb.Append("First Name" + ',');
////        //sb.Append("Last Name" + ',');
////        //sb.Append("Address" + ',');

////        //foreach (var customer in acceptCustomerDeliveries)
////        //{
////        //    sb.Append(customer.FirstName + ',');
////        //    sb.Append(customer.LastName.ToString() + ',');
////        //    sb.Append(customer.Address + ',');
////        //    sb.Append("\r\n");
////        //}
////        //return null;
////        //return sb.ToString();

////        /////////////

////    }
////    catch (Exception ex)
////    {

////        throw;
////    }
////    return response;
////}
////public DataTable getData(DateTime DeliveryDate)
////{
////    //Creating DataTable  
////    DataTable dt = new DataTable();
////    //Setiing Table Name  

////    dt.TableName = "EmployeeData";


////    var acceptCustomerDeliveries = (from p in _dbContext.CustomerDelivery
////                                    join u in _dbContext.Users on p.CreatedBy equals u.Id
////                                    join vc in _dbContext.Vehicles on p.VehicleId equals vc.VehicleId
////                                    where p.DeliveryDate.Date == DeliveryDate.Date && p.StatusId != 3 && p.IsAccepted == 2
////                                    select new
////                                    {
////                                        FirstName = u.FirstName,
////                                        LastName = u.LastName,
////                                        Address = u.Address + "," + u.Address1 + "," + u.City + u.State,
////                                        CustomerId = u.Id,
////                                        VehicleId = vc.VehicleId.ToString(),
////                                        NumberPlate = vc.LicencePlateNumber
////                                    }).ToList().GroupBy(a => a.CustomerId).Select(a => new AcceptCustomerDeliveryListResponse()
////                                    {
////                                        NoOfVehicles = a.Count().ToString(),
////                                        FirstName = a.FirstOrDefault().FirstName,
////                                        NoPlates = string.Join(",", a.Select(a => a.NumberPlate)),
////                                        LastName = a.FirstOrDefault().LastName,
////                                        Address = a.FirstOrDefault().Address
////                                    }).ToList();

////    //ToList().GroupBy(a => a.CustomerId).Select(a => new AcceptCustomerDeliveryListResponse()
////    //{
////    //    NoOfVehicles = a.Select(aa => aa.VehicleId.Count().ToString()).FirstOrDefault(),
////    //    FirstName = a.FirstOrDefault().FirstName
////    //}).ToList();



////    //  dt.TableName = await _dbContext.CustomerDelivery.Where(res=>res.DeliveryDate.Date==DateTime.UtcNow.Date).ToListAsync();
////    //Add Columns  

////    dt.Columns.Add("ID", typeof(int));
////    dt.Columns.Add("FirstName", typeof(string));
////    dt.Columns.Add("LastName", typeof(string));
////    dt.Columns.Add("Address", typeof(string));
////    dt.Columns.Add("NoOfVehicles", typeof(string));
////    dt.Columns.Add("NumberPlates", typeof(string));


////    if (acceptCustomerDeliveries != null)
////    {
////        int i = 1;
////        foreach (var item in acceptCustomerDeliveries)
////        {
////            dt.Rows.Add(i, item.FirstName, item.LastName, item.Address, item.NoOfVehicles, item.NoPlates);
////            i++;
////        }
////    }

////    dt.AcceptChanges();
////    return dt;
////}