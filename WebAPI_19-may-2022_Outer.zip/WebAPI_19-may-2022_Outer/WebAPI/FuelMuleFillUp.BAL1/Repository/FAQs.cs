﻿
//using AutoMapper.Configuration;
//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Models.ResponseModel;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Net;
//using Microsoft.Extensions.Logging;
//using System.Data;
//using FuelMuleFillUp.Entities.DBTables;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class FAQs : IFAQs
//    {
//        private readonly FuelMuleFillUpContext _dbContext;
//       private readonly ILogger<FAQs> _logger;
//        public FAQs(FuelMuleFillUpContext dbContext, ILogger<FAQs> logger)
//        {
//            _dbContext = dbContext;
//            _logger = logger;
//        }
//        /// <summary>
//        /// ListFAQs
//        /// </summary>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> ListFAQs()
//        {
//            CommonResponseModel commonResponseModel = new();
//            List<FAQsResponseModel> fAQsResponse = new(); //List<FAQsResponseModel>
//            try
//            {
//                var faqDetails = _dbContext.FAQs.ToList();
//                var faqAnswer = _dbContext.FAQAnswer.ToList();
//                fAQsResponse = faqDetails.Select(faqque => new FAQsResponseModel()
//                {
//                    FaqId = faqque.FaqId,
//                    Question = faqque.Question,
//                    Answer = faqAnswer.Where(faqans => faqans.FaqId == faqque.FaqId).Select(faqans => new FAQAnswerDetails()
//                    {
//                        AnswerId = faqans.AnswerId,
//                        Answer = faqans.Answer
//                    }).FirstOrDefault()
//                }).ToList();
//                commonResponseModel.Data = fAQsResponse;
//                commonResponseModel.StatusCode = (int)(HttpStatusCode.OK);
//                commonResponseModel.Message = TKMessages.Faqs;

//            }

//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//            }
//            return commonResponseModel;
//        }

//        public async Task<CommonResponseModel> AddUpdateListFAQs(AddUpdateFAQAnswerDetails ModelFQA) //AddUpdateFAQAnswerDetails
//        {
          

//            CommonResponseModel commonResponseModel = new();

//            try
//            {
                

//                if (ModelFQA.FaqId > 0)
//                {
//                    var faqDetails = _dbContext.FAQs.FirstOrDefault(a => a.FaqId == ModelFQA.FaqId);
//                    var faqAnswer = _dbContext.FAQAnswer.FirstOrDefault(a => a.FaqId == ModelFQA.FaqId);

//                    faqDetails.Question = ModelFQA.Question;
//                    faqAnswer.Answer = ModelFQA.Answer;
//                    _dbContext.SaveChanges();

//                    commonResponseModel.Data = null;
//                    commonResponseModel.Message = "Sucess";
//                    commonResponseModel.StatusCode = (int)HttpStatusCode.OK;

//                }
//                else
//                {
//                    FAQ FAQ = new FAQ();
//                    FAQsAnswer Ans = new FAQsAnswer();

//                    FAQ.Question = ModelFQA.Question;
//                    _dbContext.FAQs.Add(FAQ);
//                    _dbContext.SaveChanges();
//                    var Fid= (from id in _dbContext.FAQs
//                              where id.Question == ModelFQA.Question
//                              select new { id.FaqId }).FirstOrDefault();

//                    Ans.Answer = ModelFQA.Answer;
//                    Ans.FaqId = Fid.FaqId;
                   
//                    _dbContext.FAQAnswer.Add(Ans);
//                    _dbContext.SaveChanges();

//                    commonResponseModel.Data = null;
//                    commonResponseModel.Message = "Sucess Add";
//                    commonResponseModel.StatusCode = (int)HttpStatusCode.OK;


//                }


//            }
//            catch (Exception ex)
//            {

//                throw;
                
//            }
//         return commonResponseModel;
//         }


//        public async Task<CommonResponseModel> RemoveListFAQs(AddUpdateFAQAnswerDetails ModelFQA) {
          
//            CommonResponseModel commonResponseModel = new();
//            try
//            {
//                var FQAdata = await  _dbContext.FAQs.FindAsync(ModelFQA.FaqId);
//                var Aswdata = await  _dbContext.FAQAnswer.FindAsync(ModelFQA.FaqId);
//                if (ModelFQA.FaqId > 0)
//                {
//                    _dbContext.FAQAnswer.Remove(Aswdata);
//                    _dbContext.SaveChanges();
//                    _dbContext.FAQs.Remove(FQAdata);
//                    _dbContext.SaveChanges();
//                    commonResponseModel.Data = null;
//                    commonResponseModel.Message = "Remove Sucess";
//                    commonResponseModel.StatusCode = (int)HttpStatusCode.OK;
//                }
//                else {
//                    commonResponseModel.Data = null;
//                    commonResponseModel.StatusCode = (int)HttpStatusCode.BadRequest;
//                    commonResponseModel.Message = TKMessages.CommonFailed;
//                }
               
//            }
//            catch (Exception ex)
//            {

//                throw;
//            }
//            return commonResponseModel;
//        }

//    }
//}
