﻿using AutoMapper;
using ClosedXML.Excel;
using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.RequestModel;
using FuelMuleFillUp.Models.ResponseModel;
using FuelMuleFillUp.Utilities;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.Repository
{
    public class Admin : IAdmin
    {

        private readonly IAdminDal admin;
        private readonly IMapper mapper;
        private readonly IGenericDAL<RouteDetail> routeDetailGenericDal;
        private readonly IGenericDAL<Product> productGenericDal;
        private readonly IGenericDAL<Faq> faqGenericDal;
        private readonly IGenericDAL<Truck> truckGenericDal;
        private readonly IGenericDAL<ZipCode> zipGenericDal;
        private readonly IGenericDAL<AspNetUser> userGenericDal;
        private readonly IGenericDAL<SubscriptionPlan> subscripGenericDal;
        private readonly IGenericDAL<CustomerDelivery> customerDelGenericDal;
        private readonly ILogger<Admin> _logger;
        private readonly IUserDal userDal;
        public Admin(IAdminDal admin, IMapper mapper, IGenericDAL<RouteDetail> routeDetailGenericDal, IGenericDAL<Product> productGenericDal
            , IGenericDAL<Faq> faqGenericDal, IGenericDAL<Truck> truckGenericDal, IGenericDAL<ZipCode> zipGenericDal, IGenericDAL<AspNetUser> userGenericDal
            , IGenericDAL<SubscriptionPlan> subscripGenericDal, IUserDal userDal, IGenericDAL<CustomerDelivery> customerDelGenericDal, ILogger<Admin> _logger)
        {
            this.admin = admin;
            this.mapper = mapper;
            this.routeDetailGenericDal = routeDetailGenericDal;
            this.productGenericDal = productGenericDal;
            this.faqGenericDal = faqGenericDal;
            this.truckGenericDal = truckGenericDal;
            this.zipGenericDal = zipGenericDal;
            this.subscripGenericDal = subscripGenericDal;
            this.userGenericDal = userGenericDal;
            this.userDal = userDal;
            this.customerDelGenericDal = customerDelGenericDal;
            this._logger = _logger;
        }
        /// <summary>
        /// Get employees - user list without customer
        /// </summary>
        /// <param name="role"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetEmployees(string role, int? userId)
        {
            CommonResponseModel response = new();
            try
            {
                var usersList = mapper.Map<List<UserDto>>(await admin.GetEmployees(role, userId));
                if (usersList != null )
                {
                    response.Data = usersList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Get Route(s)
        /// </summary>
        /// <param name="routeId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetRoutes(int? routeId)
        {
            CommonResponseModel response = new();
            try
            {
                var routes = await admin.GetRoutes(routeId);
                var unassignedUsers = await admin.GetUnassignedUsers();

                if (routes.Count >0)
                {
                    var routesList = routes.Select(x =>
                    {
                        var route = mapper.Map<RouteDetailDto>(x);
                        route.AssignedUsersCount = x.AspNetUsers.Count;
                        route.UnassignedUsersCount = unassignedUsers.Count;
                        return route;
                    }).ToList();

                    response.Data = routesList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// User Registration - save user - customer, employee and driver
        /// </summary>
        /// <param name="route"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddUpdateRoute(RouteDetailDto route)
        {
            CommonResponseModel response = new();
            try
            {
                var existingRoute = await admin.GetRoutesByName(route.RouteName);
                var routeEntity = mapper.Map<RouteDetail>(route);
                if (existingRoute ==null || existingRoute.Id == route.Id)
                {
                    var result = await routeDetailGenericDal.Save(routeEntity);
                    if (result)
                    {
                        response.Data = routeEntity.Id;
                        response.StatusCode = (int)HttpStatusCode.OK;
                        response.Message = TKMessages.Routedeatils;
                    }
                    else
                    {
                        response.Data = routeEntity.Id;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        response.Message = TKMessages.CommonFailed;
                    }
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = "Route already exist please use different route name";
                }
               
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Dete route
        /// </summary>
        /// <param name="routeId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteRoute(int routeId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var routes = await admin.GetRoutes(routeId);
                if (routes != null && routes.Count > 0)
                {
                    var route = routes.FirstOrDefault();
                    route.IsDeleted = true;
                    route.ModifyBy = modifyBy;
                    route.ModifyDate = DateTime.Now;
                    await routeDetailGenericDal.Save(route);
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }
        /// <summary>
        /// Add and update product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddUpdateProduct(ProductDto product)
        {
            CommonResponseModel response = new();
            try
            {
                var productEntity = mapper.Map<Product>(product);
                var result = await productGenericDal.Save(productEntity);
                if (result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Delete Product
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteProduct(int productId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var products = await admin.GetProduct(productId);
                if (products != null && products.Count > 0)
                {
                    var product = products.FirstOrDefault();
                    product.IsDeleted = true;
                    product.ModifyBy = modifyBy;
                    product.ModifyDate = DateTime.Now;
                    await productGenericDal.Save(product);
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Get product list or one product
        /// </summary>
        /// <param name="ProductId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetProduct(int? ProductId)
        {
            CommonResponseModel response = new();
            try
            {
                var product = await admin.GetProduct(ProductId);
                var productList = mapper.Map<List<ProductDto>>(product);
                if (productList != null)
                {
                    response.Data = productList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Get FAQ List
        /// </summary>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetFaqs(int? faqId)
        {
            CommonResponseModel response = new();
            try
            {
                var faqs = await admin.GetFaqs(faqId);
                if (faqs != null)
                {
                    var faqList = faqs.Select(x => new FaqResponseModel()
                    {
                        FaqId = x.FaqId,
                        Question = x.Question,
                        Seq = x.Seq,
                        IsActive = true,
                        CreatedBy=x.CreatedBy,
                        CreatedDate=x.CreatedDate.Date,
                        ModifyBy=x.ModifyBy==0?0:x.ModifyBy,
                        ModifyDate=x.ModifyDate,
                        AnswerId = x.FaqAnswers.FirstOrDefault().AnswerId,
                        Answer = x.FaqAnswers.FirstOrDefault().Answer,
                    }).ToList().OrderBy(x => x.Seq);
                    response.Data = faqList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Save FAQ list
        /// </summary>
        /// <param name="faqs"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> SaveFaq(List<FaqResponseModel> faqs)
        {
            CommonResponseModel response = new();
            try
            {
                var maxSeq = admin.GetMaxSequenceNoFaq();
                List<Faq> faqList = new List<Faq>();
                faqs.ForEach(x =>
                {
                    if (x.Seq == 0)
                    {
                        maxSeq++;
                    }
                    faqList.Add(new Faq()
                    {
                        FaqId = x.FaqId,
                        Question = x.Question,
                        Seq = x.Seq == 0 ? maxSeq : x.Seq,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        FaqAnswers = new List<FaqAnswer>()
                        {
                            new FaqAnswer()
                            {
                                AnswerId = x.AnswerId,
                                Answer = x.Answer,
                                CreatedBy = x.CreatedBy,
                                CreatedDate=DateTime.Now,
                                IsActive=true,
                                IsDeleted=false,
                            }
                        }
                    });
                });
                var data = await faqGenericDal.ListSave(faqList);

                response.Data = data;
                response.StatusCode = (int)HttpStatusCode.OK;
                response.Message = TKMessages.AddUpdate;
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Get Truck list or one truck
        /// </summary>
        /// <param name="truckId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetTruck(int? truckId)
        {
            CommonResponseModel response = new();
            try
            {
                var trucks = await admin.GetTruck(truckId);
                var truckList = mapper.Map<List<TruckDto>>(trucks);
                if (truckList != null && truckList.Count > 0)
                {
                    response.Data = truckList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }

            return response;
        }

        /// <summary>
        /// Add update trucks
        /// </summary>
        /// <param name="truck"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddUpdateTruck(TruckDto truck)
        {
            CommonResponseModel response = new();
            try
            {
                var truckEntity = mapper.Map<Truck>(truck);
                var result = await truckGenericDal.Save(truckEntity);
                if (result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// ZipCode AddUpdate
        /// </summary>
        /// <param name="zip"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddUpdateZipCode(ZipDto zip)
        {
            CommonResponseModel response = new();
            try
            {
                var verifyZip = await admin.ZipCodeVerify(zip);
                if (verifyZip == null)
                {
                    var zipEntity = mapper.Map<ZipCode>(zip);
                    var result = await zipGenericDal.Save(zipEntity);
                    if (result)
                    {
                        response.Data = null;
                        response.StatusCode = (int)HttpStatusCode.OK;
                        response.Message = TKMessages.AddUpdate;
                    }
                    else
                    {
                        response.Data = null;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        response.Message = TKMessages.CommonFailed;
                    }
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = "Zip code already exits";
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Get zip code list or one by id
        /// </summary>
        /// <param name="ZipId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetZip(int? ZipId)
        {
            CommonResponseModel response = new();
            try
            {
                var zip = await admin.GetZip(ZipId);
                var routesList = mapper.Map<List<ZipDto>>(zip);
                if (routesList.Count > 0)
                {
                    response.Data = routesList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Delete Zip Code
        /// </summary>
        /// <param name="subscription"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteZipCode(int ZipId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var zip = await admin.GetZip(ZipId);
                if (zip != null && zip.Count > 0)
                {
                    var zips = zip.FirstOrDefault();
                    zips.IsDeleted = true;
                    zips.ModifyBy = modifyBy;
                    zips.ModifyDate = DateTime.Now;
                    //save/update
                    await zipGenericDal.Save(zips);

                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.DeleteRecord;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Add and update project plan
        /// </summary>
        /// <param name="subscription"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddUpdateSubscription(SubscriptionPlanDto subscription)
        {
            CommonResponseModel response = new();
            try
            {
                var subscripEntity = mapper.Map<SubscriptionPlan>(subscription);
                var result = await subscripGenericDal.Save(subscripEntity);
                if (result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Get Subscription plan list
        /// </summary>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetSubscription(int? subscriptionPlanId, int? customerId)
        {
            CommonResponseModel response = new();
            try
            {
                var subscription = await admin.GetSubscription(subscriptionPlanId, customerId);
                var GetsubscriptionList = mapper.Map<List<SubscriptionPlanDto>>(subscription);

                if (GetsubscriptionList.Count > 0)
                {
                    response.Data = GetsubscriptionList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = "No records found.";
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// AssingRouteCustomer
        /// </summary>
        /// <param name="assignRoute"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AssingRouteCustomer(List<AssignRouteDto> assignRoute)
        {
            CommonResponseModel response = new();
            try
            {
                //update vehicle in aspnetuser
                var usersList = await userDal.GetUsersByIds(assignRoute.Select(x => x.CustomerID).ToArray());
                var users = usersList.Select(x =>
                {
                    bool isAssigned = assignRoute.FirstOrDefault(y => y.CustomerID == x.Id).IsAssign;
                    if (isAssigned)
                    {
                        x.RouteId = assignRoute.FirstOrDefault(y => y.CustomerID == x.Id).RouteID;
                    }
                    else
                    {
                        x.RouteId = null;
                    }
                    x.IsAssign = assignRoute.FirstOrDefault(y => y.CustomerID == x.Id).IsAssign;
                    x.ModifyBy = x.Id;
                    return x;
                }).ToList();

                var res = await userGenericDal.ListSave(users);
                if (res)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// upcoming deliveries
        /// </summary>
        /// <returns></returns>

        public async Task<CommonResponseModel> UpcomingDeliveries()
        {
            var response = new CommonResponseModel();
            var routes = await admin.GetRoutes(null);
            try
            {
                var upcomingDeliveries = await admin.GetUpcomingDeliveries();
                if (routes != null)
                {
                    List<CustomerDelivery> customerDeliveries = new List<CustomerDelivery>();
                    foreach (var route in routes)
                    {
                        var days = route.Days.TrimEnd().Split(" ", StringSplitOptions.None).ToList().Select(x =>
                        {
                            int c = (int)DateTime.Now.DayOfWeek;

                            int offset = (7 - c + (int)Enum.Parse(typeof(Enums.WeekDays), x.Trim().ToLower())) % 7;
                            return DateTime.Now.Date.AddDays(offset == 0 ? 7 : offset);

                        }).ToList();
                        var vehicles = route.AspNetUsers.SelectMany(y => y.Vehicles.Where
                        (x => x.AssignSubscriptions.Any(z => !z.IsDeleted && z.RenewalDate >= DateTime.Now.Date))).ToList();

                        days.ForEach(day =>
                        {
                            customerDeliveries.AddRange(vehicles.Select(veh => new CustomerDelivery()
                            {
                                VehicleId = veh.VehicleId,
                                DeliveryDate = day,
                                StatusId = (int)Enums.Status.Pending,
                                CreatedBy = 1,
                                CreatedDate = DateTime.Now,
                                UserId = veh.AspNetUserId
                            }));
                        });
                    }
                    var newDeliveries = customerDeliveries.Where(x => !upcomingDeliveries.Any(up => up.VehicleId == x.VehicleId && up.DeliveryDate.Date == x.DeliveryDate.Date)).ToList();
                    await customerDelGenericDal.ListSave(newDeliveries);

                    response.Data = newDeliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {

                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;

                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                response.Message = ex.Message;

            }
            return response;

        }



        /// <summary>
        /// Delete SubscrtionPlan
        /// </summary>
        /// <param name="subscriptionPlanId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteSubscrtionPlan(int? subscriptionPlanId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var subscriptionPlans = await admin.GetSubscription(subscriptionPlanId, null);
                var subscriptionPlan = subscriptionPlans.Where(x => x.Id == subscriptionPlanId && !x.IsDeleted).FirstOrDefault();

                subscriptionPlan.IsDeleted = true;
                subscriptionPlan.ModifyBy = modifyBy;
                subscriptionPlan.ModifyDate = DateTime.Now;
                var result = await subscripGenericDal.Save(subscriptionPlan);
                if (result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Delete FAQ
        /// </summary>
        /// <param name="faqId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteFAQ(int faqId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var faqs = await admin.GetFaqs(faqId);

                if (faqs != null && faqs.Count > 0)
                {

                    var faq = faqs.Where(x => x.FaqId == faqId && x.IsDeleted == false && x.IsActive == true).FirstOrDefault();

                    faq.IsDeleted = true;
                    faq.ModifyBy = modifyBy;
                    faq.ModifyDate = DateTime.Now;

                    var result = await faqGenericDal.Save(faq);

                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }


        /// <summary>
        /// Delete Truck
        /// </summary>
        /// <param name="truckId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteTruck(int truckId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var trucks = await admin.GetTruck(truckId);
                if (trucks != null && trucks.Count > 0)
                {
                    var truck = trucks.Where(x => x.TruckId == truckId && x.IsDeleted == false && x.IsActive == true).FirstOrDefault();
                    truck.IsDeleted = true;
                    truck.ModifyBy = modifyBy;
                    truck.ModifyDate = DateTime.Now;
                    await truckGenericDal.Save(truck);
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        public async Task<CommonResponseModel> PaymentListDateWise(DateTime from, DateTime to)
        {

            CommonResponseModel response = new();
            try
            {
                var PaymenyList = mapper.Map<List<PaymentDto>>(await admin.PaymentListDateWise(from, to));
                if (PaymenyList != null)
                {
                    response.Data = PaymenyList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch
            {
                throw;
            }
            return response;

        }

        public async Task<CommonResponseModel> GetStates(int? stateId)
        {
            CommonResponseModel response = new();
            try
            {
                var state = await admin.GetStates(stateId);
                var stateList = mapper.Map<List<StatesDto>>(state);
                if (stateList.Count > 0)
                {
                    response.Data = stateList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        public int GetMaxSequenceNoFaq()
        {
            throw new NotImplementedException();
        }

        public async Task<CommonResponseModel> ZipCodeValidate(string zipCode)
        {
            CommonResponseModel response = new();
            try
            {
                var zip = await admin.ZipCodeValidate(zipCode);
                if (zip != null)
                {
                    response.Data = true;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.zipmsg;
                }
                else
                {
                    response.Data = false;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.ZipMessage;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

       
        public int GetNoOfVehicle()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Activate Inactivate User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> ActiveInactiveUser(int userId, bool activeFlag, int modifiedBy)
        {
            CommonResponseModel response = new();
            try
            {
                var entityUser = (await userDal.GetUsers(null, userId)).FirstOrDefault();
                entityUser.IsActive = activeFlag;
                entityUser.ModifyBy = modifiedBy;
                var res = await userGenericDal.Save(entityUser);
                if (res != null)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;

                    if (entityUser.IsActive == true)
                    {
                        response.Message = TKMessages.Active;
                    }
                    else
                    {
                        response.Message = TKMessages.inactive;
                    }
                }
                else

                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.invalid;

                }
            }
            catch (Exception ex)
            {

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }


        /// <summary>
        /// List Customers With Vehicle Details
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> ListCustomersWithVehicleDetails(int customerId)
        {
            CommonResponseModel response = new();
            try
            {
                var customers = await admin.ListCustomersWithVehicleDetails(customerId);
                if (customers != null)
                {
                    var deliveries = customers.Select(x => new VehicleResponseModel()
                    {
                        VehicleId = x.VehicleId,
                        AspNetUserId = x.AspNetUserId,
                        FirstName = x.AspNetUser.FirstName,
                        LastName = x.AspNetUser.LastName,
                        MobileNo = x.AspNetUser.MobileNo,
                        Address = x.AspNetUser.Address + " " + x.AspNetUser.City + " " + x.AspNetUser.Country,
                        LicencePlateNumber = x.LicencePlateNumber,
                        NoOfVehicles = Convert.ToString(admin.GetNoOfVehicle(customerId)),
                        GateCode = x.GateCode,
                        OtherInstructions = x.OtherInstructions
                    }).ToList();
                    response.Data = deliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }


            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        public int GetNoOfVehicle(int CustomerID)
        {
            throw new NotImplementedException();
        }


    }



}
