﻿//using Microsoft.Extensions.Configuration;
//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Entities.DBTables;
//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Utilities;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Text;
//using System.Threading.Tasks;
//using FuelMuleFillUp.Models.ResponseModel;
//using FuelMuleFillUp.DAL.IDAL;
//using Microsoft.Extensions.Logging;
//using FuelMuleFillUp.Entities;


//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class Route : IRoute
//    {
//        private readonly FuelMuleFillUpContext _dbContext;
//        private readonly ILogger<Route> _logger;
//        private readonly IGenericDAL<RouteDetails> _genericRouteDAL;
//        private readonly IGenericDAL<CustomerRoute> _genericCustomerRouteDAL;
//        private readonly IGenericDAL<Vehicles> _genericVechileDAL;
//        private readonly IGenericDAL<CustomerDelivery> _genericCustomerDeliveryDAL;
//        public Route(FuelMuleFillUpContext dbContext, IGenericDAL<Vehicles> genericVechileDAL, IGenericDAL<CustomerRoute> genericCustomerRouteDAL, IGenericDAL<RouteDetails> genericRouteDAL, ILogger<Route> logger, IGenericDAL<CustomerDelivery> genericCustomerDeliveryDAL) //, , IConfiguration config, UserManager<ApplicationUser> userManager
//        {
//            _dbContext = dbContext;
//            _genericVechileDAL = genericVechileDAL;
//            _genericRouteDAL = genericRouteDAL;
//            _genericCustomerRouteDAL = genericCustomerRouteDAL;
//            _logger = logger;
//            _genericCustomerDeliveryDAL = genericCustomerDeliveryDAL;
//        }
//        /// <summary>
//        /// AddUpdateRouteDetails
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>

//        public async Task<CommonResponseModel> AddUpdateRouteDetails(RouteDetailsModel model)
//        {
//            var responseResult = new CommonResponseModel();
//            try
//            {
//                var Route = Mapper.MapData<RouteDetailsModel, RouteDetails>(model);
//                var result = await _genericRouteDAL.Save(Route);
//                if (result)
//                {
//                    responseResult.Data = Route;
//                    responseResult.StatusCode = (int)HttpStatusCode.OK;
//                    responseResult.Message = TKMessages.Routedeatils;
//                }
//                else
//                {
//                    responseResult.Data = null;
//                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                    responseResult.Message = TKMessages.CommonFailed;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return responseResult;
//        }

//        public async Task<CommonResponseModel> RemoveRouteDetails(int routeId)
//        {

//            var responseResult = new CommonResponseModel();
//            try
//            {
//                var routeverify = _dbContext.RouteDetails.Where(res => res.Id == routeId && !res.IsDeleted).FirstOrDefault();
//                if (routeverify == null)
//                {
//                    responseResult.Data = null;
//                    responseResult.StatusCode = (int)HttpStatusCode.OK;
//                    responseResult.Message = "already deleted route";
//                }
//                else
//                {
//                    var Routedata = await _dbContext.RouteDetails.FindAsync(routeId);
//                    if (Routedata.Id == routeId)
//                    {
//                        Routedata.IsDeleted = true;
//                        _dbContext.RouteDetails.Update(Routedata);
//                        _dbContext.SaveChanges();
//                        responseResult.Data = null;
//                        responseResult.StatusCode = (int)HttpStatusCode.OK;
//                        responseResult.Message = "Remove Sucess";

//                    }
//                    else
//                    {
//                        responseResult.Data = null;
//                        responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                        responseResult.Message = TKMessages.CommonFailed;
//                    }
//                }
//            }
//            catch (Exception)
//            {

//                throw;
//            }

//            return responseResult;
//        }

//        /// <summary>
//        /// GetRouteUnassignedDriverList
//        /// </summary>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> GetRouteUnassignedDriverList()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                response.Data = await (from rol in _dbContext.UserRole
//                                       join ur in _dbContext.Users on rol.Id equals ur.Role
//                                       where rol.Name == "Driver"
//                                       select new DriverListForDropdownResponse()
//                                       {
//                                           Rolname = rol.Name,
//                                           Id = ur.Id,
//                                           Name = ur.FirstName + " " + ur.LastName,
//                                           Address = ur.Address,
//                                           LicenseExpiryDate = ur.LicenseExpiryDate,
//                                           MobileNo = ur.MobileNo,
//                                           LisenseNumber = ur.LisenseNumber
//                                       }).ToListAsync().ConfigureAwait(false);

//                //       response.Data = await _dbContext.Users.Where(res => res.Role == "08a7bfa9-cddf-412b-8b08-2456bc3fe08d").Select(a => new DriverListForDropdownResponse()
//                //       {
//                //           Id = a.Id,
//                //           Name = a.FirstName + " " + a.LastName,
//                //           Address = a.Address,
//                //           LicenseExpiryDate = a.LicenseExpiryDate,
//                //           MobileNo = a.MobileNo,
//                //           LisenseNumber = a.LisenseNumber
//                //       }).ToListAsync().ConfigureAwait(false);
//                response.StatusCode = (int)(HttpStatusCode.OK);
//                response.Message = TKMessages.Faqs;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }

//        /// <summary>
//        /// AddCustomerRoute
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        /// 
//        public async Task<CommonResponseModel> AddCustomerRoute(List<CustomerRouteModel> model)
//        {
//            var responseResult = new CommonResponseModel();
//            try
//            {
//               //var CustomerID= _dbContext.CustomerRoute.Where(x=>x.CustomerId== .CustomerId)

//                if (model != null)
//                {
//                    foreach (var customerRoute in model)
//                    {
//                        //if (_dbContext.CustomerRoute.Any(res => res.RouteId != customerRoute.RouteId && res.CustomerId!=customerRoute.CustomerId))
//                        //{
//                       var CustomerID = _dbContext.CustomerRoute.Where(x => x.CustomerId == customerRoute.CustomerId);
//                        if (CustomerID.Count() > 0)
//                        {
//                            responseResult.Data = null;
//                            responseResult.StatusCode = (int)HttpStatusCode.OK;
//                            responseResult.Message = "already Exist";

//                        }
//                        else { 
                       
//                        CustomerRoute customerRouteModel = new CustomerRoute()
//                        {
//                            CustomerId = customerRoute.CustomerId,
//                            Days = customerRoute.Days,
//                            RouteId = customerRoute.RouteId,
//                            IsAssign = customerRoute.IsAssign = true,

//                        };
//                            _dbContext.CustomerRoute.Add(customerRouteModel);
//                            _dbContext.SaveChanges();
//                            var date = GetNextDate(customerRoute.Days);
                   


//                    if (customerRouteModel.Id > 0)
//                        {
//                            // var vehiclesDetails =await _dbContext.Vehicles.Where(a => a.UserId == Guid.Parse(customerRouteModel.CustomerId)).Select(a => a.VehicleId ).ToListAsync().ConfigureAwait(false);


//                            // var vehiclesDetails = await _dbContext.Vehicles.Where(a => a.UserId == Guid.Parse(customerRouteModel.CustomerId) && !a.IsDeleted).Select(a => a.VehicleId).ToListAsync().ConfigureAwait(false);
//                            var vehiclesDetails = await (from asb in _dbContext.Assignsubscription
//                                                         join veh in _dbContext.Vehicles on asb.vehicleId equals veh.VehicleId
//                                                         select new
//                                                         {
//                                                             veh.VehicleId,
//                                                         }).ToListAsync();

//                            foreach (var item in vehiclesDetails)
//                            {
//                                CustomerDelivery customerDelivery = new CustomerDelivery()
//                                {
//                                    CustomerRouteId = customerRouteModel.RouteId,
//                                    //DeliveryDate= DateTime.UtcNow.AddDays(7),
//                                    // DeliveryDate = DateTime.UtcNow.AddDays(7),
//                                    DeliveryDate = Convert.ToDateTime(date),
//                                    VehicleId = item.VehicleId,
//                                    StatusId = 1,
//                                    IsAccepted = 1,
//                                    IsDeleted = false,
//                                    CreatedBy = customerRouteModel.CustomerId,
//                                    CreatedDate = DateTime.UtcNow
//                                };
//                                _dbContext.CustomerDelivery.Add(customerDelivery);
//                                _dbContext.SaveChanges();
//                                var userDetails = _dbContext.Users.Where(res => res.Id == customerRoute.CustomerId && res.IsNotification).FirstOrDefault();//&& !res.IsNotification
//                                var deviceTokens = _dbContext.UserToken.Where(res => res.UserId == customerRoute.CustomerId).ToList();
//                                if (userDetails != null)
//                                {
//                                    if (deviceTokens != null)
//                                    {
//                                        foreach (var token in deviceTokens)
//                                        {
//                                            //UtilityFunction.SendNotification(token.DeviceToken, customerRoute.CustomerId, 1, userDetails.FirstName,"Message","Delivery");
//                                            UtilityFunction.SendNotification(token.DeviceToken, customerRoute.CustomerId, 1, userDetails.FirstName, "Hi, Your next delivery is Scheduled on" + " " + customerDelivery.DeliveryDate.Date, "Delivery");
//                                        }
//                                    }
//                                }
//                                responseResult.Data = null;
//                                responseResult.StatusCode = (int)HttpStatusCode.OK;
//                                responseResult.Message = TKMessages.routeassigne;
//                            }
//                        }
//                        else
//                        {
//                            responseResult.Data = null;
//                            responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                            responseResult.Message = TKMessages.CommonFailed;
//                        }
//                        //}
//                        //else
//                        //{
//                        //    responseResult.Data = null;
//                        //    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                        //    responseResult.Message = "already assign this customer another route";
//                        //}
//                    }
//                  }
//                }
//                else
//                {
//                    responseResult.Data = null;
//                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                    responseResult.Message = TKMessages.CommonFailed;
//                }

//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return responseResult;
//        }
//        /// <summary>
//        /// CustomerRouteList
//        /// </summary>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> CustomerRouteList()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                response.Data = await _dbContext.RouteDetails.Where(res => res.IsDeleted == false).Select(a => new CustomerRouteListResponse()
//                {
//                    RouteId = a.Id,
//                    RouteName = a.RouteName,
//                    SourceAddress = a.SourceAddress,
//                    DestinationAddress = a.DestinationAddress,
//                    DeliveryType = a.DeliveryType

//                }).ToListAsync().ConfigureAwait(false);
//                response.StatusCode = (int)(HttpStatusCode.OK);
//                response.Message = TKMessages.route;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }

//        /// <summary>
//        /// GetRouteassignedCustomerList
//        /// </summary>
//        /// <returns></returns>
//        public async Task<CommonResponseModel> GetRouteAssignedCustomerList()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var data = await (from vc in _dbContext.Vehicles
//                                  join cd in _dbContext.Users on vc.UserId.ToString()! equals cd.Id
//                                  join cr in _dbContext.CustomerRoute on cd.Id! equals cr.CustomerId into USR
//                                  from usd in USR.DefaultIfEmpty()
//                                  where cd.Id != usd.CustomerId && vc.IsDeleted == false
//                                  select new CustomerListWithVehicleResponse()
//                                  {
//                                      Id = cd.Id,
//                                      FirstName = cd.FirstName,
//                                      LastName = cd.LastName,
//                                      Address = cd.Address,
//                                      Address1 = cd.Address1,
//                                      City = cd.City,
//                                      Country = cd.Country,
//                                      //  RouteId=
//                                      NoOfVehicles = _dbContext.Vehicles.Where(a => a.UserId == vc.UserId && a.IsDeleted == false).Select(a => a.VehicleId).Count()
//                                  }).ToListAsync().ConfigureAwait(false);


//                response.Data = data.GroupBy(a => a.Id).Select(aa => aa.First()).ToList();
//                response.Message = TKMessages.RouteSchedule;
//                response.StatusCode = (int)HttpStatusCode.OK;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }

//        //public async Task<CommonResponseModel> AssignedRouteList1(int routeId)
//        //{ 
//        // CommonResponseModel response = new();
//        //    try
//        //    {

//        //        if (_dbContext.CustomerRoute.Any(res => res.RouteId != routeId))
//        //        {
//        //            response.Data = null;
//        //            response.StatusCode = (int)HttpStatusCode.BadRequest;
//        //            response.Message = "Route NotFound";
//        //        }
//        //        else
//        //        {
//        //            var data = _dbContext.CustomerRoute.Where(x => x.RouteId == routeId).FirstOrDefault();
//        //            if (data.RouteId.ToString().Count() > 0)
//        //            {
//        //                response.Data = null;
//        //                response.StatusCode = (int)HttpStatusCode.OK;
//        //                response.Message = "Already Assigned  Route Another";
//        //            }
//        //            else { 

//        //            }
//        //            if (data.RouteId == routeId)
//        //            {
//        //                var assingRoute = (from Item in _dbContext.CustomerRoute
//        //                                   join cd in _dbContext.Users on Item.CustomerId equals cd.Id
//        //                                   where Item.RouteId == routeId && Item.IsAssign
//        //                                   select new
//        //                                   {
//        //                                       Item.CustomerId,
//        //                                       Item.Days,
//        //                                       cd.FirstName,
//        //                                       cd.Email,
//        //                                       Item.RouteId,
//        //                                       IsAssign = Item.IsAssign
//        //                                   }).ToList();

//        //                response.Data = assingRoute;
//        //                response.StatusCode = (int)HttpStatusCode.OK;
//        //                response.Message = "Route Assigned Sucessfull";

//        //            }
//        //            else
//        //            {
//        //                var UnassingRoute = (from Item in _dbContext.CustomerRoute
//        //                                     join cd in _dbContext.Users on Item.CustomerId equals cd.Id
//        //                                     where Item.IsAssign==false
//        //                                     select new
//        //                                     {
//        //                                         Item.CustomerId,
//        //                                         Item.Days,
//        //                                         cd.FirstName,
//        //                                         cd.Email,
//        //                                         Item.RouteId
//        //                                     }).ToList();

//        //                response.Data = UnassingRoute;
//        //                response.StatusCode = (int)HttpStatusCode.OK;
//        //                response.Message = "Route Not Assigned";
//        //            }
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {

//        //        throw;
//        //    }

//        // return response;
//        //}

//        private DateTime? GetNextDate(string DaysString)
//        {
//            //List<Date> Days = DaysString.Split(',').Select(a => new Date()
//            List<Date> Days = DaysString.Split(' ').Select(a => new Date()
//            {
//                Day = a,
//                Index = (a.Trim() == "Monday" ? 1 : a.Trim() == "Tuesday" ? 2 : a.Trim() == "Wednesday" ? 3 : a.Trim() == "Thursday" ? 4 : a.Trim() == "Friday" ? 5 : a.Trim() == "Saturday" ? 6 : a.Trim() == "Sunday" ? 7 : 0)
//            }).OrderBy(a => a.Index).ToList();
//            DateTime? next_day = null;
//            Date datename;
//            switch (DateTime.UtcNow.ToString("dddd"))
//            {
//                case "Monday":
//                    datename = Days.Where(a => a.Index > 1).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 1));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 1).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index + 6));
//                        }
//                    }
//                    break;
//                case "Tuesday":
//                    datename = Days.Where(a => a.Index > 2).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 2));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 2).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index + 5));
//                        }
//                    }
//                    break;
//                case "Wednesday":
//                    datename = Days.Where(a => a.Index > 3).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 3));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 3).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index + 4));
//                        }
//                    }
//                    break;
//                case "Thursday":
//                    datename = Days.Where(a => a.Index > 4).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 4));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 4).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index + 3));
//                        }
//                    }
//                    break;
//                case "Friday":
//                    datename = Days.Where(a => a.Index > 5).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 5));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 5).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index + 2));
//                        }
//                    }
//                    break;
//                case "Saturday":
//                    datename = Days.Where(a => a.Index > 6).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 6));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 6).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index + 1));
//                        }
//                    }
//                    break;
//                case "Sunday":
//                    datename = Days.Where(a => a.Index > 7).FirstOrDefault();
//                    if (datename != null)
//                    {
//                        next_day = DateTime.UtcNow.AddDays((datename.Index - 7));
//                    }
//                    else
//                    {
//                        datename = Days.Where(a => a.Index <= 7).FirstOrDefault();
//                        if (datename != null)
//                        {
//                            next_day = DateTime.UtcNow.AddDays((datename.Index));
//                        }
//                    }
//                    break;
//            }
//            return next_day;
//        }
//        private class Date
//        {
//            public int Index { get; set; }
//            public string Day { get; set; }
//        }

//        //public async Task<CommonResponseModel> AssignedRouteList(int routeId)
//        //{
//        //    CommonResponseModel response = new();
//        //    try
//        //    {
//        //        if (_dbContext.CustomerRoute.Any(res => res.RouteId == routeId))
//        //        {
//        //            var allRoute = (from Item in _dbContext.CustomerRoute
//        //                            join vc in _dbContext.Vehicles on Item.CustomerId equals vc.UserId.ToString()
//        //                            join ur in _dbContext.Users on Item.CustomerId equals ur.Id
//        //                            select new
//        //                            {
//        //                                cd.FirstName,
//        //                                cd.LastName,
//        //                                vc.VehicleId,
//        //                                vc.MakeName,
//        //                                Item.IsAssign,
//        //                                Item.RouteId,
//        //                                ur.FirstName,
//        //                                ur.LastName
//        //                            }).Where(x => x.RouteId == routeId || x.IsAssign).ToList();


//        //            response.Data = allRoute;
//        //            response.StatusCode = (int)HttpStatusCode.OK;
//        //            response.Message = "sucess";
//        //        }
//        //        else
//        //        {
//        //            var uservehicle = (from vc in _dbContext.Vehicles
//        //                               join cr in _dbContext.CustomerRoute on vc.UserId.ToString()! equals cr.CustomerId
//        //                               select new
//        //                               {
//        //                                   vc.VehicleId,
//        //                                   vc.LicencePlateNumber
//        //                               }).ToList();


//        //            var assingRoute = (from Item in _dbContext.CustomerRoute
//        //                               join cd in _dbContext.Vehicles on Item.CustomerId != cd.user
//        //                               select new
//        //                               {
//        //                                   Item.CustomerId,
//        //                                   Item.Days,
//        //                                   cd.FirstName,
//        //                                   cd.Email,
//        //                                   Item.RouteId,
//        //                                   Item.IsAssign
//        //                               }).ToList();

//        //            response.Data = uservehicle;
//        //            response.StatusCode = (int)HttpStatusCode.BadGateway;
//        //            response.Message = "Not Assigned any customer this route";
//        //        }

//        //    }
//        //    catch (Exception ex)
//        //    {

//        //        throw;
//        //    }

//        //    return response;
//        //}


//        public async Task<CommonResponseModel> AssignedRouteList(int routeId)  //List<CustomerRouteModel> model
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                //select U.FirstName, U.PhoneNumber from[AspNetUsers] U LEFT JOIN CustomerRoute C on U.Id = c.CustomerId
//                //INNER JOIN AspNetRoles R ON R.Id = U.Role
//                //where--R.Name = 'Customer' and
//                //C.RouteId = @RouteId-- and R.Id = 3
//                //
//                //UNION ALL
//                //
//                //select U.FirstName, U.PhoneNumber from[AspNetUsers] U LEFT JOIN CustomerRoute C on U.Id = c.CustomerId
//                //where U.Id
//                //NOT IN(select U.Id from[AspNetUsers] U INNER JOIN CustomerRoute C on U.Id = c.CustomerId
//                //INNER JOIN AspNetRoles R ON R.Id = U.Role WHERE R.Name = 'Customer')

//                //var routeDetails = await (from ur in _dbContext.Users

//                //                           join cr in _dbContext.CustomerRoute on ur.Id equals cr.CustomerId
//                //                          where cr.RouteId == routeId
//                //                          select new
//                //                          {
//                //                              Id = ur.Id,
//                //                              FirstName = ur.FirstName,
//                //                              LastName = ur.LastName,
//                //                              Address = ur.Address,
//                //                              Address1 = ur.Address1,
//                //                              City = ur.City,
//                //                              Country = ur.Country,
//                //                              routeId = cr.RouteId

//                //                          }).ToListAsync();



//                var routeDetails = await (from ur in _dbContext.Users
                                         
//                                          join cr in _dbContext.CustomerRoute on ur.Id equals cr.CustomerId
//                                          where cr.RouteId == routeId
//                                          select new
//                                          {
//                                              Id = ur.Id,
//                                              FirstName = ur.FirstName,
//                                              LastName = ur.LastName,
//                                              Address = ur.Address,
//                                              Address1 = ur.Address1,
//                                              City = ur.City,
//                                              Country = ur.Country,
//                                              routeId=cr.RouteId
                                        
//                                          }).ToListAsync();

//                var UsreID = await (from cr in _dbContext.CustomerRoute
//                                    where cr.RouteId == routeId
//                                    select new
//                                    {
//                                        cr.CustomerId
//                                    }).FirstOrDefaultAsync();


//                var UserData = await (from ur in _dbContext.Users
                                   
//                                      where ur.Id != UsreID.CustomerId
//                                      select new
//                                      {
//                                          Id = ur.Id,
//                                          FirstName = ur.FirstName,
//                                          LastName = ur.LastName,
//                                          Address = ur.Address,
//                                          Address1 = ur.Address1,
//                                          City = ur.City,
//                                          Country = ur.Country,
//                                       }).ToListAsync();

//                var result = new { routeDetails = routeDetails, UserData = UserData };
               

//                response.Data = result;
//                response.Message = TKMessages.success;
//                response.StatusCode = (int)HttpStatusCode.OK;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//            }

//            return response;

//        }

//        public async Task<CommonResponseModel> DeleteCustomerRoute(string CustomerID)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                var CustomerRoute = _dbContext.CustomerRoute.Where(res => res.CustomerId == CustomerID).FirstOrDefault();
//                if (CustomerRoute != null)
//                {
//                    _dbContext.CustomerRoute.Remove(CustomerRoute);
//                    _dbContext.SaveChanges();
//                    response.Data = null;
//                    response.Message = "sucess";
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                }
//                else
//                {
//                    response.Data = null;
//                    response.Message = TKMessages.CommonFailed;
//                    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                }
//            }
//            catch (Exception ex)
//            {

//                throw ex;
//            }
//            return response;

//        }

//        public async Task<CommonResponseModel> AssingCustomerRoute(ApplicationUser model)
//        {
//            CommonResponseModel response = new();
          
//            try
//            {
//                var RouteDetail = _dbContext.Users.FirstOrDefault(a=>a.Id==model.Id);
//                if (RouteDetail != null)
//                {

//                    RouteDetail.RouteId = model.RouteId;
//                    RouteDetail.IsAssign = model.IsAssign;
//                    //RouteDetail.Days = model.Days;
//                    _dbContext.SaveChanges();

//                    response.Data = null;
//                    response.Message = "Sucess";
//                    response.StatusCode = (int)HttpStatusCode.OK;

//                }
//                else
//                {

//                    response.Data = null;
//                    response.Message = TKMessages.CommonFailed;
//                    response.StatusCode = (int)HttpStatusCode.OK;
//                }
//            }
//            catch (Exception ex)
//            {

//                throw;
//            }

//            return response;

//        }




//    }
//}
