﻿using AutoMapper;
using ClosedXML.Excel;
using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.ResponseModel;
using FuelMuleFillUp.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.Repository
{
    public class Customer : ICustomer
    {
        private readonly IVehicleDal vehicleDal;
        private readonly IGenericDAL<Vehicle> vehicleGenericDal;
        private readonly IMapper mapper;
        private readonly ICustomerDal customerDal;
        private readonly IAdminDal admin;
        private readonly IConfiguration _config;
        private readonly IGenericDAL<OrderDetail> orderGenericDal;
        private readonly IGenericDAL<CustomerDelivery> customerDeliverytGenericDal;
        private readonly IGenericDAL<AssignSubscription> assignedSubsGenericDal;
        private readonly ISubscriptionDal subscriptionDal;
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
        private readonly ILogger<Customer> _logger;

        public Customer(IVehicleDal vehicleDal, IGenericDAL<Vehicle> vehicleGenericDal, IMapper mapper, ICustomerDal customerDal
            , IGenericDAL<OrderDetail> orderGenericDal, IGenericDAL<CustomerDelivery> customerDeliverytGenericDal, ISubscriptionDal subscriptionDal
            , IGenericDAL<AssignSubscription> assignedSubsGenericDal, FuelMuleFillUpENRGQAContext _dbContext, IConfiguration _config, ILogger<Customer> _logger, IAdminDal admin)
        {
            this.vehicleDal = vehicleDal;
            this.vehicleGenericDal = vehicleGenericDal;
            this.mapper = mapper;
            this.admin = admin;
            this.customerDal = customerDal;
            this.orderGenericDal = orderGenericDal;
            this.customerDeliverytGenericDal = customerDeliverytGenericDal;
            this.subscriptionDal = subscriptionDal;
            this.assignedSubsGenericDal = assignedSubsGenericDal;
            this._dbContext = _dbContext;
            this._config = _config;
            this._logger = _logger;
        }

        /// <summary>
        /// Get vehicles
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetVehicles(int? userId, int? vehicleId)
        {
            CommonResponseModel response = new();
            try
            {
                var vehicles = await vehicleDal.GetVehicles(userId, vehicleId);
                if (vehicles != null && vehicles.Count > 0)
                {
                    var deliveries = vehicles.Select(x => new VehicleResponseModel()
                    {
                        VehicleId = x.VehicleId,
                        AspNetUserId = x.AspNetUserId,
                        FirstName = x.AspNetUser.FirstName,
                        LastName = x.AspNetUser.LastName,
                        ProductName = x.Product.ProductName,
                        Products = x.Product.ProductName + " " + x.Product.FuelType,
                        ProductId = x.ProductId,
                        LicencePlateNumber = x.LicencePlateNumber,
                        ParkingNumber = x.ParkingNumber,
                        BarCode = x.BarCode,
                        Color = x.Color,
                        MakeName = x.MakeName,
                        TankSize = x.TankSize,
                        ModelName = x.ModelName,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        ModifyBy = x.ModifyBy,
                        ModifyDate = x.ModifyDate,
                        ImageUrl = x.ImageUrl,
                        GateCode = x.GateCode,
                        OtherInstructions = x.OtherInstructions
                    }).ToList();

                    response.Data = deliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;

                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Add and update Vehicles
        /// </summary>
        /// <param name="vehicle"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddUpdateVehicle(VehicleDto vehicle)
        {
            CommonResponseModel response = new();
            try
            {
                var vehicleEntity = mapper.Map<Vehicle>(vehicle);
                var result = await vehicleGenericDal.Save(vehicleEntity);
                if (result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Delete vehicle
        /// </summary>
        /// <param name="vehicleId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteVehicle(int vehicleId, int modifyBy)
        {
            CommonResponseModel response = new();
            try
            {
                var routes = await vehicleDal.GetVehicles(null, vehicleId);
                var route = routes.FirstOrDefault();
                route.IsDeleted = true;
                route.ModifyBy = modifyBy;
                route.ModifyDate = DateTime.Now;

                var result = await vehicleGenericDal.Save(route);
                if (result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);

            }
            return response;
        }

        /// <summary>
        /// Get customer deliveries
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetCustomerUpcomingDeliveries(int? customerId)
        {
            CommonResponseModel response = new();
            try
            {
                var customerDeliveries = await customerDal.GetCustomerUpcomingDeliveries(customerId);
                if (customerDeliveries != null && customerDeliveries.Count > 0)
                {
                    var deliveries = customerDeliveries.Select(x => new UpcommingCustomer()
                    {
                        VehicleId = x.VehicleId,
                        LicencePlateNumber = x.Vehicle.LicencePlateNumber,
                        TankSize = x.Vehicle.TankSize,
                        DeliveryDate = x.DeliveryDate,
                        StatusId = x.Status.Id,
                        DeliveryStatus = x.Status.StatusName
                    }).ToList();
                    response.Data = deliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Get customer deliveries
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetCustomerDeliveriesForDate(DateTime deliveryDate, int? userId)
        {
            CommonResponseModel response = new();
            try
            {

                var customerDeliveries = await customerDal.GetCustomerDeliveriesForDate(deliveryDate, userId);
                if (customerDeliveries != null && customerDeliveries.Count > 0)
                {
                    var deliveries = customerDeliveries.Select(x => new CustomerDeliveryResponseModel()
                    {
                        DeliveryId = x.Id,
                        LicencePlateNumber = x.Vehicle.LicencePlateNumber,
                        TankSize = x.Vehicle.TankSize,
                        StatusId = x.StatusId,
                        Status = x.Status.StatusName,
                        CustomerName = x.User.FirstName + " " + x.User.LastName,
                        MobileNumber = x.User.MobileNo,
                        Address = x.User.Address + " " + x.User.Address1 + " " + x.User.City + " " + x.User.State + " " + x.User.ZipCode,
                        DeliveryDate = x.DeliveryDate,
                        NumberOfVehicles = 1

                    }).ToList();
                    response.Data = deliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch (Exception ex)
            {

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Accept Delivery
        /// </summary>
        /// <param name="deliveryId"></param>
        /// <param name="actionId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AcceptCustomerDelivery(int deliveryId, int actionId)
        {
            CommonResponseModel response = new();
            try
            {
                //change by rishabh included vehicle and product
                var getCustomerDelivery = await customerDal.GetCustomerDeliveryById(deliveryId);

                if (getCustomerDelivery != null && deliveryId > 0)
                {
                    getCustomerDelivery.StatusId = actionId;

                    getCustomerDelivery.ModifyDate = DateTime.UtcNow;
                    getCustomerDelivery.ModifyBy = getCustomerDelivery.ModifyBy;

                    var result = await customerDeliverytGenericDal.Save(getCustomerDelivery);


                    if (result)
                    {
                        response.Data = getCustomerDelivery;
                        response.StatusCode = (int)HttpStatusCode.OK;
                        response.Message = TKMessages.Deliverystatus;
                    }
                    else
                    {
                        response.Data = null;
                        response.Message = TKMessages.ErrorMessage;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                    }
                }
                else
                {
                    response.Data = null;
                    response.Message = TKMessages.ErrorMessage;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }

            }
            catch (Exception ex)
            {

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Add Orders
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddOrder(OrderDetailDto order)
        {
            CommonResponseModel response = new();
            try
            {
                var orderEntity = mapper.Map<OrderDetail>(order);
                var result = await orderGenericDal.Save(orderEntity);
                //var changeStatus = await customerDal.OrderStatus(order);
                if(result)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.msgorder;
                }
                var cust = await _dbContext.CustomerDeliveries.Where(res => res.UserId == order.UserId && res.VehicleId == order.VehicleId && res.DeliveryDate.Date == order.CreatedDate.Date).FirstOrDefaultAsync();
                if (cust != null)
                {
                     cust.StatusId = 3;
                    _dbContext.CustomerDeliveries.Update(cust);
                    //var flag = _dbContext.SaveChanges();
                    //if (flag > 0)
                    //{
                    //    response.Data = flag;
                    //    response.StatusCode = (int)HttpStatusCode.OK;
                    //    response.Message = TKMessages.msgorder;
                    //}
                    //else
                    //{
                    //    response.Data = null;
                    //    response.StatusCode = (int)HttpStatusCode.OK;
                    //    response.Message = TKMessages.CommonFailed;
                    //}
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Customer past deliveries
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetCustomerPastDeliveries(int? customerId)
        {
            CommonResponseModel response = new();
            try
            {
                var customerDeliveries = await customerDal.GetCustomerPastDeliveries(customerId);
                if (customerDeliveries != null && customerDeliveries.Count > 0)
                {
                    response.Data = customerDeliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Assign subscription plan
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="planId"></param>
        /// <param name="vehicleId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AssignSubscriptionPlan(int userId, int planId, int vehicleId)
        {
            CommonResponseModel response = new();
            try
            {
                var plan = await subscriptionDal.GetPlans(planId);
                var assignedPlans = await subscriptionDal.GetAssignedSubscriptionByUserId(userId);

                var assignSubscription = new AssignSubscription()
                {
                    AspNetUserId = userId,
                    PlanId = planId,
                    VehicleId = vehicleId,
                    SubscribeDate = DateTime.Now.Date,
                    IsPlanSelected = true,
                    RenewalDate = DateTime.Now.Date.AddDays(plan.FirstOrDefault().SubscriptionDays),
                    SubscribeAmount = assignedPlans.Any(x => x.PlanId == planId) ? plan.FirstOrDefault().Amount / 2 : plan.FirstOrDefault().Amount,
                    IsPrimary = !assignedPlans.Any()
                };
                var result = await assignedSubsGenericDal.Save(assignSubscription);
                if (result)
                {
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// GetPlan(int userId, int vehicleId, int PlanId)
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="vehicleId"></param>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> CancelPlan(int userId, int vehicleId, int PlanId)
        {

            CommonResponseModel response = new();
            try
            {
                var plans = await subscriptionDal.GetPlan(userId, vehicleId, PlanId);
                if (plans != null && plans.Count > 0)
                {
                    var plan = plans.FirstOrDefault();
                    plan.CancelPlan = true;
                    var result = await assignedSubsGenericDal.Save(plan);
                    if (result)
                    {
                        response.Data = true;
                        response.StatusCode = (int)HttpStatusCode.OK;
                        response.Message = TKMessages.Cancel;
                    }
                    else
                    {
                        response.Data = true;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        response.Message = TKMessages.CommonFailed;
                    }
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// GetAssignSubscriptionPlanUserId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetAssignSubscriptionPlanUserId(int userId)
        {
            CommonResponseModel response = new();
            try
            {
                var customerDeliveries = await subscriptionDal.GetAssignedSubscriptionByUserId(userId); //GetAssignedSubscriptionByUserId GetAssignSubscriptionPlanUserId
                if (customerDeliveries != null && customerDeliveries.Count > 0)
                {
                    response.Data = customerDeliveries;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotPlan;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// ResetPassword
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="confirmPassword"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> ResetPassword(string username, string password, string confirmPassword)
        {
            CommonResponseModel response = new();
            try
            {
                var resetpwd = await customerDal.ResetPassword(username, password, confirmPassword);
                if (resetpwd != null)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.Reset;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// OtpSend
        /// </summary>
        /// <param name="username"></param>
        /// <param name="emailSettings"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> OtpSend(string username, EmailSettings emailSettings)
        {
            CommonResponseModel response = new();
            try
            {
                var resetpwd = await customerDal.OtpSend(username, emailSettings);
                if (resetpwd != null)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.OTP;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.CommonFailed;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// VerifyOtp
        /// </summary>
        /// <param name="username"></param>
        /// <param name="otp"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> VerifyOtp(string username, string otp)
        {
            CommonResponseModel response = new();
            try
            {
                var verifyOtp = await customerDal.VerifyOtp(username, otp);
                if (verifyOtp != null)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.VerifyOtp;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.InvalidOtp;
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// CustomersSubscriptionPlanList
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> CustomersSubscriptionPlanList(int userId)
        {
            CommonResponseModel response = new();
            try
            {
                response.Data=  await customerDal.CustomersSubscriptionPlanList(userId);
                response.StatusCode = (int)HttpStatusCode.OK;
                response.Message = "Data found";
                // response.Data = customerPlan;
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;

        }

        /// <summary>
        /// AddUpdateBarCode
        /// </summary>
        /// <param name="VehicleId"></param>
        /// <param name="BarCode"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AssignBarCode(int VehicleId, string BarCode, int modifiedBy)
        {
            CommonResponseModel response = new();
            try
            {
                var assignvehicle = await customerDal.AssignBarCode(VehicleId, BarCode, modifiedBy);

                response = assignvehicle;

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// GetBarCodeLicense
        /// </summary>
        /// <param name="BarCoderId"></param>
        /// <param name="licenseId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetBarCodeLicense(string BarCoderId, string licenseId)
        {
            CommonResponseModel response = new();
            try
            {
                var vehicles = await vehicleDal.GetBarCodeLicense(BarCoderId, licenseId);
                if (vehicles != null)
                {
                    var deliveries = vehicles.Select(x => new VehicleResponseModel()
                    {
                        VehicleId = x.VehicleId,
                        AspNetUserId = x.AspNetUserId,
                        FirstName = x.AspNetUser.FirstName,
                        LastName = x.AspNetUser.LastName,
                        ProductName = x.Product.ProductName,
                        Products = x.Product.ProductName + " " + x.Product.FuelType,
                        ProductId = x.ProductId,
                        LicencePlateNumber = x.LicencePlateNumber,
                        ParkingNumber = x.ParkingNumber,
                        BarCode = x.BarCode,
                        Color = x.Color,
                        MakeName = x.MakeName,
                        TankSize = x.TankSize,
                        ModelName = x.ModelName,
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                        ModifyBy = x.ModifyBy,
                        ModifyDate = x.ModifyDate,
                        ImageUrl = x.ImageUrl,
                        GateCode = x.GateCode,
                        OtherInstructions = x.OtherInstructions
                    }).ToList();
                    if (deliveries != null)
                    {
                        response.Data = deliveries;
                        response.StatusCode = (int)HttpStatusCode.OK;
                        response.Message = TKMessages.GetData;
                    }
                    else
                    {
                        response.Data = null;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        response.Message = TKMessages.NotExist;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// SendCustomerReferralCode
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> SendCustomerReferralCode(int customerId, string email)
        {
            try
            {
                CommonResponseModel response = new();
                var sendref = await customerDal.SendCustomerReferralCode(customerId, email);
                var res = sendref.ReferralCode;
                var name = sendref.FirstName + " " + sendref.LastName;
                var emailid = email;
                EmailSettings emailSettings = new();
                emailSettings.Email = _config.GetValue<string>("EmailConfiguration:From");
                emailSettings.Password = _config.GetValue<string>("EmailConfiguration:Password");
                emailSettings.Host = _config.GetValue<string>("EmailConfiguration:ServerAddress");
                emailSettings.Port = _config.GetValue<int>("EmailConfiguration:ServerPort");
                UtilityFunction function = new();
                EmailInfo emailInfo = new();
                emailInfo.EmailTo = emailid;
                emailInfo.Subject = "Send Referral Code";
                emailInfo.Body = TKMessages.Registrationmessage + res;
                function.SendCustomerReferralCode(emailInfo, emailSettings, res, name);

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.OK;
                response.Message = TKMessages.Faqs;
                return response;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Genetea excel for scheduled delivery.
        /// </summary>
        /// <param name="deliveryDate"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GenrateExcleSheetForAcceptedCustomer(DateTime deliveryDate)
        {
            CommonResponseModel response = new();
            try
            {
                DataTable dt = await getData(deliveryDate);
                string path = "E:\\Excel\\";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                using (XLWorkbook wb = new XLWorkbook())
                {
                    wb.Worksheets.Add(dt);
                    wb.SaveAs(path + "AcceptedDeliveries.xlsx");//+ DateTime.UtcNow.Date
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = "AcceptedCustomer";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                response.Data = null;
                response.Message = TKMessages.CommonFailed;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }
            return response;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="DeliveryDate"></param>
        /// <returns></returns>
        public async Task<DataTable> getData(DateTime DeliveryDate)
        {
            DataTable dt = new DataTable();
            dt.TableName = "EmployeeData";
            var acceptedCustomerDeliveries = await customerDal.GetCustomerDeliveriesForDate(DeliveryDate, null);
            dt.Columns.Add("SI", typeof(int));
            dt.Columns.Add("FirstName", typeof(string));
            dt.Columns.Add("LastName", typeof(string));
            dt.Columns.Add("Address", typeof(string));
            dt.Columns.Add("LicencePlates", typeof(string));
            dt.Columns.Add("MobileNo", typeof(string));
            if (acceptedCustomerDeliveries != null)
            {
                int i = 1;
                foreach (var item in acceptedCustomerDeliveries)
                {
                    dt.Rows.Add(i, item.User.FirstName, item.User.LastName, item.User.Address + " " + " " + item.User.Address1 + " " + item.User.City + " " + item.User.State + " " + item.User.Country + " " + item.User.ZipCode, item.Vehicle.LicencePlateNumber, item.User.MobileNo);
                    i++;
                }
            }
            dt.AcceptChanges();
            return dt;
        }
        public async Task<CommonResponseModel> GenrateExcleSheetCustomerPaymentList(DateTime From, DateTime To)
        {
            CommonResponseModel response = new();
            try
            {
                DataTable dt = await GetCustomerPaymentList(From, To);
                // string path = "E:\\PaymentList\\";
                string path = "E:\\PaymentList\\";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                using (XLWorkbook wb = new XLWorkbook())
                {
                    wb.Worksheets.Add(dt);
                    wb.SaveAs(path + "CustomerPaymentList.xlsx");//+ DateTime.UtcNow.Date
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = "CustomerPaymentList";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                response.Data = null;
                response.Message = TKMessages.CommonFailed;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }
            return response;
        }
        public async Task<DataTable> GetCustomerPaymentList(DateTime To, DateTime From)
        {
            DataTable dt = new DataTable();
            dt.TableName = "EmployeeData";
            var acceptedCustomerDeliveries = await admin.PaymentListDateWise(To, From);
            dt.Columns.Add("SI", typeof(int));
            dt.Columns.Add("FirstName", typeof(string));
            dt.Columns.Add("LastName", typeof(string));
            dt.Columns.Add("Amount", typeof(string));
            dt.Columns.Add("LicencePlateNumber", typeof(string));
            dt.Columns.Add("PaymentType", typeof(string));
            dt.Columns.Add("Date", typeof(string));
            if (acceptedCustomerDeliveries != null)
            {
                int i = 1;
                foreach (var item in acceptedCustomerDeliveries)
                {
                    dt.Rows.Add(i, item.AspNetUser.FirstName, item.AspNetUser.LastName, item.Amount, item.Vehicle.LicencePlateNumber, item.PaymentType, item.CreatedDate);
                    i++;
                }
            }
            dt.AcceptChanges();
            return dt;
        }
    }
}
