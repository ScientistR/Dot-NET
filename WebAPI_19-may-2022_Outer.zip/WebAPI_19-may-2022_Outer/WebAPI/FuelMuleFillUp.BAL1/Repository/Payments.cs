﻿using AuthorizeNet.Api.Contracts.V1;
using AuthorizeNet.Api.Controllers;
using AuthorizeNet.Api.Controllers.Bases;
using AutoMapper.Configuration;
using Microsoft.EntityFrameworkCore;
using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.ResponseModel;
using FuelMuleFillUp.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;

namespace FuelMuleFillUp.BAL.Repository
{


    public class Payments : IPayment
    {
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
       // private readonly IPaymentDal payment;
        private readonly IGenericDAL<Entities.Models.Payment> paymentGenericDal;
        public Payments(IGenericDAL<Entities.Models.Payment> paymentGenericDal, FuelMuleFillUpENRGQAContext _dbContext)
        {
            this._dbContext = _dbContext;
            //this.payment = payment;
            this.paymentGenericDal = paymentGenericDal;
        }
        //For internal testing
        string loginkey = "4g958CR43y3";
        string TransactionKey = "62833h5Sbza63CYq";
        //--------------------------

        //Client Authorize Crendital
        // string loginkey = "4En5V2uG6jB";
        // string TransactionKey = "4tFW4QA6a577y32R";
        //------------------
        public object Id { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> CreateCustomerPaymentProfile(AuthorizePayment model)
        {
            CommonResponseModel responseModel = new CommonResponseModel();
            try
            {
                var userDetails = await _dbContext.AspNetUsers.Where(res => res.Id == model.customerId).FirstOrDefaultAsync();
                if (userDetails != null)
                {
                    if (string.IsNullOrEmpty(userDetails.AuthorizeCustomerProfileId))
                    {
                        ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;

                        ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                        {
                            ItemElementName = ItemChoiceType.transactionKey,
                            name = loginkey,
                            Item = TransactionKey,
                        };
                        var creditCard = new creditCardType
                        {
                            cardNumber = model.CardNumber,
                            expirationDate = model.expirationDate,
                            cardCode = model.CVV

                            //cardNumber = strDecryptedCard,
                            //expirationDate = strDecryptedDate,
                            //cardCode = strDecryptedCVV
                        };
                        // standard api call to retrieve response
                        paymentType cc = new paymentType { Item = creditCard };
                        List<customerPaymentProfileType> paymentProfileList = new();
                        customerPaymentProfileType ccPaymentProfile = new customerPaymentProfileType();
                        ccPaymentProfile.payment = cc;
                        ccPaymentProfile.defaultPaymentProfile = model.IsDefoult;
                        paymentProfileList.Add(ccPaymentProfile);
                        //paymentProfileList.Add(echeckPaymentProfile);
                        List<customerAddressType> addressInfoList = new List<customerAddressType>();
                        customerAddressType homeAddress = new customerAddressType();
                        homeAddress.address = model.Address1;
                        //  homeAddress.address = model.Address2;
                        homeAddress.state = model.State;
                        homeAddress.city = model.city;
                        homeAddress.zip = model.zip;
                        addressInfoList.Add(homeAddress);
                        customerProfileType customerProfile = new customerProfileType();
                        customerProfile.merchantCustomerId = "Test CustomerID";
                        customerProfile.email = model.Email;
                        customerProfile.paymentProfiles = paymentProfileList.ToArray();
                        customerProfile.shipToList = addressInfoList.ToArray();
                        var request = new createCustomerProfileRequest { profile = customerProfile, validationMode = validationModeEnum.none };
                        // instantiate the controller that will call the service
                        var controller = new createCustomerProfileController(request);
                        controller.Execute();
                        // get the response from the service (errors contained if any)
                        createCustomerProfileResponse response = controller.GetApiResponse();

                        if (response != null)
                        {
                            if (response.customerProfileId != null)
                            {
                                if (response != null)
                                {
                                    userDetails.AuthorizeCustomerProfileId = response.customerProfileId;
                                    //_dbContext.Users.Update(userDetails);
                                    _dbContext.Entry(userDetails).State = EntityState.Modified;
                                    var result = _dbContext.SaveChanges();
                                    if (result > 0)
                                    {
                                        //responseModel.Message = "Success Customer Profile Id" + " " + ccPaymentProfile.payment.Item.;
                                        responseModel.Message = "Success Customer Profile Id" + " " + response.customerProfileId;
                                        responseModel.StatusCode = (int)HttpStatusCode.OK;
                                    }
                                    else
                                    {
                                        responseModel.Message = "Something went wrong";
                                        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                                    }
                                }
                                else
                                {
                                    if (controller.GetErrorResponse().messages.message.Length > 0)
                                    {
                                        responseModel.Message = "Customer Profile Creation Failed.";
                                        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Null Response.");
                                    }
                                }
                            }
                            else
                            {
                                responseModel.Message = response.messages.message[0].text;
                                responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                            }
                        }
                        else
                        {
                            responseModel.Message = "Something went wrong";
                            responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                        }
                    }

                    else
                    {
                        responseModel.Message = "Profile Already created";
                        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                    }
                    // }

                }
            }

            catch (Exception ex)
            {
                //_logger.LogError(ex.Message);
                responseModel.Message = TKMessages.CommonFailed;
                responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
            }
            return responseModel;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetCustomerCardDetails(int customerId)
        {
            CommonResponseModel responseModel = new CommonResponseModel();
            try
            {
                var userDetails = await _dbContext.AspNetUsers.Where(res => res.Id == customerId).FirstOrDefaultAsync();
                if (userDetails.AuthorizeCustomerProfileId != null)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                    // define the merchant information (authentication / transaction id)
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                    {
                        // name = "879zTPAvA5T",
                        ItemElementName = ItemChoiceType.transactionKey,
                        //Item = "4a8dc9HtG39m58PE",
                        name = loginkey,
                        Item = TransactionKey,
                        // name = name1,
                        // Item = Item1,
                    };

                    var request = new getCustomerProfileRequest();
                    request.customerProfileId = userDetails.AuthorizeCustomerProfileId;

                    // instantiate the controller that will call the service
                    var controller = new getCustomerProfileController(request);
                    controller.Execute();

                    // get the response from the service (errors contained if any)
                    var response = controller.GetApiResponse();
                    AuthorizeGetCustomerProfileResponse test = new AuthorizeGetCustomerProfileResponse();
                    if (response != null)
                    {
                        Profile test1 = new Profile();
                        PaymentProfile paymentProfile = new PaymentProfile();
                        List<CreditCard> lstPaymentProfile = new List<CreditCard>();
                        test1.customerProfileId = response.profile.customerProfileId;
                        foreach (var item in response.profile.paymentProfiles)
                        {
                            CreditCard card = new();
                            card.customerProfileId = item.customerPaymentProfileId;
                            card.cardNumber = ((AuthorizeNet.Api.Contracts.V1.creditCardMaskedType)item.payment.Item).cardNumber;//["cardNumber"].value.ToString();
                            card.expirationDate = ((AuthorizeNet.Api.Contracts.V1.creditCardMaskedType)item.payment.Item).expirationDate;//["cardNumber"].value.ToString();
                            card.cardType = ((AuthorizeNet.Api.Contracts.V1.creditCardMaskedType)item.payment.Item).cardType;//["cardNumber"].value.ToString();
                            card.isDefault = response.profile.paymentProfiles.Count() > 1 ? item.defaultPaymentProfile : true;
                            lstPaymentProfile.Add(card);
                        }
                        test1.email = response.profile.email;
                        test1.merchantCustomerId = response.profile.merchantCustomerId;
                        test.creditCard = lstPaymentProfile;
                        //test.profile.paymentProfiles = lstPaymentProfile;
                        responseModel.Data = lstPaymentProfile;
                        responseModel.Message = "Get Customer profile  Successfully";
                        responseModel.StatusCode = (int)HttpStatusCode.OK;
                    }
                    else
                    {
                        responseModel.Data = null;
                        responseModel.Message = TKMessages.CommonFailed;
                        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                    }
                }
            }
            catch (Exception ex)
            {
                // _logger.LogError(ex.Message);
                responseModel.Data = null;
                responseModel.Message = TKMessages.CommonFailed;
                responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
            }
            return responseModel;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> AddNewCard(AddCustomerCardDetails model)
        {
            CommonResponseModel responseModel = new CommonResponseModel();
            try
            {
                var profiledetails = await _dbContext.AspNetUsers.Where(a => a.Id == model.customerId).FirstOrDefaultAsync();
                if (profiledetails != null)
                {
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                    // define the merchant information (authentication / transaction id)
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                    {
                        //name = "879zTPAvA5T",
                        ItemElementName = ItemChoiceType.transactionKey,
                        // Item = "4a8dc9HtG39m58PE",
                        name = loginkey,
                        Item = TransactionKey,
                        // name = name1,
                        // Item = Item1,
                    };
                    var creditCard = new creditCardType
                    {
                        //cardNumber = model.cardNumber,
                        //expirationDate = model.expirationDate.ToString(),
                        //cardCode = model.cvv.ToString()
                        cardNumber = model.cardNumber,
                        expirationDate = model.expirationDate,
                        cardCode = model.cvv

                    };
                    paymentType echeck = new paymentType { Item = creditCard };
                    customerPaymentProfileType echeckPaymentProfile = new customerPaymentProfileType();
                    echeckPaymentProfile.payment = echeck;
                    //echeckPaymentProfile.billTo = billTo;
                    echeckPaymentProfile.defaultPaymentProfile = model.defaultPaymentProfile;
                    var request = new createCustomerPaymentProfileRequest
                    {
                        customerProfileId = profiledetails.AuthorizeCustomerProfileId,
                        paymentProfile = echeckPaymentProfile,
                        validationMode = validationModeEnum.none
                    };
                    // instantiate the controller that will call the service
                    var controller = new createCustomerPaymentProfileController(request);
                    controller.Execute();
                    // get the response from the service (errors contained if any)
                    createCustomerPaymentProfileResponse response = controller.GetApiResponse();
                    if (response != null)
                    {
                        if (response.messages.resultCode == messageTypeEnum.Ok)
                        {
                            if (response.messages.message != null)
                            {
                                responseModel.Message = "Customer payment profile created successfull!";
                                responseModel.StatusCode = (int)HttpStatusCode.OK;
                            }
                        }
                        else
                        {
                            responseModel.Message = "Customer Payment Profile Creation Failed.";
                            responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                            if (response.messages.message[0].code == "E00039")
                            {
                                responseModel.Message = ("Duplicate Payment Profile ID: " + response.customerPaymentProfileId);
                            }
                        }
                    }
                    else
                    {
                        if (controller.GetErrorResponse().messages.message.Length > 0)
                        {
                            responseModel.Message = "Customer Payment Profile Creation Failed.";
                            responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                        }
                        else
                        {
                            //Console.WriteLine(TKMessages.Msgnull);
                        }
                    }

                }
                //}
                else
                {
                    responseModel.Message = "Customer Payment Profile Creation Failed.";
                    responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return responseModel;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paymentDetailsByCardIdRequest"></param>
        /// <returns></returns>
        //public async Task<CommonResponseModel> CustomerPayment(CustomerPayment paymentDetailsByCardIdRequest)
        //{
        //    CommonResponseModel responseModel = new();
        //    try
        //    {
        //        var transactionId = string.Empty;
        //        var isTransactionComplete = false;

        //        if (_dbContext.AssignSubscriptions.Any(ass => ass.AspNetUserId == paymentDetailsByCardIdRequest.userId && ass.PlanId == paymentDetailsByCardIdRequest.PlanId && ass.VehicleId == paymentDetailsByCardIdRequest.vehicleId && !ass.CancelPlan && ass.RenewalDate > DateTime.UtcNow)) //ass.PlanId == assign.PlanId && ass.vehicleId == assign.VehicleId &&
        //        {
        //            responseModel.Data = null;
        //            responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
        //            responseModel.Message = "already subscribe";
        //        }
        //        else
        //        {
        //            var verifyCustomerProfile = _dbContext.AspNetUsers.Where(rec => rec.Id == paymentDetailsByCardIdRequest.userId).FirstOrDefault();
        //            if (verifyCustomerProfile != null)
        //            {
        //                // Console.WriteLine("Charge Customer Profile");

        //                ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;

        //                // define the merchant information (authentication / transaction id)
        //                ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
        //                {
        //                    ItemElementName = ItemChoiceType.transactionKey,
        //                    name = loginkey,
        //                    Item = TransactionKey,
        //                };

        //                //create a customer payment profile
        //                customerProfilePaymentType profileToCharge = new customerProfilePaymentType();
        //                profileToCharge.customerProfileId = verifyCustomerProfile.AuthorizeCustomerProfileId;
        //                profileToCharge.paymentProfile = new paymentProfile { paymentProfileId = paymentDetailsByCardIdRequest.ProfileId };
        //                var transactionRequest = new transactionRequestType
        //                {
        //                    transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),
        //                    amount = paymentDetailsByCardIdRequest.Amount,
        //                    profile = profileToCharge

        //                };
        //                var request = new createTransactionRequest { transactionRequest = transactionRequest };

        //                // instantiate the collector that will call the service
        //                var controller = new createTransactionController(request);
        //                controller.Execute();

        //                // get the response from the service (errors contained if any)
        //                var response = controller.GetApiResponse();

        //                // validate response
        //                if (response != null)
        //                {
        //                    if (response.messages.resultCode == messageTypeEnum.Ok)
        //                    {
        //                        if (response.transactionResponse.messages != null)
        //                        {
        //                            transactionId = response.transactionResponse.transId;
        //                            isTransactionComplete = true;
        //                            //responseModel.Message = TKMessages.paymentstatus;
        //                            //responseModel.Data = null;
        //                            //responseModel.StatusCode = (int)HttpStatusCode.OK;
        //                        }
        //                        else
        //                        {
        //                            isTransactionComplete = false;
        //                            Console.WriteLine("Failed Transaction.");
        //                            if (response.transactionResponse.errors != null)
        //                            {
        //                                Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
        //                                Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
        //                            }
        //                        }

        //                        var TransactionId = response.transactionResponse.transId;

        //                        //responseModel.Message = TKMessages.paymentstatus;
        //                        //responseModel.Data = null;
        //                        //responseModel.StatusCode = (int)HttpStatusCode.OK;
        //                        // await payment.SavePaymentDetails(paymentDetailsByCardIdRequest);
        //                        payment1 payment = new payment1();
        //                        // payment.Amount = Convert.ToDecimal(paymentDetailsByCardIdRequest.Amount);
        //                        payment.Amount = Convert.ToDouble(paymentDetailsByCardIdRequest.Amount);
        //                        payment.TransactionId = response.transactionResponse.transId;
        //                         //payment.TransactionId = "00";
        //                       //  payment.VehicleId = paymentDetailsByCardIdRequest.vehicleId;
        //                         payment.Userid = paymentDetailsByCardIdRequest.userId;
        //                         payment.ModifyBy = paymentDetailsByCardIdRequest.userId;
        //                         payment.CreatedBy = paymentDetailsByCardIdRequest.userId;
        //                         payment.CreatedOn = DateTime.UtcNow;
        //                         payment.ModifyOn = DateTime.UtcNow;
        //                         payment.IsTransactionComplete = isTransactionComplete;

        //                        var paymentEntity = mapper.Map<Payment>(payment);

        //                        var result = await paymentGenericDal.Save(paymentEntity);
        //                        //_dbContext.Payment.Add(payment);
        //                        //_dbContext.SaveChanges();
        //                        //var result = _dbContext.SaveChanges();
        //                        if (result !=null)
        //                        {
        //                            responseModel.Message = TKMessages.paymentstatus;
        //                            responseModel.Data = payment;
        //                            responseModel.StatusCode = (int)HttpStatusCode.OK;
        //                        }
        //                        else
        //                        {
        //                            responseModel.Message = TKMessages.invalid;
        //                            responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        Console.WriteLine("Failed");
        //                        if (response.transactionResponse != null && response.transactionResponse.errors != null)
        //                        {
        //                            Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
        //                            Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
        //                        }
        //                        else
        //                        {
        //                            Console.WriteLine("Error Code: " + response.messages.message[0].code);
        //                            Console.WriteLine("Error message: " + response.messages.message[0].text);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    Console.WriteLine("Null Response.");
        //                }
        //            }

        //            else
        //            {
        //                responseModel.Message = TKMessages.CommonFailed;
        //                responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        //_logger.LogError(ex.Message);
        //        responseModel.Message = TKMessages.CommonFailed;
        //        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
        //    }
        //    return responseModel;
        //}
        string strDecryptedCard;
        string strDecryptedDate;
        string strDecryptedCVV;

        public void GetDecrypted(AuthorizePayment model)
        {
            string Decryptedcard = model.CardNumber;
            string Decrypteddate = model.expirationDate;
            string Decryptedcvv = (model.CVV).ToString();
            //Get values from mobile
            strDecryptedCard = DecryptCard(Decryptedcard, "36523");
            strDecryptedDate = DecryptDate(Decrypteddate, "36523");
            strDecryptedCVV = DecryptCVV(Decryptedcvv, "36523");

        }

        ///Decrypt Customer Card Details
        ///
        public static string DecryptCard(string strEncrypted, string strKey)
        {
            try
            {
                TripleDESCryptoServiceProvider objDESCrypto = new TripleDESCryptoServiceProvider();
                MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();

                byte[] byteHash, byteBuff;
                string strTempKey = strKey;

                byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(strTempKey));
                objHashMD5 = null;
                objDESCrypto.Key = byteHash;
                objDESCrypto.Mode = CipherMode.ECB;

                byteBuff = Convert.FromBase64String(strEncrypted);
                string strDecryptedCard = ASCIIEncoding.ASCII.GetString(objDESCrypto.CreateDecryptor().TransformFinalBlock(byteBuff, 0, byteBuff.Length));
                objDESCrypto = null;

                return strDecryptedCard;
            }
            catch (Exception ex)
            {
                return "Wrong Input. " + ex.Message;
            }
        }
        public static string DecryptDate(string strEncrypted, string strKey)
        {
            try
            {
                TripleDESCryptoServiceProvider objDESCrypto = new TripleDESCryptoServiceProvider();
                MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();

                byte[] byteHash, byteBuff;
                string strTempKey = strKey;

                byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(strTempKey));
                objHashMD5 = null;
                objDESCrypto.Key = byteHash;
                objDESCrypto.Mode = CipherMode.ECB;

                byteBuff = Convert.FromBase64String(strEncrypted);
                string strDecryptedDate = ASCIIEncoding.ASCII.GetString(objDESCrypto.CreateDecryptor().TransformFinalBlock(byteBuff, 0, byteBuff.Length));
                objDESCrypto = null;

                return strDecryptedDate;
            }
            catch (Exception ex)
            {
                return "Wrong Input. " + ex.Message;
            }
        }
        public static string DecryptCVV(string strEncrypted, string strKey)
        {
            try
            {
                TripleDESCryptoServiceProvider objDESCrypto = new TripleDESCryptoServiceProvider();
                MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();

                byte[] byteHash, byteBuff;
                string strTempKey = strKey;

                byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(strTempKey));
                objHashMD5 = null;
                objDESCrypto.Key = byteHash;
                objDESCrypto.Mode = CipherMode.ECB;

                byteBuff = Convert.FromBase64String(strEncrypted);
                string strDecryptedCVV = ASCIIEncoding.ASCII.GetString(objDESCrypto.CreateDecryptor().TransformFinalBlock(byteBuff, 0, byteBuff.Length));
                objDESCrypto = null;

                return strDecryptedCVV;
            }
            catch (Exception ex)
            {
                return "Wrong Input. " + ex.Message;
            }
        }
        public async Task<CommonResponseModel> CustomerPayment(CustomerPayment paymentDetailsByCardIdRequest)
        {
            CommonResponseModel responseModel = new();
            try
            {
                var transactionId = string.Empty;
                var isTransactionComplete = false;

                if (_dbContext.AssignSubscriptions.Any(ass => ass.AspNetUserId == paymentDetailsByCardIdRequest.userId && ass.PlanId == paymentDetailsByCardIdRequest.PlanId && ass.VehicleId == paymentDetailsByCardIdRequest.vehicleId && !ass.CancelPlan && ass.RenewalDate > DateTime.UtcNow)) //ass.PlanId == assign.PlanId && ass.vehicleId == assign.VehicleId &&
                {
                    responseModel.Data = null;
                    responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                    responseModel.Message = "already subscribe";
                }
                else
                {
                    var verifyCustomerProfile = _dbContext.AspNetUsers.Where(rec => rec.Id == paymentDetailsByCardIdRequest.userId).FirstOrDefault();
                    if (verifyCustomerProfile != null)
                    {
                        // Console.WriteLine("Charge Customer Profile");

                        ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;

                        // define the merchant information (authentication / transaction id)
                        ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                        {
                            ItemElementName = ItemChoiceType.transactionKey,
                            name = loginkey,
                            Item = TransactionKey,
                        };

                        //create a customer payment profile
                        customerProfilePaymentType profileToCharge = new customerProfilePaymentType();
                        profileToCharge.customerProfileId = verifyCustomerProfile.AuthorizeCustomerProfileId;
                        profileToCharge.paymentProfile = new paymentProfile { paymentProfileId = paymentDetailsByCardIdRequest.ProfileId };
                        var transactionRequest = new transactionRequestType
                        {
                            transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),
                            amount = Convert.ToDecimal(paymentDetailsByCardIdRequest.Amount),
                            profile = profileToCharge

                        };
                        var request = new createTransactionRequest { transactionRequest = transactionRequest };

                        // instantiate the collector that will call the service
                        var controller = new createTransactionController(request);
                        controller.Execute();

                        // get the response from the service (errors contained if any)
                        var response = controller.GetApiResponse();

                        // validate response
                        if (response != null)
                        {
                            if (response.messages.resultCode == messageTypeEnum.Ok)
                            {
                                if (response.transactionResponse.messages != null)
                                {
                                    transactionId = response.transactionResponse.transId;
                                    isTransactionComplete = true;
                                }
                                else
                                {
                                    isTransactionComplete = false;
                                    Console.WriteLine("Failed Transaction.");
                                    if (response.transactionResponse.errors != null)
                                    {
                                        Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
                                        Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
                                    }
                                }
                                Entities.Models.Payment payment = new Entities.Models.Payment();
                                payment.Amount = Convert.ToDouble(paymentDetailsByCardIdRequest.Amount);
                                payment.TransactionId = response.transactionResponse.transId;
                                payment.VehicleId = paymentDetailsByCardIdRequest.vehicleId;
                                payment.AspNetUserId = paymentDetailsByCardIdRequest.userId;
                                payment.ModifyBy = paymentDetailsByCardIdRequest.userId;
                                payment.CreatedBy = paymentDetailsByCardIdRequest.userId;
                                payment.PaymentType = paymentDetailsByCardIdRequest.PaymentType;
                                payment.CreatedDate = DateTime.UtcNow;
                                payment.ModifyDate = DateTime.UtcNow;
                                payment.IsTransactionComplete = isTransactionComplete;
                                var result = await paymentGenericDal.Save(payment);
                                if (result)
                                {
                                    responseModel.Message = TKMessages.paymentstatus;
                                    responseModel.Data = null;
                                    responseModel.StatusCode = (int)HttpStatusCode.OK;
                                }
                                else
                                {
                                    responseModel.Data = null;
                                    responseModel.Message = "Payment Failed";
                                    responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Failed");
                                if (response.transactionResponse != null && response.transactionResponse.errors != null)
                                {
                                    Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
                                    Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
                                }
                                else
                                {
                                    Console.WriteLine("Error Code: " + response.messages.message[0].code);
                                    Console.WriteLine("Error message: " + response.messages.message[0].text);
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Null Response.");
                        }
                    }

                    else
                    {
                        responseModel.Message = TKMessages.CommonFailed;
                        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return responseModel;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> DeleteCustomerCard(DeleteCustomerCard model)
        {
            CommonResponseModel responseModel = new();
            try
            {
                var userDetails = await _dbContext.AspNetUsers.Where(res => res.Id == model.UserID).FirstOrDefaultAsync();
                if (userDetails != null)
                {

                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
                    ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
                    {
                        // name = "879zTPAvA5T",
                        ItemElementName = ItemChoiceType.transactionKey,
                        //  Item = "4a8dc9HtG39m58PE",
                        //name = loginkey,
                        //Item = TransactionKey,
                        //  name = name1,
                        //  Item = Item1,
                        name = loginkey,
                        Item = TransactionKey,

                    };
                    //please update the subscriptionId according to your sandbox credentials
                    var request = new deleteCustomerPaymentProfileRequest
                    {
                        customerProfileId = userDetails.AuthorizeCustomerProfileId,
                        customerPaymentProfileId = model.ProfileID
                    };

                    //Prepare Request
                    var controller = new deleteCustomerPaymentProfileController(request);
                    controller.Execute();

                    //Send Request to EndPoint
                    deleteCustomerPaymentProfileResponse response = controller.GetApiResponse();
                    if (response != null && response.messages.resultCode == messageTypeEnum.Ok)
                    {
                        if (response != null && response.messages.message != null)
                        {

                            responseModel.Message = TKMessages.Delete;
                            responseModel.StatusCode = (int)HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        responseModel.Message = TKMessages.Delete;
                        responseModel.StatusCode = (int)HttpStatusCode.BadRequest;
                    }
                }
            }
            catch (Exception ex)
            {
                //_logger.LogError(ex.Message);
                responseModel.Message = TKMessages.CommonFailed;
                responseModel.StatusCode = (int)HttpStatusCode.BadRequest;

            }
            return responseModel;
        }


    }
}

