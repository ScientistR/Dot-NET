﻿//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Models.ResponseModel;
//using FuelMuleFillUp.Utilities;
//using Microsoft.Extensions.Logging;
//using Nancy.Json;
//using Newtonsoft.Json;
//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Text;
//using System.Threading.Tasks;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class Notification : INotification
//    {
//        private readonly FuelMuleFillUpContext _dbContext;
//        private readonly ILogger<Notification> _logger;

//        public Notification(FuelMuleFillUpContext dbContext, ILogger<Notification> logger) //,IConfiguration config, UserManager<ApplicationUser> userManager
//        {
//            _dbContext = dbContext;
//            _logger = logger;
//        }
//        public bool CustomerNotification(CustomerNotificationRequestModel model)
//        {
//            CommonResponseModel commonResponseModel = new CommonResponseModel();
//            SendNotificationAsync(model.DeviceToken, model.UserId, 1, "Test");
//            return true;
//        }
        
//        private async Task SendNotificationAsync(string deviceToken, string UserId, int CommentId, string userName)
//        {
//            try
//            {
//                RemoteMessage req = new RemoteMessage()
//                {
//                    To = deviceToken,
//                    Notification = new NotificationModel()
//                    {
//                        body = userName + "sent you a message.", //reciverDetails.FullName + "User this commented on your product.", 
//                        title = "Fuel-Mule Fill-Up",
//                        Priority = "high",
//                        ContentAvailable = true
//                    },
//                    Data= new Data(){
//                        ContentAvailable=true,
//                        Id=1,
//                        Type="Message",
//                        UserId= UserId
//                    }
//                };
//                //var task = Task.Run(async () => await SendPushNotification.SendMessageNotification(req).ConfigureAwait(false));
//                var task = await SendPushNotification.SendMessageNotification(req).ConfigureAwait(false);
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                throw;
//            }
//        }
//        public static class SendPushNotification
//        {
//            public static async Task<NotificationResponseModel> SendNotification(NotificationRequestModel notificationRequest)
//            {
//                try
//                {
//                    NotificationResponseModel notificationResponse = new NotificationResponseModel();
//                    string apiResponse = string.Empty;
//                    using (var httpClientHandler = new HttpClientHandler())
//                    {
//                        using (HttpClient httpClient = new HttpClient())
//                        {
//                            string payLoad = JsonConvert.SerializeObject(notificationRequest);
//                            using HttpContent inputContent = new StringContent(payLoad, Encoding.UTF8, "application/json");
//                            //httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAAEtucAfg:APA91bFbwOKKoMo6gioBkAC2VgdebJ51vBhEKdmgDcRLbNE4RtkiaiklLCDF0tgibasaACwDeXvL4zEr7BtGji0qw2NjHEFvpBzKqzipOcdiMqLsnmbULh9j-DdCX3wii30S47nTycS_");
//                            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAARYEJ8kw:APA91bFXc7b781AY-7z6m3XdpzJav_kGd1OQj8gvLhEqCferYTzz0-yiWYHwx0N2HUpOlwtVTvHPujZhowUoOJlDZVC8mV_w9kc8FBWAmffqnyjmR7U4RvnSvHphEdQIgwRxM-fYjuEd");
//                            var response = await httpClient.PostAsync(new Uri("https://fcm.googleapis.com/fcm/send"), inputContent).ConfigureAwait(false);
//                            if (response.StatusCode == HttpStatusCode.OK)
//                            {
//                                apiResponse = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
//                                notificationResponse = JsonConvert.DeserializeObject<NotificationResponseModel>(apiResponse);
//                                return notificationResponse;
//                            }
//                            else
//                            {
//                                return notificationResponse;
//                            }
//                        }
//                    }
//                }
//                catch
//                {
//                    //_logger.LogError(ex.Message);
//                    throw;
//                }
//            }

//            public static async Task<NotificationResponseModel> SendMessageNotification(RemoteMessage notificationRequest)
//            {
//                try
//                {
//                    NotificationResponseModel notificationResponse = new NotificationResponseModel();
//                    string apiResponse = string.Empty;
//                    using (var httpClientHandler = new HttpClientHandler())
//                    {
//                        using (HttpClient httpClient = new HttpClient())
//                        {
//                            string payLoad = JsonConvert.SerializeObject(notificationRequest);
//                            HttpContent inputContent = new StringContent(payLoad, Encoding.UTF8, "application/json");
//                            // httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAAEtucAfg:APA91bFbwOKKoMo6gioBkAC2VgdebJ51vBhEKdmgDcRLbNE4RtkiaiklLCDF0tgibasaACwDeXvL4zEr7BtGji0qw2NjHEFvpBzKqzipOcdiMqLsnmbULh9j-DdCX3wii30S47nTycS_");
//                            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAARYEJ8kw:APA91bFXc7b781AY-7z6m3XdpzJav_kGd1OQj8gvLhEqCferYTzz0-yiWYHwx0N2HUpOlwtVTvHPujZhowUoOJlDZVC8mV_w9kc8FBWAmffqnyjmR7U4RvnSvHphEdQIgwRxM-fYjuEd");
//                            var response = await httpClient.PostAsync(new Uri("https://fcm.googleapis.com/fcm/send"), inputContent).ConfigureAwait(false);
//                            if (response.StatusCode == HttpStatusCode.OK)
//                            {
//                                apiResponse = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
//                                notificationResponse = JsonConvert.DeserializeObject<NotificationResponseModel>(apiResponse);
//                                return notificationResponse;
//                            }
//                            else
//                            {
//                                return notificationResponse;
//                            }
//                        }
//                    }
//                }
//                catch (Exception ex)
//                {
//                    //_logger.LogError(ex.Message);
//                    throw;
//                }
//            }

//            public static string SendNotificationNew(string DeviceToken, string titleName, string msg)
//            {
//                // var serverKey = "AAAAEtucAfg:APA91bFbwOKKoMo6gioBkAC2VgdebJ51vBhEKdmgDcRLbNE4RtkiaiklLCDF0tgibasaACwDeXvL4zEr7BtGji0qw2NjHEFvpBzKqzipOcdiMqLsnmbULh9j-DdCX3wii30S47nTycS_";
//                var serverKey = "=AAAARYEJ8kw:APA91bFXc7b781AY-7z6m3XdpzJav_kGd1OQj8gvLhEqCferYTzz0-yiWYHwx0N2HUpOlwtVTvHPujZhowUoOJlDZVC8mV_w9kc8FBWAmffqnyjmR7U4RvnSvHphEdQIgwRxM-fYjuEd";
//                var senderId = "80993845752";
//                var webAddr = "https://fcm.googleapis.com/fcm/send";
//                var result = "-1";
//                var httpWebRequest = (HttpWebRequest)WebRequest.Create(webAddr);
//                httpWebRequest.ContentType = "application/json";
//                httpWebRequest.Headers.Add(string.Format("Authorization: key={0}", serverKey));
//                httpWebRequest.Headers.Add(string.Format("Sender: id={0}", senderId));
//                httpWebRequest.Method = "POST";
//                string[] str = msg.Split(":", StringSplitOptions.None);
//                string bodyMsg = string.Empty;
//                if (str.Length > 1)
//                {
//                    bodyMsg = str[0] + "\n" + str[1];
//                }
//                else
//                {
//                    bodyMsg = str[0];
//                }

//                var payload = new
//                {
//                    to = DeviceToken,
//                    priority = "high",
//                    content_available = true,
//                    notification = new
//                    {
//                        body = bodyMsg,
//                        title = titleName
//                    },
//                };
//                var serializer = new JavaScriptSerializer();
//                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
//                {
//                    string json = serializer.Serialize(payload);
//                    streamWriter.Write(json);
//                    streamWriter.Flush();
//                }
//                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
//                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
//                {
//                    result = streamReader.ReadToEnd();
//                }
//                return result;
//            }
//        }
//    }
//}