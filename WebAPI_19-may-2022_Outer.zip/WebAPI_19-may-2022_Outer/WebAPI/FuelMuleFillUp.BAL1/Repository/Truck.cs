﻿//using FuelMuleFillUp.BAL.IRepository;
//using FuelMuleFillUp.DAL.IDAL;
//using FuelMuleFillUp.Entities.CoreDbContext;
//using FuelMuleFillUp.Entities.DBTables;
//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Utilities;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Logging;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Text;
//using System.Threading.Tasks;

//namespace FuelMuleFillUp.BAL.Repository
//{
//    public class Truck : ITruck
//    {
//        private readonly FuelMuleFillUpContext _dbContext;
//        private readonly IGenericDAL<Trucks> _genericDAL;
//        private readonly ILogger<Trucks> _logger;

//        public Truck(FuelMuleFillUpContext dbContext, IGenericDAL<Trucks> genericDAL, ILogger<Trucks> logger) 
//        {
//            _dbContext = dbContext;
//            _genericDAL = genericDAL;
//            _logger = logger;
//        }
//        /// <summary>
//        /// TruckDetails
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        #region TruckDetails
//        public async Task<CommonResponseModel> TruckDetails(TruckDetailsModel model)
//        {
//            var responseResult = new CommonResponseModel();
//            try
//            {
//                var truck = Mapper.MapData<TruckDetailsModel, Trucks>(model);
//                var result = await _genericDAL.Save(truck);
//                if (result)
//                {
//                    responseResult.Data = truck;
//                    responseResult.StatusCode = (int)HttpStatusCode.OK;
//                    responseResult.Message = TKMessages.Truck;
//                }
//                else
//                {
//                    responseResult.Data = null;
//                    responseResult.StatusCode = (int)HttpStatusCode.BadRequest;
//                    responseResult.Message = TKMessages.rejectorder;
//                }
//            }
//            catch (Exception ex)
//            {

//                _logger.LogError(ex.Message);
//                responseResult.Data = null;
//                responseResult.Message = TKMessages.CommonFailed;
//                responseResult.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }

//            return responseResult;
//        }

//        #endregion
//        /// <summary>
//        ///  DeleteTruckDetails
//        /// </summary>
//        /// <param name="TruckId"></param>
//        /// <returns></returns>
//        #region  DeleteTruckDetails
//        public async Task<CommonResponseModel> DeleteTruckDetails(int TruckId)
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                if (TruckId > 0)
//                {
//                    var truckDetails = await _dbContext.Trucks.Where(t => t.TruckId == TruckId && t.IsDeleted == false).FirstOrDefaultAsync().ConfigureAwait(true);
//                    if (truckDetails != null)
//                    {
//                        truckDetails.IsDeleted = true;
//                        _dbContext.Update(truckDetails);
//                        var result = _dbContext.SaveChanges();
//                        if (result > 0)
//                        {
//                            response.Data = truckDetails;
//                            response.StatusCode = (int)HttpStatusCode.OK;
//                            response.Message = TKMessages.Delete;
//                        }
//                        else
//                        {
//                            response.Data = null;
//                            response.StatusCode = (int)HttpStatusCode.BadRequest;
//                            response.Message = TKMessages.CommonFailed;
//                        }
//                    }
//                    else
//                    {
//                        response.Data = null;
//                        response.StatusCode = (int)HttpStatusCode.BadRequest;
//                        response.Message = TKMessages.TruckDeleted;
//                    }
//                }
//                else
//                {
//                    response.Data = null;
//                    response.StatusCode = (int)HttpStatusCode.BadRequest;
//                    response.Message = TKMessages.CommonFailed;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//        #endregion
//        /// <summary>
//        /// ListTruckDetails
//        /// </summary>
//        /// <returns></returns>
//        #region  ListTruckDetails
//        public async Task<CommonResponseModel> ListTruckDetails()
//        {
//            CommonResponseModel response = new();
//            try
//            {
//                response.Data = await _dbContext.Trucks.Where(res => res.IsDeleted == false).Select(a => new TruckDetailsModel()
//                {
//                    TruckId=a.TruckId,
//                    TruckColor=a.TruckColor,
//                    MakeName=a.MakeName,
//                    ModelName=a.ModelName,
//                    LicencePlateNumber=a.LicencePlateNumber,
//                    TankSize=a.TankSize
//                }).ToListAsync().ConfigureAwait(false);
//                response.StatusCode = (int)(HttpStatusCode.OK);
//                response.Message = TKMessages.TruckList;
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex.Message);
//                response.Data = null;
//                response.Message = TKMessages.CommonFailed;
//                response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            }
//            return response;
//        }
//       #endregion
//    }

//}
