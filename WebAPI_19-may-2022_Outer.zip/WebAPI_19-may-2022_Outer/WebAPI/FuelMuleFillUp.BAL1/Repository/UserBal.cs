﻿using AutoMapper;
using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.RequestModel;
using FuelMuleFillUp.Utilities;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Org.BouncyCastle.Security;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.Repository
{
    public class UserBal : IUserBal
    {
        private readonly IUserDal userDal;
        private readonly IGenericDAL<UserToken> tokenGenericDal;
        public UtilityFunction utility;
        public readonly IMapper mapper;
        private readonly IGenericDAL<AspNetUser> userGenericDal;
        private readonly ILogger<UserBal> _logger;

        /// <summary>
        /// UserBal class
        /// </summary>
        /// <param name="userDal"></param>
        public UserBal(IUserDal userDal, IGenericDAL<UserToken> tokenGenericDal, IMapper mapper, IGenericDAL<AspNetUser> userGenericDal, ILogger<UserBal> _logger)
        {
            this.userDal = userDal;
            this.tokenGenericDal = tokenGenericDal;
            this.mapper = mapper;
            this.userGenericDal = userGenericDal;
            this._logger = _logger;
        }
        /// <summary>
        /// GenrateReferralRandomCode
        /// </summary>
        /// <returns></returns>
        public string GenrateReferralRandomCode()
        {
            char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890".ToCharArray();
            StringBuilder sb = new(); //StringBuilder
            Random random = new SecureRandom();
            for (int i = 0; i < 6; i++)
            {
                char c = chars[random.Next(chars.Length)];
                sb.Append(c);
            }
            String output = sb.ToString();
            return output;
        }

       // var content = "Chetu@123";
        string key = "E546C8DF278CD5931069B522E695D4F2";
        /// <summary>
        /// User Registration - save user - customer, employee and driver
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> UserRegistration(UserDto user)
        {
            utility = new UtilityFunction();
            CommonResponseModel response = new();
            try
            {
                user.ReferralCode = GenrateReferralRandomCode();
                if (user.RouteId == 0)
                {
                    user.RouteId = null;
                }
               // var hashsalt = EncryptString(user.PasswordHash);
               // user.PasswordHash = hashsalt;
                var emailExists = userDal.FindUserWithEmail(user.Email, user.Id);
                response = await utility.DuplicateResponse(emailExists);

                if (response.Message != "Already Exists")
                {
                    var userInfo = mapper.Map<AspNetUser>(user);
                    var result = await userDal.UserRegistration(userInfo);
                    user.Id = userInfo.Id;
                    response = await utility.ResponseMessage(result, user);
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Update User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> UpdateUser(UserUpdateRequestModel user)
        {
            CommonResponseModel response = new();
            try
            {
                var entityUser = (await userDal.GetUsers(null, user.Id)).FirstOrDefault();
                entityUser.FirstName = user.FirstName;
                entityUser.LastName = user.LastName;
                entityUser.Address1 = user.Address1;
                entityUser.Address = user.Address;
                entityUser.City = user.City;
                entityUser.Country = user.Country;
                entityUser.MobileNo = user.MobileNo;
                var res = await userGenericDal.Save(entityUser);
                if (res != null)
                {
                    response.Data = entityUser.Id;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.AddUpdate;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.invalid;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }
        /// <summary>
        /// Get user details
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetUsers(string role, int? userId)
        {
            utility = new UtilityFunction();
            CommonResponseModel response = new();
            try
            {

                var usersList = await userDal.GetUsers(role, userId);

                var users = mapper.Map<List<UserDto>>(usersList);
                users.ForEach(user =>
                {
                        user.SubscriptionId = usersList.FirstOrDefault(x => x.Id == user.Id).AssignSubscriptions.Any() ?
                        user.SubscriptionId = usersList.FirstOrDefault(x => x.Id == user.Id).AssignSubscriptions.FirstOrDefault().PlanId : null;
                     
                        user.Vehicles = mapper.Map<List<VehicleDto>>(user.Vehicles);
                    
                });

                if (usersList != null)
                {
                    response.Data = users;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;

                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;

                }
            }
            catch (Exception ex)
            {

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// Get roles
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<CommonResponseModel> GetRoles(int? id)
        {
            utility = new UtilityFunction();
            CommonResponseModel response = new();
            try
            {
                var usersList = await userDal.GetRoles(id);

                if (usersList != null)
                {
                    response.Data = usersList;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.GetData;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;

                }


            }
            catch (Exception ex)
            {

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        /// <summary>
        /// User login
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        /// 
        //public class UserVerify
        //{
        //    public int Id { get; set; }
        //    public string Name { get; set; }
        //    public string Password { get; set; }
        //    public byte[] StoredSalt { get; set; }

        //}
        //UserVerify verify = new UserVerify();
        //public string EncryptPassword(string password)
        //{
        //    // Encrypt password
        //    byte[] salt = new byte[128 / 8]; // Generate a 128-bit salt using a secure PRNG
        //    using (var rng = RandomNumberGenerator.Create())
        //    {
        //        rng.GetBytes(salt);
        //    }

        //    string encryptedPassw = Convert.ToBase64String(KeyDerivation.Pbkdf2(
        //        password: password,
        //        salt: salt,
        //        prf: KeyDerivationPrf.HMACSHA1,
        //        iterationCount: 10000,
        //        numBytesRequested: 256 / 8
        //    ));
        //    return encryptedPassw;
        //}

        //public bool VerifyPassword(string password, byte[] salt, string PasswordHash)
        //{
        //    //string encryptedPassw = Convert.ToBase64String(KeyDerivation.Pbkdf2(
        //    string encryptedPassw = Convert.ToBase64String(KeyDerivation.Pbkdf2(
        //        password: password,
        //        salt: salt,
        //        prf: KeyDerivationPrf.HMACSHA1,
        //        iterationCount: 10000,
        //        numBytesRequested: 256 / 8
        //    ));
        //    return encryptedPassw == PasswordHash;
        //}

        public static string EncryptString(string text, string keyString)
        {
            var key = Encoding.UTF8.GetBytes(keyString);

            using (var aesAlg = Aes.Create())
            {
                using (var encryptor = aesAlg.CreateEncryptor(key, aesAlg.IV))
                {
                    using (var msEncrypt = new MemoryStream())
                    {
                        using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(text);
                        }

                        var iv = aesAlg.IV;

                        var decryptedContent = msEncrypt.ToArray();

                        var result = new byte[iv.Length + decryptedContent.Length];

                        Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
                        Buffer.BlockCopy(decryptedContent, 0, result, iv.Length, decryptedContent.Length);

                        return Convert.ToBase64String(result);
                    }
                }
            }
        }

        public static string DecryptString(string cipherText, string keyString)
        {
            var fullCipher = Convert.FromBase64String(cipherText);

            var iv = new byte[16];
            var cipher = new byte[16];

            Buffer.BlockCopy(fullCipher, 0, iv, 0, iv.Length);
            Buffer.BlockCopy(fullCipher, iv.Length, cipher, 0, iv.Length);
            var key = Encoding.UTF8.GetBytes(keyString);

            using (var aesAlg = Aes.Create())
            {
                using (var decryptor = aesAlg.CreateDecryptor(key, iv))
                {
                    string result;
                    using (var msDecrypt = new MemoryStream(cipher))
                    {
                        using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (var srDecrypt = new StreamReader(csDecrypt))
                            {
                                result = srDecrypt.ReadToEnd();
                            }
                        }
                    }

                    return result;
                }
            }
        }

       
        
        public async Task<CommonResponseModel> UserLogin(string email, string password, string deviceToken, string deviceId, SymmetricSecurityKey key)
        {
            utility = new UtilityFunction();
            CommonResponseModel response = new();
            try
            {
                var user = await userDal.UserLogin(email, password);
                if (user!=null && user.IsActive == false)
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = "User is currently inactive please contact admin";
                }
                else
                {
                    // var vaildatepwd = user.PasswordHash;

                    //  var user = _context.Users.FirstOrDefault(u => u.Name == loginUser.Name);
                    //var isPasswordMatched = VerifyPassword(loginUser.Password, user.StoredSalt, user.Password);
                    //var isPasswordMatched = VerifyPassword(password, user.PasswordHash);
                    //if (isPasswordMatched)
                    //{
                    //    //Login Successfull
                    //}
                    //else
                    //{
                    //    //Login Failed
                    //}

                    if (user != null && user.Id > 0)
                    {
                        await tokenGenericDal.Save(new UserToken()
                        {
                            Id = user.UserTokens.Any(x => x.DeviceId == deviceId) ? user.UserTokens.FirstOrDefault(x => x.DeviceId == deviceId).Id : 0,
                            DeviceToken = deviceToken,
                            DeviceId = deviceId,
                            AspNetUserId = user.Id,
                            CreatedBy = user.Id
                        });

                        user.UserTokens = null;

                        string retToken;
                        var tokenHandler = new JwtSecurityTokenHandler();
                        //3. Create JETdescriptor
                        var tokenDescriptor = new SecurityTokenDescriptor()
                        {
                            Subject = new ClaimsIdentity(
                                new Claim[]
                                {
                                new Claim(ClaimTypes.Name, email),
                                new Claim(ClaimTypes.Role, user.RoleId.ToString())

                                }),
                            Expires = DateTime.Now.AddDays(365),
                            SigningCredentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature),
                        };
                        //4. Create Token
                        var token = tokenHandler.CreateToken(tokenDescriptor);

                        // 5. Return Token from method
                        retToken = tokenHandler.WriteToken(token);
                        var userDto = mapper.Map<UserDto>(user);

                        userDto.AccessToken = retToken;
                        userDto.RoleName = user.Role.Name;

                        response.Data = userDto;
                        response.StatusCode = (int)HttpStatusCode.OK;
                        response.Message = TKMessages.login;
                    }
                    else
                    {
                        response.Data = null;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        response.Message = TKMessages.Msgvalidpwd;
                    }
                }
            }
            catch (Exception ex)
            {

                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }

        public async Task<CommonResponseModel> DeleteEmployee(int UserId)
        {
            CommonResponseModel response = new();
            try
            {
                var admins = await userDal.GetUsers("Admin", null);
                var users = await userDal.GetUsersByIds(new int[] { UserId });
                if(!admins.Any(x => x.Id != UserId))
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.Msgadmin;
                }
                else if (users != null && users.Count > 0)
                {
                    var user = users.Where(x => x.IsDeleted == false).FirstOrDefault();
                    user.IsDeleted = true;
                    await userGenericDal.Save(user);
                    response.Data = true;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = TKMessages.DeleteRecord;
                }
                else
                {
                    response.Data = null;
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    response.Message = TKMessages.NotExist;
                }

            }
            catch (Exception ex)
            {
                response.Data = null;
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.Message = TKMessages.CommonFailed;
                _logger.LogError(ex.Message);
            }
            return response;
        }


    }
}
