﻿using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.RequestModel;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
    public interface IUserBal
    {
        Task<CommonResponseModel> UserRegistration(UserDto user);
        
        Task<CommonResponseModel> UpdateUser(UserUpdateRequestModel user);
        Task<CommonResponseModel> GetUsers(string role, int? userId);
        Task<CommonResponseModel> UserLogin(string email, string password, string deviceToken, string deviceId, SymmetricSecurityKey key);
        Task<CommonResponseModel> GetRoles(int? id);
        Task<CommonResponseModel> DeleteEmployee(int UserId);
    }
}
