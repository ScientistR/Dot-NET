﻿//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using FuelMuleFillUp.Entities.DBTables;
//using FuelMuleFillUp.Entities.CoreDbContext;

//namespace FuelMuleFillUp.BAL.IRepository
//{
//    public interface IRoute
//    {
//        /// <summary>
//        /// AddUpdateRouteDetails
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddUpdateRouteDetails(RouteDetailsModel model);


//        /// <summary>
//        /// RemoveRouteDetails
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
       
//        Task<CommonResponseModel> RemoveRouteDetails(int routeId);
//        /// <summary>
//        /// AddCustomerRoute
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddCustomerRoute(List<CustomerRouteModel> model);
//        /// <summary>
//        /// GetRouteUnassignedDriverList
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetRouteUnassignedDriverList();
//        /// <summary>
//        /// CustomerRouteList
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> CustomerRouteList();
//        /// <summary>
//        /// GetRouteassignedCustomerList
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetRouteAssignedCustomerList();

//        Task<CommonResponseModel> AssignedRouteList(int routeId);

//        /// <summary>
//        /// AddCustomerRoute
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> DeleteCustomerRoute(string CustomerID);
//        /// <summary>
//        /// 
//        //add new add

//        Task<CommonResponseModel> AssingCustomerRoute(ApplicationUser model);

//    }
//}
