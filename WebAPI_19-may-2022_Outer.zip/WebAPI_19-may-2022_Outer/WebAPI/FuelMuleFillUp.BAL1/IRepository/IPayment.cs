﻿//using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
    public interface IPayment
    {
        Task<CommonResponseModel> CreateCustomerPaymentProfile(AuthorizePayment payment);
        Task<CommonResponseModel> GetCustomerCardDetails(int customerId);
        Task<CommonResponseModel> AddNewCard(AddCustomerCardDetails model);
        Task<CommonResponseModel> CustomerPayment(CustomerPayment model);
        Task<CommonResponseModel> DeleteCustomerCard(DeleteCustomerCard model);
    }
}

