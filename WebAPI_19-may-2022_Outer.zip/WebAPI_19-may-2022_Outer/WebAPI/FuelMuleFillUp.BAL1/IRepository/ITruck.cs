﻿using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
    public interface ITruck
    {
        /// <summary>
        /// TruckDetails
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
   //     Task<CommonResponseModel> TruckDetails(TruckDetailsModel model);
        /// <summary>
        /// DeleteTruckDetails
        /// </summary>
        /// <param name="TruckId"></param>
        /// <returns></returns>
        Task<CommonResponseModel> DeleteTruckDetails(int TruckId);
        /// <summary>
        /// ListTruckDetails
        /// </summary>
        /// <returns></returns>
        Task<CommonResponseModel> ListTruckDetails();
    }
}
