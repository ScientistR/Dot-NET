﻿using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
//using FuelMuleFillUp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
  public  interface ICustomer
    {
        Task<CommonResponseModel> GetVehicles(int? userId, int? vehicleId);
        Task<CommonResponseModel> AddUpdateVehicle(VehicleDto vehicle);
        Task<CommonResponseModel> DeleteVehicle(int vehicleId, int modifyBy);
        Task<CommonResponseModel> GetCustomerUpcomingDeliveries(int? customerId);
        Task<CommonResponseModel> GetCustomerDeliveriesForDate(DateTime deliveryDate, int? userId);
        Task<CommonResponseModel> AcceptCustomerDelivery(int deliveryId, int actionId);
        Task<CommonResponseModel> AddOrder(OrderDetailDto order);
        Task<CommonResponseModel> GetCustomerPastDeliveries(int? customerId);
        Task<CommonResponseModel> AssignSubscriptionPlan(int userId, int planId, int vehicleId);
        Task<CommonResponseModel> CancelPlan(int userId, int vehicleId, int PlanId);
        Task<CommonResponseModel> GetAssignSubscriptionPlanUserId(int userId);
        Task<CommonResponseModel> ResetPassword(string username, string password, string confirmPassword);
        Task<CommonResponseModel> OtpSend(string username, EmailSettings emailSettings);
        Task<CommonResponseModel> VerifyOtp(string username, string otp);
        Task<CommonResponseModel> CustomersSubscriptionPlanList(int userId);
        Task<CommonResponseModel> AssignBarCode(int VehicleId, string BarCode, int modifiedBy);
        Task<CommonResponseModel> GetBarCodeLicense(string coderId, string licenseId);
        Task<CommonResponseModel> SendCustomerReferralCode(int customerId, string email);
        Task<CommonResponseModel> GenrateExcleSheetForAcceptedCustomer(DateTime deliveryDate);
        Task<CommonResponseModel> GenrateExcleSheetCustomerPaymentList(DateTime From, DateTime To);
    }
}
