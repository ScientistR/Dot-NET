﻿using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
  public interface IHelp
    {
       // Task<CommonResponseModel> Help();
       // Task<CommonResponseModel> Help1();
    }
}
