﻿
//using FuelMuleFillUp.Models;
////using FuelMuleFillUp.Models.RequestModel;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;



//namespace FuelMuleFillUp.BAL.IRepository
//{
//    public interface IRegistration
//    {
//        /// <summary>
//        /// RegisterUser
//        /// </summary>
//        /// <param name="register"></param>
//        /// <returns></returns>
//       // Task<CommonResponseModel> SaveUpdateCustomer(RegistrationModel loginRegistration);
//        /// <summary>
//        /// loginUser
//        /// </summary>
//        /// <param name="login"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> loginUser(LoginModel login);
       
//        /// <summary>
//        /// OtpSend
//        /// </summary>
//        /// <param name="sendOtp"></param>
//        /// <param name="emailSettings"></param>
//        /// <returns></returns>
//        Task<APIResponseModel> OtpSend(SendOtpModel sendOtp, EmailSettings emailSettings);
//        /// <summary>
//        /// VerifyOtp
//        /// </summary>
//        /// <param name="verifyOtpModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> VerifyOtp(VerifyOtpModel verifyOtpModel);
//        /// <summary>
//        /// user can ResetPassword
//        /// </summary>
//        /// <param name="resetPasswordModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> ResetPassword(ResetPasswordModel resetPasswordModel);
//        /// <summary>
//        /// DriverRegistration
//        /// </summary>
//        /// <param name="driverRegistration"></param>
//        /// <returns></returns>
      
//        Task<APIResponseModel> logout(SendOtpModel sendOtp);
//        /// <summary>
//        /// AddOrder
//        /// </summary>
//        /// <param name="order"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddOrder(OrderModel order);
//        /// <summary>
//        /// AddUpdateProduct
//        /// </summary>
//        /// <param name="productRequestModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddUpdateProduct(ProductRequestModel productRequestModel);
//        /// <summary>
//        /// AddVehicleBarCode
//        /// </summary>
//        /// <param name="addBarCodeRequestModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddVehicleBarCode(AddBarCodeRequestModel addBarCodeRequestModel);
//        /// <summary>
//        /// PerStopDeliveryAmount
//        /// </summary>
//        /// <param name="perStopDeliveryAmountRequestModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> PerStopDeliveryAmount(PerStopDeliveryAmountRequestModel perStopDeliveryAmountRequestModel);
//        /// <summary>
//        /// DeleteProduct
//        /// </summary>
//        /// <param name="ProductId"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> DeleteProduct(int ProductId);
//        /// <summary>
//        /// GetAllProduct
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetAllProduct();
//        /// <summary>
//        /// GetAllCustomerPaymentDetails
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetAllCustomerPaymentDetails();
//        /// <summary>
//        /// GetALLDeliveryStopAmountDetails
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetALLDeliveryStopAmountDetails();
//        Task<CommonResponseModel> GetCustomerPaymentDetailsDateWise(DateTime To, DateTime From);
//        Task<CommonResponseModel> CustomerPaymentFailedDateWise(DateTime To, DateTime From);
//        Task<CommonResponseModel> GenrateExcleSheetCustomerPaymentList(DateTime To, DateTime From);
//        Task<CommonResponseModel> GenrateExcleSheetForAcceptedCustomer(DateTime DeliveryDate);//DateTime date
//        Task<CommonResponseModel> GetRoll();
      
//    }
//}
