﻿
using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
//using FuelMuleFillUp.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
   public interface IFAQs
    {
        Task<CommonResponseModel> ListFAQs();

       // Task<CommonResponseModel> AddUpdateListFAQs(AddUpdateFAQAnswerDetails ModelFQA);

       // Task<CommonResponseModel> RemoveListFAQs(AddUpdateFAQAnswerDetails ModelFQA);
    }
}
