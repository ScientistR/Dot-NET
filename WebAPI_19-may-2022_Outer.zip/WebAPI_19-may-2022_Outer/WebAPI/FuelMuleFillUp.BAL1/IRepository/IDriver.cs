﻿using FuelMuleFillUp.Models;
//using FuelMuleFillUp.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
    public  interface IDriver
    {
        /// <summary>
        /// DriverRegistrationUpdate
        /// </summary>
        /// <param name="driverRegistration"></param>
        /// <returns></returns>
       // Task<CommonResponseModel> DriverRegistrationUpdate(DriverRegistrationModel driverRegistration);
        /// <summary>
        /// ListOfEmployee
        /// </summary>
        /// <returns></returns>
        Task<CommonResponseModel> ListOfEmployee();
        /// <summary>
        /// DeleteEmployeeDetails
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        Task<CommonResponseModel> DeleteEmployeeDetails(string EmployeeId);
        /// <summary>
        /// VehicleDetailsByPlatNo
        /// </summary>
        /// <param name="LicencePlateNumber"></param>
        /// <returns></returns>
        Task<CommonResponseModel> VehicleDetailsByPlatNo(string LicencePlateNumber);
        Task<CommonResponseModel> VehicleDetailsByPlatNoAndBarcode(string PlatOrBarCode);
        /// <summary>
        /// GetVehicleDetailsByScanBarCode
        /// </summary>
        /// <param name="BarCode"></param>
        /// <returns></returns>
        Task<CommonResponseModel> GetVehicleDetailsByScanBarCode(string BarCode);
        Task<CommonResponseModel> GetCustomerVehicleDetailsById(int vehicleId);


    }
}
