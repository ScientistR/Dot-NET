﻿//using FuelMuleFillUp.Models;
////using FuelMuleFillUp.ViewModel.ViewModels;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace FuelMuleFillUp.BAL.IRepository
//{
//    public interface ICustomerDetails
//    {     
       
//        /// <summary>
//        /// CustomerAddVehicles
//        /// </summary>
//        /// <param name="customerAddVehiclesModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddVehicles(VehicleModel vehicles); 
//        /// <summary>
//        /// CustomerVehiclesId
//        /// </summary>
//        /// <param name="CustomerId"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> CustomerVehiclesId(Guid? CustomerId);
//        /// <summary>
//        /// AddOrderForCustomer
//        /// </summary>
//        /// <param name="orderModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AddOrderForCustomer(OrderModel orderModel);
//        /// <summary>
//        /// CustomerDeatilsId
//        /// </summary>
//        /// <param name="CustomerId"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> CustomerDeatilsId(string CustomerId);
//        /// <summary>
//        /// DeleteCustomerVehicles
//        /// </summary>
//        /// <param name="CustomerId"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> DeleteCustomerVehicles(int vehicleId);
//        /// <summary>
//        /// CustomerDelivery
//        /// </summary>
//        /// <param name="customerDelivery"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> CustomerDelivery(Guid? UserId);
//        /// <summary>
//        /// DeliveryByUserIdAndDate
//        /// </summary>
//        /// <param name="UserId"></param>
//        /// <param name="dateTime"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> DeliveryByUserIdAndDate(Guid UserId, DateTime dateTime);
//        /// <summary>
//        /// DeliverySchedule
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> DeliverySchedule();
//        /// <summary>
//        /// SendCustomerReferralCode
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonResponseModel> SendCustomerReferralCode(SendCustomerReferralCodeModel model);
//        /// <summary>
//        /// AcceptCustomerDelivery
//        /// </summary>
//        /// <param name="model"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AcceptCustomerDelivery(AcceptCustomerDeliveryRequestModel model);
//        /// <summary>
//        /// AcceptCustomerDeliveryList
//        /// </summary>
//        /// <param name="DeliveryDate"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AcceptCustomerDeliveryList(DateTime DeliveryDate);
//        /// <summary>
//        /// Get Customer List API
//        /// </summary>
//        /// <returns></returns>
//        Task<CommonUserResponseModel> GetCustomersDetails(int? Id);
//        /// <summary>
//        /// CustomersSubscriptiomPlanList
//        /// </summary>
//        /// <param name="customerId"></param>
//        /// <returns></returns>
//        Task<CommonUserResponseModel> CustomersSubscriptiomPlanList(string customerId);
//        /// <summary>
//        /// AssignSubscriptionplan
//        /// </summary>
//        /// <param name="subscriptionplan"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> AssignSubscriptionplan(CustomerAssignSubscriptionplan subscriptionplan);
//        /// <summary>
//        /// CancelSubscriptionPlan
//        /// </summary>
//        /// <param name="Id"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> CancelSubscriptionPlan(CustomerAssignSubscriptionplan customerAssignSubscriptionplan);
//        /// <summary>
//        /// GetExcelSheetDetails
//        /// </summary>
//        /// <param name="Date"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetExcelSheetDetails(DateTime Date);
//        /// <summary>
//        /// GetCustomerOrderDetails
//        /// </summary>
//        /// <param name="userId"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> GetCustomerOrderDetails(string userId);
//        Task<CommonResponseModel> GetCustomerDeliveryPastFive(Guid userId);
//        Task<CommonResponseModel> GetCustomerListWithVehicleDetails(bool IsBarcode);
//        Task<CommonResponseModel> GetCustomerVehicleList();
//      //  Task<CommonResponseModel> GetAcceptedListDeliveryNotCompleted(DateTime Date);
//        /// <summary>
//        /// CustomerAddOrder
//        /// </summary>
//        /// <param name="customerOrderRequestModel"></param>
//        /// <returns></returns>
//        Task<CommonResponseModel> CustomerAddOrder(CustomerOrderRequestModel customerOrderRequestModel);
//        Task<CommonResponseModel> CustomerNotification(Customer customer);
//    }
//}
