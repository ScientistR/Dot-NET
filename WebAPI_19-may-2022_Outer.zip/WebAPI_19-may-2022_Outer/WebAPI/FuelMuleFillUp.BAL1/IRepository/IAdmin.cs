﻿using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.RequestModel;
using FuelMuleFillUp.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.BAL.IRepository
{
    public interface  IAdmin
    {
      
        Task<CommonResponseModel> GetEmployees(string role, int? userId);
        Task<CommonResponseModel> GetRoutes(int? routeId);
        Task<CommonResponseModel> AddUpdateRoute(RouteDetailDto route);
        Task<CommonResponseModel> DeleteRoute(int routeId,int modifyBy);
        Task<CommonResponseModel> AddUpdateProduct(ProductDto product);
        Task<CommonResponseModel> DeleteProduct(int productId, int modifyBy);
        Task<CommonResponseModel> GetProduct(int? productId);
        Task<CommonResponseModel> GetFaqs(int? faqId);
        Task<CommonResponseModel> SaveFaq(List<FaqResponseModel> faqs);
        Task<CommonResponseModel> GetTruck(int? truckId);
        Task<CommonResponseModel> AddUpdateTruck(TruckDto truck);
        Task<CommonResponseModel> AddUpdateZipCode(ZipDto zip);
        Task<CommonResponseModel> GetZip(int? ZipId);
        Task<CommonResponseModel> ZipCodeValidate(string zipCode);
        Task<CommonResponseModel> DeleteZipCode(int ZipId, int modifyBy);
        Task<CommonResponseModel> ActiveInactiveUser(int userId, bool activeFlag, int modifiedBy);
        Task<CommonResponseModel> AddUpdateSubscription(SubscriptionPlanDto subscription);
        Task<CommonResponseModel> GetSubscription(int? subscriptionPlanId, int? customerId);
        Task<CommonResponseModel> AssingRouteCustomer(List<AssignRouteDto> assignRoute);
        Task<CommonResponseModel> UpcomingDeliveries();
        Task<CommonResponseModel> DeleteFAQ(int faqid, int modifyBy);
        Task<CommonResponseModel> DeleteTruck(int truckId,int modifyBy);
        Task<CommonResponseModel> DeleteSubscrtionPlan(int? subscriptionPlanId, int modifyBy);
        Task<CommonResponseModel> PaymentListDateWise(DateTime From, DateTime To);
        Task<CommonResponseModel> GetStates(int? stateId);
        int GetMaxSequenceNoFaq();
        Task<CommonResponseModel> ListCustomersWithVehicleDetails(int customerId);
        int GetNoOfVehicle(int CustomerID);


    }
}
