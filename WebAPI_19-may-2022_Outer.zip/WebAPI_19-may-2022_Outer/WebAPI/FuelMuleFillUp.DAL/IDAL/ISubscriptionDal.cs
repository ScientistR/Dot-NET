﻿using FuelMuleFillUp.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.IDAL
{
    public interface ISubscriptionDal
    {
        Task<List<SubscriptionPlan>> GetPlans(int? id);
        Task<List<AssignSubscription>> GetAssignedSubscriptionByUserId(int? userId);
        Task<List<AssignSubscription>> GetPlan(int userId, int vehicleId, int PlanId);
    }
}
