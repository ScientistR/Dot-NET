﻿using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
//using FuelMuleFillUp.ViewModel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.IDAL
{
   public interface IVehicleDal
    {
        Task<List<Vehicle>> GetVehicles(int? userId, int? vehicleId);
        Task<List<Vehicle>> GetBarCodeLicense(string barCoderId, string licenseId);
    }
}
