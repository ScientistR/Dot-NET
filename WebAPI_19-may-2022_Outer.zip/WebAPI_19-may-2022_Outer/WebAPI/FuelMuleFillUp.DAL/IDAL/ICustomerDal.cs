﻿using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.IDAL
{
    public interface ICustomerDal
    {
        Task<List<AspNetUser>> GetCustomers(int routeId);
        Task<CustomerDelivery> GetCustomerDeliveryById(int deliveryId);
        Task<CustomerDelivery> GetCustomerDeliveryOrders(OrderDetailDto order);
        Task<List<CustomerDelivery>> GetCustomerUpcomingDeliveries(int? customerId);
        Task<List<CustomerDelivery>> GetCustomerDeliveriesForDate(DateTime deliveryDate, int? customerId);
        Task<List<CustomerDelivery>> GetCustomerPastDeliveries(int? customerId);
        Task<AspNetUser> ResetPassword(string username, string password, string confirmPassword);
        Task<AspNetUser> OtpSend(string username, EmailSettings emailSettings);
        Task<AspNetUser> VerifyOtp(string username, string otp);
        Task<List<VehicleListWithSubscrptionPlanResponseModel>> CustomersSubscriptionPlanList(int userId);
        Task<CommonResponseModel> AssignBarCode(int VehicleId, string BarCode, int modifiedBy);
        Task<AspNetUser> SendCustomerReferralCode(int customerId, string email);
       
       // Task<CommonResponseModel> OrderStatus(OrderDetailDto order);
    }
}
