﻿using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.IDAL
{
    public interface IUserDal
    {

        Task<bool> UserRegistration(AspNetUser user);
        bool FindUserWithEmail(string email, int userid);
        Task<List<AspNetUser>> GetUsers(string role, int? userId);
        Task<List<AspNetUser>> GetUsersByIds(int[] userIds);
        Task<AspNetUser> UserLogin(string email, string password);
        Task<List<AspNetRole>> GetRoles(int? id);
    }
}
