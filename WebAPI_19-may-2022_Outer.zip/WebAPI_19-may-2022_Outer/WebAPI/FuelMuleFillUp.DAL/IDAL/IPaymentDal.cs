﻿using FuelMuleFillUp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.IDAL
{
    public interface IPaymentDal
    {
        // SavePaymentDetails
        Task<CommonResponseModel> SavePaymentDetails();

    }
}
