﻿using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FuelMuleFillUp.Utilities.Enums;

namespace FuelMuleFillUp.DAL.IDAL
{
    public interface IAdminDal
    {
     
        Task<List<AspNetUser>>GetEmployees(string role, int? userId);
        Task<List<RouteDetail>> GetRoutes(int? routeId);
        Task<List<AspNetUser>> GetUnassignedUsers();
        Task<List<Product>> GetProduct(int? ProductId);
        Task<List<Faq>> GetFaqs(int? faqId);
        Task<List<Truck>> GetTruck(int? truckId);
        Task<RouteDetail> GetRoutesByName(string routeName);
        Task<List<SubscriptionPlan>> GetSubscription(int? subscriptionPlanId, int? customerId);
        Task<List<ZipCode>> GetZip(int? ZipId);
        Task<ZipCode> ZipCodeValidate(string zipCode);
        Task<ZipCode> ZipCodeVerify(ZipDto zip);
        Task<List<CustomerDelivery>> GetUpcomingDeliveries();
        Task<List<Vehicle>> ListCustomersWithVehicleDetails(int customerId);
        int GetNoOfVehicle(int CustomerID);
        int GetMaxSequenceNoFaq();
        Task<List<State>> GetStates(int? stateId);
        Task<List<Payment>> PaymentListDateWise(DateTime from, DateTime to);
    }
}
