﻿using FuelMuleFillUp.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.IDAL
{
    public interface IGenericDAL<T>
    {
        Task<bool> Save(T model);
        Task<bool> ListSave(List<T> model);
        Task<bool> Delete(T model);
    }
}
