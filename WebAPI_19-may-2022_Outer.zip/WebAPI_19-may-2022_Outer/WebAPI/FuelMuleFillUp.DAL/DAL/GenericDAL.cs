﻿using FuelMuleFillUp.DAL.IDAL;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models.Models;

namespace FuelMuleFillUp.DAL.DAL
{
    public class GenericDAL<T> : IGenericDAL<T> where T : class
    {
        #region Private
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
       // private readonly ILogger _logger;
        #endregion

        #region Constructor
        public GenericDAL(FuelMuleFillUpENRGQAContext dbContext)
        {
            _dbContext = dbContext;
           // _logger = logger;
        }
        #endregion


        #region Add / Update 
        public async Task<bool> Save(T model)
        {
            try
            {
                _dbContext.Set<T>().Update(model);
                return await _dbContext.SaveChangesAsync() > 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        public async Task<bool> ListSave(List<T> model)
        {
            try
            {
                using (_dbContext)
                {
                    _dbContext.Set<T>().UpdateRange(model);
                    return await _dbContext.SaveChangesAsync() > 0;
                }
            
            }
            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                _dbContext.Dispose();
            }
        }

        #region Delete
        public async Task<bool> Delete(T model)
        {
            try
            {
                using (_dbContext)
                {
                    _dbContext.Set<T>().Remove(model);
                    return await _dbContext.SaveChangesAsync() > 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }


}
