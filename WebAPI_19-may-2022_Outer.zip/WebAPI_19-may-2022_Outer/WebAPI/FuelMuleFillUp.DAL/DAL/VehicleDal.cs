﻿using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using Microsoft.EntityFrameworkCore;
//using FuelMuleFillUp.ViewModel.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.DAL
{
    public class VehicleDal : IVehicleDal
    {
        private readonly FuelMuleFillUpENRGQAContext _dbContext;

        public VehicleDal(FuelMuleFillUpENRGQAContext _dbContext)
        {
            this._dbContext = _dbContext;
        }

        public async Task<List<Vehicle>> GetBarCodeLicense(string barCoderId, string licenseId)
        {
            return await _dbContext.Vehicles.Where(x => (barCoderId == null || x.BarCode == barCoderId) && (licenseId == null || x.LicencePlateNumber == licenseId) && !x.IsDeleted)
                  .Include(x => x.AspNetUser)
                .Include(x => x.Product)
                .ToListAsync();
        }

        public async Task<List<Vehicle>> GetVehicles(int? userId, int? vehicleId)
        {
            //  return await _dbContext.Vehicles.Where(x => (userId == null || x.AspNetUserId == userId) && (vehicleId == null || x.VehicleId == vehicleId) && !x.IsDeleted).Include(x => x.AspNetUser).ToListAsync();
            var VehicleList = await _dbContext.Vehicles.Where(x => (userId == null || x.AspNetUserId == userId) && (vehicleId == null || x.VehicleId == vehicleId) && !x.IsDeleted)
                .Include(x => x.AspNetUser)
                .Include(x => x.Product)
                .ToListAsync();
            return VehicleList;
        }

    }
}
