﻿using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using System.Net;
using System.Threading.Tasks;
using FuelMuleFillUp.Utilities;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace FuelMuleFillUp.DAL.DAL
{
    public class UserDal : IUserDal
    {
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
        private readonly IGenericDAL<AspNetUser> userGenericDal;

        /// <summary>
        /// User data layer.
        /// </summary>
        /// <param name="userGenericDal"></param>
        /// <param name="_dbContext"></param>
        public UserDal(IGenericDAL<AspNetUser> userGenericDal, FuelMuleFillUpENRGQAContext _dbContext)
        {
            this._dbContext = _dbContext;
            this.userGenericDal = userGenericDal;
        }

        /// <summary>
        /// Save and Update user - emoployee, customer, driver etc.
        /// </summary>
        /// <param name="AspNetUser user"></param>
        /// <returns></returns>
        public async Task<bool> UserRegistration(AspNetUser user)
        {
            if (user.RoleId == 0)
            {
                user.RoleId = _dbContext.AspNetRoles.FirstOrDefault(x => x.Name == "Customer").Id;
            }
            return await userGenericDal.Save(user);

        }
        //public async Task<bool> CustomerRegistration(AspNetUser user)
        //{
        //    if (user.RoleId == 0)
        //    {
        //        user.RoleId = _dbContext.AspNetRoles.FirstOrDefault(x => x.Name == "Customer").Id;
        //    }
        //    return await userGenericDal.Save(user);
      
        //}
        

        /// <summary>
        /// FindUserWithEmail
        /// </summary>
        /// <param name="email"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public bool FindUserWithEmail(string email, int userid)
        {
            return _dbContext.AspNetUsers.Any(x => (userid == 0 && x.Email == email) || (x.Id != userid && x.Email == email));
        }


        /// <summary>
        /// GetUsers by role
        /// </summary>
        /// <param name="email"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public async Task<List<AspNetUser>> GetUsers(string role, int? userId)
        {

            return await _dbContext.AspNetUsers.Where(x => (role == null || x.Role.Name == role) && (userId == null || x.Id == userId) && !x.IsDeleted)
                .Include(x => x.AssignSubscriptions)
                .Include(x => x.Vehicles).ThenInclude(x => x.Product)
                .ToListAsync();

        }

        /// <summary>
        /// GetUsers by role
        /// </summary>
        /// <param name="email"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public async Task<List<AspNetUser>> GetUsersByIds(int[] userIds)
        {
            return await _dbContext.AspNetUsers.Where(x => userIds.Length == 0 || userIds.Contains(x.Id)).ToListAsync();
        }
        /// <summary>
        /// Get role
        /// </summary>
        /// <param name="email"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public async Task<List<AspNetRole>> GetRoles(int? id)
        {

          return await _dbContext.AspNetRoles.Where(x => (id == null || x.Id == id) && x.Name !="Customer" ).ToListAsync();


        }

        /// <summary>
        /// Userlogin
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        //public async Task<AspNetUser> UserLogin(string email, string password)
        //{
        //    return await _dbContext.AspNetUsers.AsNoTracking().Where(x => x.Email == email && x.PasswordHash == password).Include(x => x.UserTokens).AsNoTracking()
        //        .Include(x => x.Role)
        //        .FirstOrDefaultAsync();
        //}
        public async Task<AspNetUser> UserLogin(string email, string password)
        {
           
            return await _dbContext.AspNetUsers.AsNoTracking().Where(x => (x.Email == email && x.PasswordHash== password) && x.IsDeleted==false).Include(x => x.UserTokens).AsNoTracking()
                .Include(x => x.Role)
                .FirstOrDefaultAsync();
        }


        //  public async Task<bool> FindUserWithEmail(string email)
        //  {
        //      return _dbContext.AspNetUsers.Any(x => x.Email == email);
        //      //CommonResponseModel response = new();
        //      //try
        //      //{
        //
        //      //    if(!_dbContext.AspNetUsers.Any(x => x.Email == registration.Email))//not exist
        //      //    {
        //      //        _dbContext.AspNetUsers.Add(registration);
        //      //        _dbContext.SaveChanges();
        //      //    }
        //      //    else//exist
        //      //    {
        //      //        response.Data = null;
        //      //        response.Message = "Alreadyexists";//TKMessages.Alreadyexists;
        //      //        response.StatusCode = (int)HttpStatusCode.BadRequest;
        //      //    }
        //      //  var roleDetails = _dbContext.Roles.Where(res => res.Name == "Customer").FirstOrDefault();
        //      //  if (string.IsNullOrEmpty(registration.Id))
        //      //  {
        //      //      var userExists = _userManager.FindByEmailAsync(registration.UserName).Result;
        //      //      if (userExists != null)
        //      //      {
        //      //      }
        //      //      else
        //      //      {
        //      //          //if (zipcode != null)
        //      //          //{
        //      //          ApplicationUser user = new()
        //      //          {
        //      //              ReferralCode = GenrateReferralRandomCode(),
        //      //              SecurityStamp = Guid.NewGuid().ToString(),
        //      //              UserName = registration.UserName.ToLower().Trim(),
        //      //              PasswordHash = registration.Password,
        //      //              FirstName = registration.FirstName.Trim(),
        //      //              LastName = registration.LastName.Trim(),
        //      //              MobileNo = registration.MobileNo.Trim(),
        //      //              ZipCode = registration.ZipCode,
        //      //              Address = registration.Address.Trim(),
        //      //              Address1 = registration.Address1,
        //      //              Latitude = registration.Latitude,
        //      //              //JoiningDate = registration.JoiningDate
        //      //              Longitude = registration.Longitude,
        //      //              City = registration.City.Trim(),
        //      //              //State = registration.State.Trim(),
        //      //              Country = registration.Country.Trim(),
        //      //              CreateDate = DateTime.UtcNow,
        //      //              // JoiningDate= DateTime.UtcNow,
        //      //              IsDeleted = registration.IsDeleted = false,
        //      //              IsNotification = registration.IsNotification = true,
        //      //              Email = registration.UserName.ToLower().Trim(),
        //      //              Role = roleDetails.Id.Trim()
        //      //          };
        //      //          var result = await _userManager.CreateAsync(user, registration.Password).ConfigureAwait(false);
        //      //          if (result.Succeeded)
        //      //          {
        //      //              var email = user.Email;
        //      //              EmailSettings emailSettings = new();
        //      //              emailSettings.Email = Config.GetValue<string>("EmailConfiguration:From");
        //      //              emailSettings.Password = Config.GetValue<string>("EmailConfiguration:Password");
        //      //              emailSettings.Host = Config.GetValue<string>("EmailConfiguration:ServerAddress");
        //      //              emailSettings.Port = Config.GetValue<int>("EmailConfiguration:ServerPort");
        //      //
        //      //              UtilityFunction function = new();
        //      //              EmailInfo emailInfo = new();
        //      //              emailInfo.EmailTo = user.Email;
        //      //              emailInfo.EmailTo = user.Email;
        //      //              emailInfo.Subject = TKMessages.subject;
        //      //              emailInfo.Body = TKMessages.Registrationmessage;
        //      //              function.SendEmailAsync(emailInfo, emailSettings);
        //      //              response.Data = null;
        //      //              response.Message = TKMessages.success;
        //      //              response.StatusCode = (int)HttpStatusCode.OK;
        //      //
        //      //          }
        //      //          else
        //      //          {
        //      //              response.Data = null;
        //      //              response.Message = TKMessages.invalid;
        //      //              response.StatusCode = (int)HttpStatusCode.BadRequest;
        //      //          }
        //      //          //  }
        //      //
        //      //
        //      //
        //      //          //else
        //      //          //{
        //      //          //    response.Data = null;
        //      //          //    response.Message = TKMessages.ZipMessage;
        //      //          //    response.StatusCode = (int)HttpStatusCode.BadRequest;
        //      //          //}
        //      //
        //      //      }
        //      //
        //      //  }
        //      //  else
        //      //  {
        //      //      var customerDetails = _userManager.FindByIdAsync(registration.Id).Result;// _dbContext.Users.Where(res => res.Id == registrationVM.Id).FirstOrDefault();
        //      //      customerDetails.FirstName = registration.FirstName.Trim();
        //      //      customerDetails.LastName = registration.LastName.Trim();
        //      //      customerDetails.MobileNo = registration.MobileNo.Trim();
        //      //      customerDetails.Address = registration.Address.Trim();
        //      //      customerDetails.Address1 = registration.Address1;
        //      //      customerDetails.City = registration.City.Trim();
        //      //      //customerDetails.ZipCode = Convert.ToInt16(registration.ZipCode.ToString());
        //      //      customerDetails.Country = registration.Country.Trim();
        //      //      // customerDetails.State = registration.State.Trim();
        //      //      // customerDetails.Longitude = registrationVM.Longitude.Trim();
        //      //      //customerDetails.Latitude = registrationVM.Latitude.Trim();
        //      //      customerDetails.ModifyDate = DateTime.UtcNow;
        //      //      _dbContext.Users.Update(customerDetails);
        //      //      var res = _dbContext.SaveChanges();
        //      //      if (res > 0)
        //      //      {
        //      //          response.Data = customerDetails;
        //      //          response.Message = TKMessages.update;
        //      //          response.StatusCode = (int)HttpStatusCode.OK;
        //      //      }
        //      //      else
        //      //      {
        //      //          response.Data = null;
        //      //          response.Message = TKMessages.invalid;
        //      //          response.StatusCode = (int)HttpStatusCode.BadRequest;
        //      //      }
        //      //  }
        //      //}
        //
        //
        //
        //      //else
        //      //{
        //      //    response.Data = null;
        //      //    response.Message = TKMessages.ZipMessage;
        //      //    response.StatusCode = (int)HttpStatusCode.BadRequest;
        //      //  }
        //
        //      //}
        //      //catch (Exception ex)
        //      //{
        //      //   // _logger.LogError(ex.Message);
        //      //    response.Data = null;
        //      //    response.Message = ex.Message;
        //      //    response.StatusCode = (int)HttpStatusCode.InternalServerError;
        //
        //      //}
        //      ////finally
        //      ////{
        //      ////    return response;
        //      ////}
        //      //return response;
        //  }
    }
}
