﻿using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.DAL
{
    public class SubscriptionDal:ISubscriptionDal
    {
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
        public SubscriptionDal(FuelMuleFillUpENRGQAContext _dbContext)
        {
            this._dbContext = _dbContext;
        }

        public async Task<List<SubscriptionPlan>> GetPlans(int? id)
        {
            return await _dbContext.SubscriptionPlans.Where(x => (id == null || x.Id == id) && !x.IsDeleted).ToListAsync();
        }
        public async Task<List<AssignSubscription>> GetAssignedSubscriptionByUserId(int? userId)
        {
            return await _dbContext.AssignSubscriptions.Where(x => (userId == null || x.AspNetUserId == userId) && !x.IsDeleted).ToListAsync();
        }

        public async Task<List<AssignSubscription>> GetPlan(int userId, int vehicleId, int PlanId)
        {
            return await _dbContext.AssignSubscriptions.Where(x => (x.AspNetUserId == userId && x.VehicleId == vehicleId  &&  x.PlanId == PlanId) && !x.CancelPlan).ToListAsync();

        }
    }
}
