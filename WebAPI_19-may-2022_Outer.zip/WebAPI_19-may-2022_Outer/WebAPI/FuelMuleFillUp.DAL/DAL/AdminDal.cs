﻿using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static FuelMuleFillUp.Utilities.Enums;

namespace FuelMuleFillUp.DAL.DAL
{
    public class AdminDal : IAdminDal
    {
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
        private readonly IGenericDAL<AspNetUser> userGenericDal;
       
        public AdminDal(IGenericDAL<AspNetUser> userGenericDal, FuelMuleFillUpENRGQAContext _dbContext)
        {
            this.userGenericDal = userGenericDal;
            this._dbContext = _dbContext;
        }
        /// <summary>
        /// Get Employee Details
        /// </summary>
        /// <param name="role"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<List<AspNetUser>> GetEmployees(string role, int? userId)
        {
            var usersList = await _dbContext.AspNetUsers.Where(x => (role == null || x.Role.Name != role) && (userId == null || x.Id == userId) && x.IsDeleted==false).Include(x=>x.Role)
                .ToListAsync();
            return usersList;
        }
        /// <summary>
        /// Get customer Routes
        /// </summary>
        /// <param name="routeId"></param>
        /// <returns></returns>
        public async Task<List<RouteDetail>> GetRoutes(int? routeId)
        {
            var routesList = await _dbContext.RouteDetails.Where(x => (routeId == null || x.Id == routeId) && !x.IsDeleted)
                .Include(x => x.AspNetUsers).ThenInclude(x => x.Vehicles).ThenInclude(x=>x.AssignSubscriptions).ToListAsync();
            return routesList;
        }
        /// <summary>
        /// Get unassigned users
        /// </summary>
        /// <param name="routeId"></param>
        /// <returns></returns>
        public async Task<List<AspNetUser>> GetUnassignedUsers()
        {
            return await _dbContext.AspNetUsers.Where(x => x.RouteId == null && !x.IsDeleted && x.Role.Name == "Customer").ToListAsync();
        }
        /// <summary>
        /// method to get routes by name
        /// </summary>
        /// <param name="routeName"></param>
        /// <returns></returns>
        public async Task<RouteDetail> GetRoutesByName(string routeName)
        {
            var routesList = await _dbContext.RouteDetails.Where(x => (routeName == null || x.RouteName == routeName) && !x.IsDeleted).FirstOrDefaultAsync();
            return routesList;
        }
        /// <summary>
        /// Get customer Product
        /// </summary>
        /// <param name="ProductId"></param>
        /// <returns></returns>
        public async Task<List<Product>> GetProduct(int? ProductId)
        {
            var productList = await _dbContext.Products.Where(x => (ProductId == 0 || x.Id == ProductId) && !x.IsDeleted).ToListAsync();
            return productList;
        }
        /// <summary>
        /// Get Faqs
        /// </summary>
        /// <returns></returns>
        public async Task<List<Faq>> GetFaqs(int? faqId)
        {
            return await _dbContext.Faqs.Where(x => (faqId == null || x.FaqId == faqId) && !x.IsDeleted).Include(x => x.FaqAnswers).ToListAsync();
        }
        /// <summary>
        /// Get Truck
        /// </summary>
        /// <param name="truckId"></param>
        /// <returns></returns>
        public async Task<List<Truck>> GetTruck(int? truckId)
        {

            var truckList = await _dbContext.Trucks.Where(x => (truckId == null || x.TruckId == truckId) && !x.IsDeleted).ToListAsync();
            return truckList;
        }
        /// <summary>
        /// Get all Zip code
        /// </summary>
        /// <param name="ZipId"></param>
        /// <returns></returns>
        public async Task<List<ZipCode>> GetZip(int? ZipId)
        {

            var zipList = await _dbContext.ZipCodes.Where(x => (ZipId == null || x.Id == ZipId)&& !x.IsDeleted).ToListAsync();
            return zipList;
        }
        /// <summary>
        /// ZipCode Validate service area
        /// </summary>
        /// <param name="zipCode"></param>
        /// <returns></returns>
        public async Task<ZipCode> ZipCodeValidate(string zipCode)
        {
            var zipList = await _dbContext.ZipCodes.Where(x => x.Zip == zipCode).FirstOrDefaultAsync();
            return zipList;
        }
        /// <summary>
        /// Get customer Subscription
        /// </summary>
        /// <param name="subscriptionPlanId"></param>
        /// <returns></returns>
        public async Task<List<SubscriptionPlan>> GetSubscription(int? subscriptionPlanId, int? customerId)
        {
            var SubcriptionList = await _dbContext.SubscriptionPlans.Where(x => (subscriptionPlanId == null || x.Id == subscriptionPlanId) 
                && (customerId == null || x.CustomerId == customerId) && !x.IsDeleted).Include(x => x.Customer)
                .ToListAsync();
            return SubcriptionList;
        }
        /// <summary>
        /// Get Upcoming Deliveries
        /// </summary>
        /// <returns></returns>
        public async Task<List<CustomerDelivery>> GetUpcomingDeliveries()
        {
            return await _dbContext.CustomerDeliveries.Where(x => x.DeliveryDate.Date >= DateTime.Now.Date).ToListAsync();
        }
        /// <summary>
        /// Get All States
        /// </summary>
        /// <param name="stateId"></param>
        /// <returns></returns>
        public async Task<List<State>> GetStates(int? stateId)
        {
            var stateList = await _dbContext.States.Where(x => (stateId == null || x.Id == stateId)).ToListAsync();
            return stateList;
        }
        /// <summary>
        /// GetMaxSequenceNoFaq
        /// </summary>
        /// <returns></returns>
        public int GetMaxSequenceNoFaq()
        {
            return _dbContext.Faqs.Where(x => !x.IsDeleted).Max(x => x.Seq);
        }
        /// <summary>
        /// ListCustomersWithVehicleDetails
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        public async Task<List<Vehicle>> ListCustomersWithVehicleDetails(int customerId)
        {
            // var SubcriptionList = await _dbContext.Vehicles.Where(x => (customerId==null|| x.AspNetUserId== customerId) && !x.IsDeleted).Include(x=>x.AspNetUser).ToListAsync();
            var SubcriptionList = await _dbContext.Vehicles.Where(x => x.AspNetUserId == customerId && !x.IsDeleted).Include(x => x.AspNetUser).ToListAsync();

            return SubcriptionList;
        }
        /// <summary>
        /// GetNoOfVehicle
        /// </summary>
        /// <param name="CustomerID"></param>
        /// <returns></returns>
        public int GetNoOfVehicle(int CustomerID)
        {
            return _dbContext.Vehicles.Where(x => x.AspNetUserId == CustomerID && !x.IsDeleted).Include(x => x.AspNetUser).Count();
        }
        public async Task<ZipCode> ZipCodeVerify(ZipDto zip)
        {
            var zipList = await _dbContext.ZipCodes.Where(x => x.Zip == zip.Zip).FirstOrDefaultAsync();
            return zipList;
        }
        public async Task<List<Payment>> PaymentListDateWise(DateTime from, DateTime to)
        {
            var usersList = await _dbContext.Payments.Where(x => x.CreatedDate.Date >= from.Date && x.CreatedDate.Date <= to.Date).
                Include(y=>y.Vehicle).Include(x=>x.AspNetUser).ThenInclude(x=>x.AssignSubscriptions).ThenInclude(x=>x.Plan)
                .ToListAsync();
            return usersList;
        }
    }
}
