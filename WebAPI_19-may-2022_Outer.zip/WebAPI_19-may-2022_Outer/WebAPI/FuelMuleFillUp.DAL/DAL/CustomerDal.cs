﻿using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.ResponseModel;
using FuelMuleFillUp.Utilities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.DAL
{
    public class CustomerDal : ICustomerDal
    {
        //private readonly CustomerDal customerDal;
        private readonly FuelMuleFillUpENRGQAContext _dbContext;
        private readonly IGenericDAL<AspNetUser> userGenericDal;
        public CustomerDal(IGenericDAL<AspNetUser> userGenericDal, FuelMuleFillUpENRGQAContext _dbContext)
        {
            //this.customerDal = customerDal;
            this.userGenericDal = userGenericDal;
            this._dbContext = _dbContext;
            //  var Route = Mapper.MapData<UserDto, AspNetUser>(user);
        }


        /// <summary>
        /// GetCustomers by RouteId
        /// </summary>
        /// <param name="RouteId"></param>
        /// <returns></returns>
        public async Task<List<AspNetUser>> GetCustomers(int routeId)
        {

            return await _dbContext.AspNetUsers.Where(x => x.RouteId == routeId || x.RouteId == 0).ToListAsync();

        }

        /// <summary>
        /// Get customer upcoming deliveries
        /// </summary>
        /// <param name="deliveryId"></param>
        /// <returns></returns>
        public async Task<List<CustomerDelivery>> GetCustomerUpcomingDeliveries(int? customerId)
        {
            var deliveryList = await _dbContext.CustomerDeliveries.Where(x => x.Vehicle.AspNetUserId == customerId && !x.IsDeleted && x.DeliveryDate.Date >= System.DateTime.Now.Date).Include(x => x.Status)
                 .Include(res => res.Vehicle)
                .ToListAsync();

            return deliveryList;
        }

        /// <summary>
        /// Get customer upcoming deliveries
        /// </summary>
        /// <param name="deliveryId"></param>
        /// <returns></returns>
        public async Task<List<CustomerDelivery>> GetCustomerDeliveriesForDate(DateTime deliveryDate, int? customerId)
        {
            var deliveryList = await _dbContext.CustomerDeliveries.Where(x => (customerId == null || x.UserId == customerId) && !x.IsDeleted && x.DeliveryDate.Date == deliveryDate.Date)
             .Include(x => x.Vehicle)
              .Include(x => x.Status)
              .Include(x=>x.User)
              .ToListAsync();

            return deliveryList;
        }

        public async Task<CustomerDelivery> GetCustomerDeliveryById(int deliveryId)
        {
            var deliveryList = await _dbContext.CustomerDeliveries.Where(x => x.Id == deliveryId && !x.IsDeleted).FirstOrDefaultAsync();
            return deliveryList;
        }

        /// <summary>
        /// Customer Past Delivery
        /// </summary>
        /// <param name="customerId"></param>
        /// <returns></returns>
        public async Task<List<CustomerDelivery>> GetCustomerPastDeliveries(int? customerId)
        {
            var deliveryList = await _dbContext.CustomerDeliveries.Where(x => (customerId == null || x.UserId == customerId) && !x.IsDeleted && x.DeliveryDate.Date <= System.DateTime.Now.Date).ToListAsync();

            return deliveryList;
        }

        public async Task<AspNetUser> ResetPassword(string username, string password, string confirmPassword)
        {
            var restpwd = await _dbContext.AspNetUsers.Where(res => res.Email == username).FirstOrDefaultAsync();
            restpwd.PasswordHash = password;
            _dbContext.Entry(restpwd).State = EntityState.Modified;
            _dbContext.SaveChanges();
            return restpwd;
        }

        public async Task<AspNetUser> OtpSend(string username, EmailSettings emailSettings)
        {
            UtilityFunction function = new();
            var sendOtp = await _dbContext.AspNetUsers.Where(res => res.Email == username).FirstOrDefaultAsync();
            var otpDetails = GenerateRandomOTP();
            sendOtp.Otp = otpDetails;
            _dbContext.Entry(sendOtp).State = EntityState.Modified;
            _dbContext.SaveChanges();
            EmailInfo emailInfo = new();
            emailInfo.EmailTo = sendOtp.Email;
            emailInfo.Subject = "send otp";
            emailInfo.Body = "This is your reset password Otp" + " " + otpDetails;
            function.SendEmailAsync(emailInfo, emailSettings);
            return sendOtp;
        }

        public string GenerateRandomOTP()
        {
            string[] saAllowedCharacters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            string sOTP = String.Empty;
            string sTempChars = String.Empty;
            Random rand = new();
            for (int i = 0; i < 4; i++)
            {
                sTempChars = saAllowedCharacters[rand.Next(0, saAllowedCharacters.Length)];
                sOTP += sTempChars;
            }
            return sOTP;
        }

        public async Task<AspNetUser> VerifyOtp(string username, string otp)
        {
            var sendOtp = await _dbContext.AspNetUsers.Where(res => res.Email == username && res.Otp == otp).FirstOrDefaultAsync();
            return sendOtp;
        }

        /// <summary>
        /// CustomersSubscriptiomPlanList
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<List<VehicleListWithSubscrptionPlanResponseModel>> CustomersSubscriptionPlanList(int userId)
        {
            List<VehicleListWithSubscrptionPlanResponseModel> response = new List<VehicleListWithSubscrptionPlanResponseModel>();
            //CommonResponseModel response = new();
            try
            {
                var plans = _dbContext.SubscriptionPlans.Where(a => !a.IsDeleted && a.DefaultPlan || a.CustomerId==userId && a.DefaultPlan).ToList();
                
                

                var data = await (from vc in _dbContext.Vehicles
                                  where vc.AspNetUserId == userId && !vc.IsDeleted
                                  group new { vc } by new { vc.LicencePlateNumber, vc.MakeName, vc.ModelName, vc.VehicleId, } into grp
                                  select new VehicleListWithSubscrptionPlanResponseModel()
                                  {
                                      VehicleId = grp.Key.VehicleId,
                                      LicencePlateNumber = grp.Key.LicencePlateNumber,
                                      MakeName = grp.Key.MakeName,
                                      ModelName = grp.Key.ModelName
                                  }).ToListAsync().ConfigureAwait(false);
                
                int rowcount = 0;
                if (data.Count() > 0)
                {
                    foreach (var item in data)
                    {
                        if (plans != null)
                        {
                            List<PlansResponseModel> planList = (from p in plans
                                                                 join sp in _dbContext.AssignSubscriptions on new { X1 = p.Id, X2 = item.VehicleId, X3 = userId } equals new { X1 = sp.PlanId, X2 = sp.VehicleId, X3 = sp.AspNetUserId } into spp
                                                                 from n in spp.Where(a => a.RenewalDate >= DateTime.UtcNow).OrderBy(x => x.IsPrimary).DefaultIfEmpty()
                                                                 select new PlansResponseModel()
                                                                 {
                                                                     Id = p.Id,
                                                                     Amount = (rowcount > 0 ? Convert.ToDecimal(p.Amount) / 2 : Convert.ToDecimal(p.Amount)),
                                                                     PlanName = p.PlanName,
                                                                     Discount = Convert.ToDecimal(p.Discount),
                                                                     NoOfTransation = p.NoOfTransation,
                                                                     PerStopAmount = Convert.ToDecimal(p.PerStopAmount),
                                                                     SubscriptionDays = p.SubscriptionDays,
                                                                     NumberOfStops = p.NumberOfStops,
                                                                     GasUsage = p.GasUsage,
                                                                     SubscribeDate = (n != null ? n.SubscribeDate : null),
                                                                     RenewalDate = (n != null ? n.RenewalDate : null),
                                                                     IsPlanSelected = (n != null ? n.IsPlanSelected ? n.SubscribeDate < DateTime.UtcNow : false : false),
                                                                 }).ToList();
                            item.Plans = planList;
                            rowcount++;
                        }
                    }
                    response = data;
                }
                

            }
            catch
            {
                throw;
            }
            return response;
        }

        public async Task<CommonResponseModel> AssignBarCode(int VehicleId, string BarCode, int modifiedBy)
        {
            CommonResponseModel response = new();
            try
            {
                var check_vehicleBarcode = (from item in _dbContext.Vehicles where item.BarCode == BarCode select item).FirstOrDefault();

                if (check_vehicleBarcode !=null)
                {
                    response.Data = null;
                    response.Message = "Already assign";
                    response.StatusCode = (int)HttpStatusCode.OK;
                }
                else
                {
                    if (VehicleId > 0)
                    {
                        var c = await (from x in _dbContext.Vehicles
                                       where x.VehicleId == VehicleId
                                       select x).FirstOrDefaultAsync();
                        c.BarCode = BarCode;
                        c.ModifyBy = modifiedBy;
                        _dbContext.SaveChanges();
                        response.Data = null;
                        response.Message = "Saved sucessfully";
                        response.StatusCode = (int)HttpStatusCode.OK;
                    }
                    else
                    {
                        response.Data = null;
                        response.Message = "Failed";
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                    }
                }
            }
            catch
            {
                response.Data = null;
                 response.Message = "Failed";
                response.StatusCode = (int)HttpStatusCode.BadRequest;
            }
            return response;
        }

        public async Task<CustomerDelivery> GetCustomerDeliveryOrders(OrderDetailDto order)
        {
            var customeOrdersDetails = await _dbContext.CustomerDeliveries.Where(x => x.UserId == order.UserId && x.VehicleId == order.VehicleId).FirstOrDefaultAsync();
            return customeOrdersDetails;
        }

        public async Task<AspNetUser> SendCustomerReferralCode(int customerId, string email)
        {
            var restpwd = await _dbContext.AspNetUsers.Where(res => res.Id == customerId).FirstOrDefaultAsync();
            return restpwd;
        }     
    }
}
