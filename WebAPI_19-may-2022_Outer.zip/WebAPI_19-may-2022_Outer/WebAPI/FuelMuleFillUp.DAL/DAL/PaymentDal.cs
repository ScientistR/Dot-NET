﻿using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.DAL.DAL
{
    public class PaymentDal : IPaymentDal
    {

        private readonly FuelMuleFillUpENRGQAContext _dbContext;
 
        public PaymentDal( FuelMuleFillUpENRGQAContext _dbContext)
        {
            this._dbContext = _dbContext;
        }

        public Task<CommonResponseModel> SavePaymentDetails()
        {
            throw new NotImplementedException();
        }
    }
}
