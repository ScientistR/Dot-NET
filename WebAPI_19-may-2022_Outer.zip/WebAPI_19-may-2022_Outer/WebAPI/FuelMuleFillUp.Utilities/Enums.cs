﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Utilities
{
    public class Enums
    {
        public enum WeekDays
        {
            monday = 1,
            tuesday,
            wednesday,
            thursday,
            friday,
            saturday,
            sunday
        }

        public enum Status
        {
            Pending = 1,
            Schedule = 2,
            Delivered = 3
        }
    }
}
