﻿using AutoMapper.Configuration;
using FuelMuleFillUp.Models;
using MailKit.Security;
using Microsoft.AspNetCore.Http;
using MimeKit;
using Nancy.Json;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
//using SmtpClient = MailKit.Net.Smtp.SmtpClient;


namespace FuelMuleFillUp.Utilities
{
    public class UtilityFunction
    {
        //private readonly IConfiguration _config;
        private EmailSettings _mailSettings;
        public UtilityFunction(Microsoft.Extensions.Options.IOptions<EmailSettings> mailSettings)
        {
            _mailSettings = mailSettings.Value;
        }
        /// <summary>
        /// //common seting by karan
        /// </summary>
        public class AppException : Exception
        {
            public AppException() : base() { }

            public AppException(string message) : base(message) { }

            public AppException(string message, params object[] args)
                : base(String.Format(CultureInfo.CurrentCulture, message, args))
            {
            }
        }

        public UtilityFunction()
        {

        }
        public void SendEmailAsync(EmailInfo emailInfo, EmailSettings emailSettings)
        {

            try
            {
                _mailSettings = emailSettings;
                string to = emailInfo.EmailTo; //To address    
                string from = _mailSettings.Email; //From address    
                MailMessage message = new MailMessage(from, to);
                //Attachment attachment = AttachmentHelper.CreateAttachment("D:/Excel/OrderDetails.xlsx", "First Excel", TransferEncoding.Base64);
                //emailInfo.Attachments.Add(attachment);
                string mailbody = emailInfo.Body;
                message.Subject = emailInfo.Subject;
                message.Body = mailbody;
                message.BodyEncoding = Encoding.UTF8;
                message.IsBodyHtml = true;
                //message.Attachments.Add(attachment);
                SmtpClient client = new SmtpClient(_mailSettings.Host, _mailSettings.Port); //Gmail smtp    
                System.Net.NetworkCredential basicCredential1 = new
                System.Net.NetworkCredential(_mailSettings.Email, _mailSettings.Password);
                client.EnableSsl = true;
                client.UseDefaultCredentials = false;
                client.Credentials = basicCredential1;
                try
                {
                    client.Send(message);
                }

                catch (Exception)
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //public static void SendNotification(string deviceToken, string UserId, int CommentId, string userName, string message, string type)
        //{
        //    try
        //    {
        //        RemoteMessage req = new RemoteMessage()
        //        {
        //            To = deviceToken,
        //            Notification = new NotificationModel()
        //            {
        //                //body = userName + " "+ message, //reciverDetails.FullName + "User this commented on your product.", 
        //                body = message, //reciverDetails.FullName + "User this commented on your product.", 
        //                title = "FuelMuleFillUp-ENRG",
        //                Priority = "high",
        //                ContentAvailable = true
        //            },
        //            Data = new Data()
        //            {
        //                ContentAvailable = true,
        //                Id = CommentId,
        //                UserId = UserId,
        //                Type = type
        //            }
        //        };
        //        var task = Task.Run(async () => await SendPushNotification.SendMessageNotification(req).ConfigureAwait(false));
        //    }
        //    catch (Exception)
        //    {
        //        // _logger.LogError(ex.Message);
        //        throw;
        //    }
        //}
        //public static class SendPushNotification
        //{
        //    public static async Task<NotificationResponseModel> SendNotification(NotificationRequestModel notificationRequest)
        //    {
        //        try
        //        {
        //            NotificationResponseModel notificationResponse = new NotificationResponseModel();
        //            string apiResponse = string.Empty;
        //            using (var httpClientHandler = new HttpClientHandler())
        //            {
        //                using (HttpClient httpClient = new HttpClient())
        //                {
        //                    string payLoad = JsonConvert.SerializeObject(notificationRequest);
        //                    using HttpContent inputContent = new StringContent(payLoad, Encoding.UTF8, "application/json");
        //                    //httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAAEtucAfg:APA91bFbwOKKoMo6gioBkAC2VgdebJ51vBhEKdmgDcRLbNE4RtkiaiklLCDF0tgibasaACwDeXvL4zEr7BtGji0qw2NjHEFvpBzKqzipOcdiMqLsnmbULh9j-DdCX3wii30S47nTycS_");
        //                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAARYEJ8kw:APA91bFXc7b781AY-7z6m3XdpzJav_kGd1OQj8gvLhEqCferYTzz0-yiWYHwx0N2HUpOlwtVTvHPujZhowUoOJlDZVC8mV_w9kc8FBWAmffqnyjmR7U4RvnSvHphEdQIgwRxM-fYjuEd");
        //                    var response = await httpClient.PostAsync(new Uri("https://fcm.googleapis.com/fcm/send"), inputContent).ConfigureAwait(false);
        //                    if (response.StatusCode == HttpStatusCode.OK)
        //                    {
        //                        apiResponse = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
        //                        notificationResponse = JsonConvert.DeserializeObject<NotificationResponseModel>(apiResponse);
        //                        return notificationResponse;
        //                    }
        //                    else
        //                    {
        //                        return notificationResponse;
        //                    }
        //                }
        //            }
        //        }
        //        catch
        //        {
        //            //_logger.LogError(ex.Message);
        //            throw;
        //        }
        //    }

        //    public static async Task<NotificationResponseModel> SendMessageNotification(RemoteMessage notificationRequest)
        //    {
        //        try
        //        {
        //            NotificationResponseModel notificationResponse = new NotificationResponseModel();
        //            string apiResponse = string.Empty;
        //            using (var httpClientHandler = new HttpClientHandler())
        //            {
        //                using (HttpClient httpClient = new HttpClient())
        //                {
        //                    string payLoad = JsonConvert.SerializeObject(notificationRequest);
        //                    HttpContent inputContent = new StringContent(payLoad, Encoding.UTF8, "application/json");
        //                    // httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAAEtucAfg:APA91bFbwOKKoMo6gioBkAC2VgdebJ51vBhEKdmgDcRLbNE4RtkiaiklLCDF0tgibasaACwDeXvL4zEr7BtGji0qw2NjHEFvpBzKqzipOcdiMqLsnmbULh9j-DdCX3wii30S47nTycS_");
        //                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Key", "=AAAARYEJ8kw:APA91bFXc7b781AY-7z6m3XdpzJav_kGd1OQj8gvLhEqCferYTzz0-yiWYHwx0N2HUpOlwtVTvHPujZhowUoOJlDZVC8mV_w9kc8FBWAmffqnyjmR7U4RvnSvHphEdQIgwRxM-fYjuEd");
        //                    var response = await httpClient.PostAsync(new Uri("https://fcm.googleapis.com/fcm/send"), inputContent).ConfigureAwait(false);
        //                    if (response.StatusCode == HttpStatusCode.OK)
        //                    {
        //                        apiResponse = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
        //                        notificationResponse = JsonConvert.DeserializeObject<NotificationResponseModel>(apiResponse);
        //                        return notificationResponse;
        //                    }
        //                    else
        //                    {
        //                        return notificationResponse;
        //                    }
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            //_logger.LogError(ex.Message);
        //            throw;
        //        }
        //    }

        //    public static string SendNotificationNew(string DeviceToken, string titleName, string msg)
        //    {
        //        // var serverKey = "AAAAEtucAfg:APA91bFbwOKKoMo6gioBkAC2VgdebJ51vBhEKdmgDcRLbNE4RtkiaiklLCDF0tgibasaACwDeXvL4zEr7BtGji0qw2NjHEFvpBzKqzipOcdiMqLsnmbULh9j-DdCX3wii30S47nTycS_";
        //        var serverKey = "AAAARYEJ8kw:APA91bFXc7b781AY-7z6m3XdpzJav_kGd1OQj8gvLhEqCferYTzz0-yiWYHwx0N2HUpOlwtVTvHPujZhowUoOJlDZVC8mV_w9kc8FBWAmffqnyjmR7U4RvnSvHphEdQIgwRxM-fYjuEd";
        //        var senderId = "80993845752";
        //        var webAddr = "https://fcm.googleapis.com/fcm/send";
        //        var result = "-1";
        //        var httpWebRequest = (HttpWebRequest)WebRequest.Create(webAddr);
        //        httpWebRequest.ContentType = "application/json";
        //        httpWebRequest.Headers.Add(string.Format("Authorization: key={0}", serverKey));
        //        httpWebRequest.Headers.Add(string.Format("Sender: id={0}", senderId));
        //        httpWebRequest.Method = "POST";
        //        string[] str = msg.Split(":", StringSplitOptions.None);
        //        string bodyMsg = string.Empty;
        //        if (str.Length > 1)
        //        {
        //            bodyMsg = str[0] + "\n" + str[1];
        //        }
        //        else
        //        {
        //            bodyMsg = str[0];
        //        }

        //        var payload = new
        //        {
        //            to = DeviceToken,
        //            priority = "high",
        //            content_available = true,
        //            notification = new
        //            {
        //                body = bodyMsg,
        //                title = titleName
        //            },
        //        };
        //        var serializer = new JavaScriptSerializer();
        //        using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
        //        {
        //            string json = serializer.Serialize(payload);
        //            streamWriter.Write(json);
        //            streamWriter.Flush();
        //        }
        //        var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
        //        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
        //        {
        //            result = streamReader.ReadToEnd();
        //        }
        //        return result;
        //    }
        //}


        public void SendEmailAsync1(EmailInfo emailInfo, EmailSettings emailSettings)
        {
            try
            {
                _mailSettings = emailSettings;
                string to = emailInfo.EmailTo; //To address    
                string from = _mailSettings.Email; //From address    
                MailMessage message = new MailMessage(from, to);
                string mailbody = emailInfo.Body;
                message.Subject = emailInfo.Subject;
                message.Body = mailbody;
                message.BodyEncoding = Encoding.UTF8;
                message.IsBodyHtml = true;
                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment("E:/Excel/AcceptedDeliveries.xlsx");
                message.Attachments.Add(attachment);
                SmtpClient client = new SmtpClient(_mailSettings.Host, _mailSettings.Port);  
                System.Net.NetworkCredential basicCredential1 = new
                System.Net.NetworkCredential(_mailSettings.Email, _mailSettings.Password);
                client.EnableSsl = true;
                client.UseDefaultCredentials = false;
                client.Credentials = basicCredential1;
                try
                {
                    client.Send(message);
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void SendEmailAsync2(EmailInfo emailInfo, EmailSettings emailSettings)
        {
            try
            {
                _mailSettings = emailSettings;
                string to = emailInfo.EmailTo; //To address    
                string from = _mailSettings.Email; //From address    
                MailMessage message = new MailMessage(from, to);
                string mailbody = emailInfo.Body;
                message.Subject = emailInfo.Subject;
                message.Body = mailbody;
                message.BodyEncoding = Encoding.UTF8;
                message.IsBodyHtml = true;
                System.Net.Mail.Attachment attachment; 
                attachment = new System.Net.Mail.Attachment("E:/PaymentList/CustomerPaymentList.xlsx");
                message.Attachments.Add(attachment);
                SmtpClient client = new SmtpClient(_mailSettings.Host, _mailSettings.Port); //Gmail smtp    
                System.Net.NetworkCredential basicCredential1 = new
                System.Net.NetworkCredential(_mailSettings.Email, _mailSettings.Password);
                client.EnableSsl = true;
                client.UseDefaultCredentials = false;
                client.Credentials = basicCredential1;
                try
                {
                    client.Send(message);
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<CommonResponseModel> ResponseMessage(bool result, object data)
        {
            CommonResponseModel response = new();
            if (result)
            {
                response.Data = data;
                response.Message = "Saved successfully";//TKMessages.Alreadyexists;
                response.StatusCode = (int)HttpStatusCode.OK;
            }
            else
            {
                response.Data = null;
                response.Message = "Failed";//TKMessages.Alreadyexists;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
            }

            return response;
               
        }

        public async Task<CommonResponseModel> DuplicateResponse(bool result)
        {
            CommonResponseModel response = new();
            if (result)
            {
                response.Data = null;
                response.Message = "Already Exists";//TKMessages.Alreadyexists;
                response.StatusCode = (int)HttpStatusCode.OK;
            }
            else
            {
                response.Data = null;
                response.Message = "Failed";//TKMessages.Alreadyexists;
                response.StatusCode = (int)HttpStatusCode.BadRequest;
            }

            return response;

        }

        public void SendCustomerReferralCode(EmailInfo emailInfo, EmailSettings emailSettings, string referral = null, string username = null)
        {
            try
            {
                _mailSettings = emailSettings;
                string to = emailInfo.EmailTo; //To address    
                string from = _mailSettings.Email; //From address    
                MailMessage message = new MailMessage(from, to);
                string body = string.Empty;
                var path = Path.Combine("wwwroot", "EmailTemplate", "ReferralCodeTemplate.html");
                using (StreamReader reader = new StreamReader(path))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("#referralcode", referral);
                body = body.Replace("#UserName", username);
                // body = body.Replace("#UserName", username);
                //body=  body.Replace("#referral"),referral);
                string mailbody = emailInfo.Body;
                message.Subject = emailInfo.Subject;
                message.Body = body;
                message.BodyEncoding = Encoding.UTF8;
                message.IsBodyHtml = true;
                //message.Attachments.Add(attachment);
                SmtpClient client = new SmtpClient(_mailSettings.Host, _mailSettings.Port); //Gmail smtp    
                System.Net.NetworkCredential basicCredential1 = new
                System.Net.NetworkCredential(_mailSettings.Email, _mailSettings.Password);
                client.EnableSsl = true;
                client.UseDefaultCredentials = false;
                client.Credentials = basicCredential1;
                try
                {
                    client.Send(message);
                }

                catch 
                {
                    throw;
                }
            }
            catch 
            {
                throw;
            }
        }



    }
}