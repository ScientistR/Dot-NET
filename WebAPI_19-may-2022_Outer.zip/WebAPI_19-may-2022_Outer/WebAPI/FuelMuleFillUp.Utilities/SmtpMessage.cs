﻿using FuelMuleFillUp.BAL.IRepository;
using MailKit.Security;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using MimeKit;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Utilities
{
   public class SmtpMessage: IMessage
	{

		private string _body;
		private bool _bodyIsHtml;
		private bool _isAttachemnt;
		private string _fromEmail;
		private string _fromName;
		private string _password;
		private string _userName;
		private BAL.IRepository.MessagePriority _priority;
		private string _replyToEmail;
		private string _replyToName;
		private string _subject;
		private List<Recipient> _recipients;
		private List<Attachments> _attachments;
		private List<Recipient> _ccRecipients;
		private List<Recipient> _bccRecipients;
		private IConfiguration _config;
		private string _smtpServer;
		private int _smtpServerPort;
		private readonly IHostingEnvironment _hostingEnvironment;

		public SmtpMessage(IConfiguration config, IHostingEnvironment hostingEnvironment)
		{
			_config = config;
			_smtpServer = _config["EmailConfiguration:ServerAddress"];
			Int32.TryParse(_config["EmailConfiguration:ServerPort"], out _smtpServerPort);
			_body = "";
			_fromEmail = _config["EmailConfiguration:From"];
			_fromName = _config["EmailConfiguration:FromName"];
			_replyToEmail = "";
			_replyToName = "";
			_subject = "";
			_recipients = new List<Recipient>();
			_ccRecipients = new List<Recipient>();
			_bccRecipients = new List<Recipient>();
			_password = _config["EmailConfiguration:Password"];
			_userName = _config["EmailConfiguration:UserName"];
			_hostingEnvironment = hostingEnvironment;
			_attachments = new List<Attachments>();
			_config = config;
			_smtpServer = _config["EmailConfiguration:ServerAddress"];
			Int32.TryParse(_config["EmailConfiguration:ServerPort"], out _smtpServerPort);
			_body = "";
			_fromEmail = _config["EmailConfiguration:From"];
			_fromName = _config["EmailConfiguration:FromName"];
			_priority = BAL.IRepository.MessagePriority.Normal;
			_replyToEmail = "";
			_replyToName = "";
			_subject = "";
			_recipients = new List<Recipient>();
			_ccRecipients = new List<Recipient>();
			_bccRecipients = new List<Recipient>();
			_password = _config["MailSettings:Password"];
			_userName = _config["MailSettings:UserName"];
			_hostingEnvironment = hostingEnvironment;
			_attachments = new List<Attachments>();
		}

		public SmtpMessage()
		{
		}

		public string Body
		{
			get
			{
				return _body;
			}
			set
			{
				_body = value;
			}
		}

		public bool BodyIsHtml
		{
			get
			{
				return _bodyIsHtml;
			}

			set
			{
				_bodyIsHtml = value;
			}
		}


		public bool isAttachemnt
		{
			get
			{
				return _isAttachemnt;
			}

			set
			{
				_isAttachemnt = value;
			}
		}

		public string FromEmail
		{
			get
			{
				return _fromEmail;
			}

			set
			{
				_fromEmail = value;
			}
		}

		public string FromName
		{
			get
			{
				return _fromName;
			}

			set
			{
				_fromName = value;
			}
		}

		public BAL.IRepository.MessagePriority Priority
		{
			get
			{
				return _priority;
			}

			set
			{
				_priority = value;
			}
		}

		public string ReplyToEmail
		{
			get
			{
				return _replyToEmail;
			}

			set
			{
				_replyToEmail = value;
			}
		}

		public string ReplyToName
		{
			get
			{
				return _replyToName;
			}

			set
			{
				_replyToName = value;
			}
		}

		public string Subject
		{
			get
			{
				return _subject;
			}

			set
			{
				_subject = value;
			}
		}

		public IEnumerable<Recipient> Recipients
		{
			get
			{
				return _recipients;
			}
		}

		public IEnumerable<Recipient> CCRecipients
		{
			get
			{
				return _ccRecipients;
			}
		}

		public IEnumerable<Recipient> BCCRecipients
		{
			get
			{
				return _bccRecipients;
			}
		}

        BAL.IRepository.MessagePriority IMessage.Priority
		{
			get
			{
				throw new NotImplementedException();
			}

			set
			{
				throw new NotImplementedException();
			}
		}

		public void AddBCCRecipient(string fullName, string emailAddress)
		{
			_bccRecipients.Add(new Recipient(fullName, emailAddress));
		}

		public void AddCCRecipient(string fullName, string emailAddress)
		{
			_ccRecipients.Add(new Recipient(fullName, emailAddress));
		}

		public void AddRecipient(string fullName, string emailAddress)
		{
			_recipients.Add(new Recipient(fullName, emailAddress));
		}

		public void RemoveAllRecipaints()
		{
			try
			{
				if (_recipients.Count > 0)
				{
					_recipients = new List<Recipient>();
				}
			}
			catch (Exception)
			{
				throw;
			}
		}


		public void RemoveAllAttachments()
		{
			try
			{
				if (_attachments.Count > 0)
				{
					_attachments = new List<Attachments>();
				}
			}
			catch
			{
				throw;
			}

		}
		public async Task<bool> Send()
		{
			try
			{
				var mimeMessage = new MimeMessage();
				mimeMessage.From.Add(new MailboxAddress(_fromName, _fromEmail));

				foreach (Recipient rec in _recipients)
				{
					mimeMessage.To.Add(new MailboxAddress(rec.FullName, rec.Email));
				}

				foreach (Recipient rec in _ccRecipients)
				{
					mimeMessage.Cc.Add(new MailboxAddress(rec.FullName, rec.Email));
				}

				foreach (Recipient rec in _bccRecipients)
				{
					mimeMessage.Bcc.Add(new MailboxAddress(rec.FullName, rec.Email));
				}

				mimeMessage.Subject = _subject;




				if (_isAttachemnt)
				{
					foreach (var rec in _attachments)
					{
						var multipart = new Multipart("mixed");
						multipart.Add(new TextPart("plain") { Text = _body });

						// create an image attachment for the file located at path
						var attachment = new MimePart("image", "gif")
						{
#pragma warning disable CS0618 // 'MimePart.ContentObject' is obsolete: 'Use the Content property instead.'
#pragma warning disable CS0618 // 'ContentObject' is obsolete: 'Use the MimeContent class instead.'
#pragma warning disable CS0618 // 'ContentObject.ContentObject(Stream, ContentEncoding)' is obsolete: 'Use the MimeContent class instead.'
							ContentObject = new ContentObject(File.OpenRead(rec.FilePath), ContentEncoding.Default),
#pragma warning restore CS0618 // 'ContentObject.ContentObject(Stream, ContentEncoding)' is obsolete: 'Use the MimeContent class instead.'
#pragma warning restore CS0618 // 'ContentObject' is obsolete: 'Use the MimeContent class instead.'
#pragma warning restore CS0618 // 'MimePart.ContentObject' is obsolete: 'Use the Content property instead.'
							ContentDisposition = new MimeKit.ContentDisposition(MimeKit.ContentDisposition.Attachment),
							ContentTransferEncoding = ContentEncoding.Base64,
							FileName = rec.FileName,

						};
						multipart.Add(attachment);
						mimeMessage.Body = multipart;
					}
				}
				else
				{
					if (_bodyIsHtml)
					{
						mimeMessage.Body = new TextPart("html") { Text = _body };
					}
					else
					{
						mimeMessage.Body = new TextPart("plain") { Text = _body };
					}
				}

				using (var smtpClient = new MailKit.Net.Smtp.SmtpClient())
				{

					await smtpClient.ConnectAsync(_smtpServer, _smtpServerPort, SecureSocketOptions.StartTlsWhenAvailable).ConfigureAwait(false);
					smtpClient.Authenticate(_userName, _password);
					await smtpClient.SendAsync(mimeMessage).ConfigureAwait(false);
					await smtpClient.DisconnectAsync(true).ConfigureAwait(false);
				}
				RemoveAllRecipaints();
				RemoveAllAttachments();
				return true;
			}
			catch
			{
				throw;
			}
		}

		public void AddAttachment(Attachments atfile)
		{
			try
			{
				_attachments.Add(atfile);
			}
			catch (Exception)
			{
				throw;
			}
		}
	}
}
