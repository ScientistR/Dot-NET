﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Utilities
{
     public class Helpers
     {
        public static string UploadFile(IFormFile file)
        {
            if ( file.Length == null)   //if (file.Length > 0)
            {
                if (!Directory.Exists(Constants.WWWRootFolderPath))
                {
                    Directory.CreateDirectory(Constants.WWWRootFolderPath);
                }
                string uniqueFileName = Guid.NewGuid() + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "_" + file.FileName;
                var path = Path.Combine(Directory.GetCurrentDirectory(), Constants.WWWRootFolderPath, uniqueFileName);
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                return uniqueFileName;
            }
            else
            {
                return string.Empty;
            }
        }
    }

    public class AppException : Exception
    {
        public AppException() : base() { }

        public AppException(string message) : base(message) { }

        public AppException(string message, params object[] args)
            : base(String.Format(CultureInfo.CurrentCulture, message, args))
        {
        }

       
    }
}
