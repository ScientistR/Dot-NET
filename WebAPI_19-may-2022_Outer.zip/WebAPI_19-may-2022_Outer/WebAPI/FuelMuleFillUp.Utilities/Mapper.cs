﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Utilities
{
   public static class Mapper
    {
        public static T2 MapData<T1, T2>(this T1 source)
        {
            if (source == null)
            {
                throw new InvalidOperationException("Null refence can not map!");
            }
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<T1, T2>();
            });

            var mapper = config.CreateMapper();
            //Mapper.CreateMap<T1, T2>();
            T2 obj = mapper.Map<T1, T2>(source);
            return obj;
        }

        public static List<T2> MapDataList<T1, T2>(this List<T1> source)
        {
            if (source == null)
            {
                throw new InvalidOperationException("Null refence can not map!");
            }
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<T1, T2>();
            });
            var mapper = config.CreateMapper();
            //Mapper.CreateMap<T1, T2>();
            List<T2> objList = mapper.Map<List<T1>, List<T2>>(source);
            return objList;
        }

    }
}
