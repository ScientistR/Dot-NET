﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Utilities
{
   public class Constants
    {
        public const string WWWRootFolderPath = "wwwroot/UploadFile/";


    }
}
