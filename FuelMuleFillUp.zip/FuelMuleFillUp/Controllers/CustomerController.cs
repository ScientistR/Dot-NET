﻿using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Controller
{
    [Route("api/[controller]")]
    [ApiController]
  //  [Authorize]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomer customerBal;
        private readonly IConfiguration _config;

        public CustomerController(ICustomer customerBal, IConfiguration _config)
        {
            this.customerBal = customerBal;
            this._config = _config;
        }

        #region GetVehicles
        [Route("GetVehicles")]
        [HttpGet]
        public async Task<IActionResult> GetVehicles(int? userId, int? vehicleId)
        {
            CommonResponseModel responseModel = await customerBal.GetVehicles(userId, vehicleId);
            return Ok(responseModel);
        }
        #endregion

        #region Add Update Vehicle
        [Route("AddUpdateVehicle")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateVehicle(VehicleDto vehicle)
        {
            CommonResponseModel responseModel = await customerBal.AddUpdateVehicle(vehicle);
            return Ok(responseModel);
        }
        #endregion

        #region Delete Vehicle
        [Route("DeleteVehicle")]
        [HttpPost]
        public async Task<IActionResult> DeleteVehicle(int id, int modifyBy)
        {
            CommonResponseModel responseModel = await customerBal.DeleteVehicle(id, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region Customer Upcoming Deliveries
        [Route("GetCustomerUpcomingDeliveries")]
        [HttpPost]
        public async Task<IActionResult> GetCustomerUpcomingDeliveries(int? customerId)
        {
            CommonResponseModel responseModel = await customerBal.GetCustomerUpcomingDeliveries(customerId);
            return Ok(responseModel);
        }
        #endregion

        #region Customer Deliveries For Date
        [Route("GetCustomerDeliveriesForDate")]
        [HttpGet]
        public async Task<IActionResult> GetCustomerDeliveriesForDate(DateTime deliveryDate, int? userId)
        {
            CommonResponseModel responseModel = await customerBal.GetCustomerDeliveriesForDate(deliveryDate, userId);
            return Ok(responseModel);
        }
        #endregion

        #region Accept CustomerDelivery
        [Route("AcceptCustomerDelivery")]
        [HttpGet]
        public async Task<IActionResult> AcceptCustomerDelivery(int deliveryId, int actionId)
        {

            CommonResponseModel responseModel = await customerBal.AcceptCustomerDelivery(deliveryId, actionId);
            return Ok(responseModel);
        }
        #endregion

        #region Add  OrderDetails
        [Route("AddOrder")]
        [HttpPost]
        public async Task<IActionResult> AddOrder(OrderDetailDto order)
        {
            CommonResponseModel responseModel = await customerBal.AddOrder(order);
            return Ok(responseModel);
        }
        #endregion

        #region Get Customer Past Deliveries
        [Route("GetCustomerPastDeliveries")]
        [HttpGet]
        public async Task<IActionResult> GetCustomerPastDeliveries(int? customerId)
        {

            CommonResponseModel responseModel = await customerBal.GetCustomerPastDeliveries(customerId);
            return Ok(responseModel);
        }
        #endregion

        #region Assign Subscription Plan
        [Route("AssignSubscriptionPlan")]
        [HttpPost]
        public async Task<IActionResult> AssignSubscriptionPlan(int userId, int planId, int vehicleId)
        {
            CommonResponseModel responseModel = await customerBal.AssignSubscriptionPlan(userId, planId, vehicleId);
            return Ok(responseModel);
        }
        #endregion

        #region CancelPlan SubscriptionPlan 
        [Route("CancelPlanSubscriptionPlan")]
        [HttpPost]
        public async Task<IActionResult> CancelPlan(int userId, int vehicleId, int PlanId)
        {
            CommonResponseModel responseModel = await customerBal.CancelPlan(userId, vehicleId, PlanId);
            return Ok(responseModel);
        }
        #endregion

        #region Get Subscription Plan By UserId
        [Route("GetAssignSubscriptionPlanUserId")]
        [HttpGet]
        public async Task<IActionResult> GetAssignSubscriptionPlanUserId(int userId)
        {
            CommonResponseModel responseModel = await customerBal.GetAssignSubscriptionPlanUserId(userId);
            return Ok(responseModel);
        }
        #endregion

        #region ResetPassword

        [Route("ResetPassword")]
        [HttpPost]
        public async Task<IActionResult> ResetPassword(string username, string password, string confirmPassword)
        {
            CommonResponseModel responseModel = await customerBal.ResetPassword(username, password, confirmPassword);
            return Ok(responseModel);
        }
        #endregion

        #region OtpSend
        [Route("OtpSend")]
        [HttpPost]
        public async Task<IActionResult> OtpSend(string username)
        {
            EmailSettings emailSettings = new();
            emailSettings.Email = _config.GetValue<string>("EmailConfiguration:From");
            emailSettings.Password = _config.GetValue<string>("EmailConfiguration:Password");
            emailSettings.Host = _config.GetValue<string>("EmailConfiguration:ServerAddress");
            emailSettings.Port = _config.GetValue<int>("EmailConfiguration:ServerPort");
            CommonResponseModel responseModel = await customerBal.OtpSend(username, emailSettings);
            return Ok(responseModel);
        }
        #endregion

        #region VerifyOtp
        [Route("VerifyOtp")]
        [HttpPost]
        public async Task<IActionResult> VerifyOtp(string username, string otp)
        {
            CommonResponseModel responseModel = new();
            responseModel = await customerBal.VerifyOtp(username, otp);
            return Ok(responseModel);
        }
        #endregion

        #region CustomersSubscriptionPlanList
        [Route("CustomersSubscriptionPlanList")]
        [HttpGet]
        public async Task<IActionResult> CustomersSubscriptionPlanList(int userId)
        {
            CommonResponseModel responseModel = new();
            responseModel = await customerBal.CustomersSubscriptionPlanList(userId);
            return Ok(responseModel);
        }
        #endregion

        #region AssignBarCode
        [Route("AssignBarCode")]
        [HttpPost]
        public async Task<IActionResult> AssignBarCode(int VehicleId, string BarCode, int modifiedBy)
        {
            CommonResponseModel responseModel = new();
            responseModel = await customerBal.AssignBarCode(VehicleId, BarCode, modifiedBy);
            return Ok(responseModel);
        }
        #endregion

        #region Get BarCode License
        [Route("GetBarCodeLicense")]
        [HttpGet]
        public async Task<IActionResult> GetBarCodeLicense(string BarCoderId, string licenseId)
        {
            CommonResponseModel responseModel = await customerBal.GetBarCodeLicense(BarCoderId, licenseId);
            return Ok(responseModel);
        }
        #endregion
       
        #region Get BarCode License
        [Route("SendCustomerReferralCode")]
        [HttpPost]
        public async Task<IActionResult> SendCustomerReferralCode(int customerId, string email)
        {
            CommonResponseModel responseModel = new();
            responseModel = await customerBal.SendCustomerReferralCode(customerId, email);
            return Ok(responseModel);
        }
        #endregion
       
        #region  GenrateExcleSheetForAcceptedCustomer
        [Route("GenrateExcleSheetForAcceptedCustomer")]
        [HttpGet]
        public async Task<IActionResult> GenrateExcleSheetForAcceptedCustomer(DateTime deliveryDate)
        {
            CommonResponseModel responseModel = await customerBal.GenrateExcleSheetForAcceptedCustomer(deliveryDate);
            var emailsend = "sumitk4@chetu.com"; //amareshdesai@yopmail.com
            EmailSettings emailSettings = new();
            emailSettings.Email = _config.GetValue<string>("EmailConfiguration:From");
            emailSettings.Password = _config.GetValue<string>("EmailConfiguration:Password");
            emailSettings.Host = _config.GetValue<string>("EmailConfiguration:ServerAddress");
            emailSettings.Port = _config.GetValue<int>("EmailConfiguration:ServerPort");
            UtilityFunction function = new();
            EmailInfo emailInfo = new();
            emailInfo.EmailTo = emailsend;
            emailInfo.Subject = "Accepted Delivery list for Customers " + deliveryDate.Date;
            emailInfo.Body = "Hi, Please find your accepted delivery list of customers for the date " + deliveryDate.Date;
            function.SendEmailAsync1(emailInfo, emailSettings);
            return Ok(responseModel);
        }
        #endregion
     
        #region  GenrateExcleSheetCustomerPaymentList

        [HttpGet("GenrateExcleSheetCustomerPaymentList")]
        public async Task<IActionResult> GenrateExcleSheetCustomerPaymentList(DateTime From, DateTime To) //DateTime date
        {
            CommonResponseModel responseModel = new();
            responseModel = await customerBal.GenrateExcleSheetCustomerPaymentList(From, To);
            var emailsend = "karnveerk@chetu.com"; //amareshdesai@yopmail.com
            EmailSettings emailSettings = new();
            emailSettings.Email = _config.GetValue<string>("EmailConfiguration:From");
            emailSettings.Password = _config.GetValue<string>("EmailConfiguration:Password");
            emailSettings.Host = _config.GetValue<string>("EmailConfiguration:ServerAddress");
            emailSettings.Port = _config.GetValue<int>("EmailConfiguration:ServerPort");
            UtilityFunction function = new();
            EmailInfo emailInfo = new();
            emailInfo.EmailTo = emailsend;
            emailInfo.Subject = " Completed Customer Payment list for Customers " + From.Date + " To " + To.Date;
            emailInfo.Body = "Hi, Please find your list of customers payment for the date " + From.Date + " " + To.Date;
            function.SendEmailAsync2(emailInfo, emailSettings);
            return Ok(responseModel);
        }
        #endregion
    }
}
