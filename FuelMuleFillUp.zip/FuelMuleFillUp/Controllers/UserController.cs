﻿using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.RequestModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Controllers
{
 
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class UserController : ControllerBase
    {
        private readonly IUserBal _repo;
        private readonly IConfiguration config;

        public UserController(IUserBal repo, IConfiguration config)
        {
            _repo = repo;
            this.config = config;
        }
        #region UserRegistration
        [AllowAnonymous]
        [Route("UserRegistration")]
        [HttpPost]
        public async Task<IActionResult> UserRegistration(UserDto user)
        {
            CommonResponseModel responseModel = await _repo.UserRegistration(user);
            return Ok(responseModel);
        }
        #endregion
    
        #region Update User
        [AllowAnonymous]
        [Route("UpdateUser")]
        [HttpPost]
        public async Task<IActionResult> UpdateUser(UserUpdateRequestModel user)
        {
            CommonResponseModel responseModel = await _repo.UpdateUser(user);
            return Ok(responseModel);
        }
        #endregion


        #region GetCustomer
        [Route("GetCustomer")]
        [HttpGet]
       
        public async Task<IActionResult> GetCustomer(int? userId)
        {
            CommonResponseModel responseModel = await _repo.GetUsers("Customer", userId);
            return Ok(responseModel);
        }
        #endregion
        

        #region Get Roles
        [Route("GetRoles")]
        [HttpGet]
        public async Task<IActionResult> GetRoles(int? id)
        {
            CommonResponseModel responseModel = await _repo.GetRoles(id);
            return Ok(responseModel);
        }
        #endregion

        #region UserLogin
        [AllowAnonymous]
        [Route("UserLogin")]
        [HttpPost]
        public async Task<IActionResult> UserLogin(string email, string password, string deviceToken, string deviceId)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]));
            CommonResponseModel responseModel = await _repo.UserLogin(email, password, deviceToken, deviceId, securityKey);
            return Ok(responseModel);
        }
        #endregion

        #region Delete Employee 
        [Route("DeleteEmployee")]
        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(int userId)
        {
            CommonResponseModel responseModel = await _repo.DeleteEmployee(userId);
            return Ok(responseModel);
        }
        #endregion


    }
}
