﻿using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Controller
{
    [Route("api/[controller]")]
    [ApiController]
   // [Authorize]
    public class PaymentController : ControllerBase
    {
        private readonly IPayment _repo;
        public PaymentController(IPayment repo)
        {
            _repo = repo;
        }
        #region Create Authorize Customer Profile
        [Route("CreateCustomerPaymentProfile")]
        [HttpPost]
        public async Task<IActionResult> CreateCustomerPaymentProfile(AuthorizePayment payment)
        {
            CommonResponseModel responseModel = await _repo.CreateCustomerPaymentProfile(payment);
            return Ok(responseModel);
        }
        #endregion
       
        #region   Get Customer Card Details
        [Route("GetCustomerCardDetails")]
        [HttpGet]
      
        public async Task<IActionResult> GetCustomerCardDetails(int customerId)
        {
            CommonResponseModel responseModel = await _repo.GetCustomerCardDetails(customerId);
            return Ok(responseModel);
        }
        #endregion

        #region  Addcard 

        [Route("AddNewCard")]
        [HttpPost]
     
        public async Task<IActionResult> AddNewCard(AddCustomerCardDetails model)
        {
            CommonResponseModel responseModel = new();
            responseModel = await _repo.AddNewCard(model);
            return Ok(responseModel);
        }
        #endregion
       
        #region   GetCustomerProfile
        [Route("PaymentDetailsByCardId")]
        [HttpPost]
       
        public async Task<IActionResult> CustomerPayment(CustomerPayment model)
        {
            CommonResponseModel responseModel = new();
            responseModel = await _repo.CustomerPayment(model);
            return Ok(responseModel);
        }
        #endregion
       
        #region   DeleteCustomerProfile
        [Route("DeleteCustomerCard")]
        [HttpPost]
        public async Task<IActionResult> DeleteCustomerCard(DeleteCustomerCard customerCard)
        {
            CommonResponseModel responseModel = new();
            responseModel = await _repo.DeleteCustomerCard(customerCard);
            return Ok(responseModel);
        }
        #endregion
    }

}

