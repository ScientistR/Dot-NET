﻿using FuelMuleFillUp.BAL.IRepository;
using FuelMuleFillUp.DAL.IDAL;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models;
using FuelMuleFillUp.Models.Models;
using FuelMuleFillUp.Models.RequestModel;
using FuelMuleFillUp.Models.ResponseModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FuelMuleFillUp.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class AdminController : ControllerBase
    {
        private readonly IAdmin _repo;
        public AdminController(IAdmin repo)
        {
            _repo = repo;
        }
      
        #region GetEmployees
        [Route("GetEmployees")]
        [HttpGet]
        
        public async Task<IActionResult> GetEmployees(int? userId)
        {
            CommonResponseModel responseModel = await _repo.GetEmployees("Customer", userId);
            return Ok(responseModel);
        }
        #endregion
    
        #region GetRoutes
        [Route("GetRoutes")]
        [HttpGet]
      
        public async Task<IActionResult> GetRoutes(int? id)
        {
            CommonResponseModel responseModel = await _repo.GetRoutes(id);
            return Ok(responseModel);
        }
        #endregion

        #region Add Update Route
        [Route("AddUpdateRoute")]
        [HttpPost]
       
        public async Task<IActionResult> AddUpdateRoute(RouteDetailDto route)
        {
            CommonResponseModel responseModel = await _repo.AddUpdateRoute(route);
            return Ok(responseModel);
        }
        #endregion

        #region Delete Route
        [Route("DeleteRoute")]
        [HttpPost]
        public async Task<IActionResult> DeleteRoute(int id, int modifyBy)
        {
            CommonResponseModel responseModel = await _repo.DeleteRoute(id, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region Add Update Product
        [Route("AddUpdateProduct")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateProduct(ProductDto product)
        {
            CommonResponseModel responseModel = await _repo.AddUpdateProduct(product);
            return Ok(responseModel);
        }
        #endregion

        #region Delete Product
        [Route("DeleteProduct")]
        [HttpPost]
        public async Task<IActionResult> DeleteProduct(int id,int modifyBy)
        {
            CommonResponseModel responseModel = await _repo.DeleteProduct(id, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region Get Product
        [Route("GetProduct")]
        [HttpGet]
        public async Task<IActionResult> GetProduct(int ProductId)
        {
            CommonResponseModel responseModel = await _repo.GetProduct(ProductId);
            return Ok(responseModel);
        }
        #endregion

        #region Get Faqs
        [Route("GetFaqs")]
        [HttpGet]
       
        public async Task<IActionResult> GetFaqs(int? faqId)
        {
            CommonResponseModel responseModel = await _repo.GetFaqs(faqId);
            return Ok(responseModel);
        }
        #endregion
        
        #region Save Faqs
        [Route("SaveFaqs")]
        [HttpPost]
        public async Task<IActionResult> SaveFaqs(List<FaqResponseModel> faqs)
        {
            CommonResponseModel responseModel = await _repo.SaveFaq(faqs);
            return Ok(responseModel);
        }
        #endregion

        #region GetTruck
        [Route("GetTruck")]
        [HttpGet]
        public async Task<IActionResult> GetTruck(int? truckId)
        {
            CommonResponseModel responseModel = await _repo.GetTruck(truckId);
            return Ok(responseModel);
        }
        #endregion

        #region  AddUpdateTruck
        [Route("AddUpdateTruck")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateTruck(TruckDto truck)
        {
            CommonResponseModel responseModel = await _repo.AddUpdateTruck(truck);
            return Ok(responseModel);
        }
        #endregion

        #region  GetZipCode
        [Route("GetZipCode")]
        [HttpGet]
        public async Task<IActionResult> GetZip(int? zip)
        {
            CommonResponseModel responseModel = await _repo.GetZip(zip);
            return Ok(responseModel); 
        }
        #endregion

        #region  AddUpdateZipCode
        [Route("AddUpdateZipCode")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateZipCode(ZipDto zip)
        {
            CommonResponseModel responseModel = await _repo.AddUpdateZipCode(zip);
            return Ok(responseModel);
        }
        #endregion

        #region  Delete ZipCode
        [Route("DeleteZipCode")]
        [HttpPost]
        public async Task<IActionResult> DeleteZipCode(int zip, int modifyBy)
        {
            CommonResponseModel responseModel = await _repo.DeleteZipCode(zip, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region  AddUpdate Subcription
        [Route("AddUpdateSubscription")]
        [HttpPost]
       
        public async Task<IActionResult> AddUpdateSubscription(SubscriptionPlanDto subscription)
        {
            CommonResponseModel responseModel = await _repo.AddUpdateSubscription(subscription);
            return Ok(responseModel);
        }
        #endregion

        #region Get Subcription
        [Route("GetSubscription")]
        [HttpGet]
       
        public async Task<IActionResult> GetSubscription(int? subscriptionPlanId, int? customerId)
        {
            CommonResponseModel responseModel = await _repo.GetSubscription(subscriptionPlanId, customerId);
            return Ok(responseModel);
        }
        #endregion

        #region Assign RouteCustomer
        [Route("AssignRouteCustomer")]
        [HttpPost]
        public async Task<IActionResult> AssignRouteCustomer(List<AssignRouteDto>  assignRouteDto)
        {
            CommonResponseModel responseModel = await _repo.AssingRouteCustomer(assignRouteDto);
            return Ok(responseModel);
        }
        #endregion

        #region Update Upcoming Deliveries
        [Route("UpcomingDeliveries")]
        [HttpGet]
       
        public async Task<IActionResult> UpcomingDeliveries()
        {
            CommonResponseModel responseModel = await _repo.UpcomingDeliveries();
            return Ok(responseModel);
        }
        #endregion

        #region Delete FAQ
        [Route("DeleteFAQ")]
        [HttpPost]
        public async Task<IActionResult> DeleteFAQ(int faqid, int modifyBy)
        {
            CommonResponseModel responseModel = await _repo.DeleteFAQ(faqid, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region Delete SubscrionPlan
        [Route("DeleteSubscrtionPlan")]
        [HttpPost]
        public async Task<IActionResult> DeleteSubscrtionPlan(int subscriptionPlanId, int modifyBy)
        {
            CommonResponseModel responseModel = await _repo.DeleteSubscrtionPlan(subscriptionPlanId, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region Delete Truck
        [Route("DeleteTruck")]
        [HttpPost]
        public async Task<IActionResult> DeleteTruck(int truckId, int modifyBy)
        {
            CommonResponseModel responseModel = await _repo.DeleteTruck(truckId, modifyBy);
            return Ok(responseModel);
        }
        #endregion

        #region PaymentListDateWise
        [Route("PaymentListDateWise")]
        [HttpGet]
       
        public async Task<IActionResult> PaymentListDateWise(DateTime from, DateTime to)
        {
            CommonResponseModel responseModel = await _repo.PaymentListDateWise(from, to);
            return Ok(responseModel);
        }
        #endregion

        #region  Get States
        [Route("GetStates")]
        [HttpGet]
        public async Task<IActionResult> GetStates(int? stateId)
        {
            CommonResponseModel responseModel = await _repo.GetStates(stateId);
            return Ok(responseModel);
        }
        #endregion

        #region  ZipCodeValidate
        [Route("ZipCodeValidate")]
        [HttpGet]
        public async Task<IActionResult> ZipCodeValidate(string zipCode)
        {
            CommonResponseModel responseModel = await _repo.ZipCodeValidate(zipCode);
            return Ok(responseModel);
        }
        #endregion

        #region  Active Inactive User
        [Route("ActiveInactiveUser")]
        [HttpPost]
        public async Task<IActionResult> ActiveInactiveUser(int userId, bool activeFlag, int modifiedBy)
        {
            CommonResponseModel responseModel = await _repo.ActiveInactiveUser(userId, activeFlag, modifiedBy);
            return Ok(responseModel);
        }
        #endregion


        #region List Customers With Vehicle Details
        [Route("ListCustomersWithVehicleDetails")]
        [HttpGet]
        public async Task<IActionResult> ListCustomersWithVehicleDetails(int customerId)
        {
            CommonResponseModel responseModel = await _repo.ListCustomersWithVehicleDetails(customerId);
            return Ok(responseModel);
        }
        #endregion

    }
}


