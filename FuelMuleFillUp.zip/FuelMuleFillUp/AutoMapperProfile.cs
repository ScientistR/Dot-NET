﻿using AutoMapper;
using FuelMuleFillUp.Entities.Models;
using FuelMuleFillUp.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FuelMuleFillUp
{
    public class AutoMapperProfile : AutoMapper.Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<UserDto, AspNetUser>()
                .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
                .ForMember(x => x.Role, opt => opt.Ignore());

            CreateMap<AspNetUser, UserDto>()
                .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
                .ForMember(x => x.RoleName, opt => opt.MapFrom(y => y.Role.Name));

            CreateMap<RouteDetail, RouteDetailDto>()
                .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
                .ReverseMap();

            CreateMap<Product, ProductDto>()
                .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
                .ReverseMap();
            CreateMap<Vehicle, VehicleDto>()
                .ForMember(x => x.VehicleId, opt => opt.MapFrom(y => y.VehicleId))
                .ForMember(x => x.ProductName, opt => opt.MapFrom(y => y.Product.ProductName))
                .ForMember(x=>x.FuleType,opt=>opt.MapFrom(y=>y.Product.FuelType));
            CreateMap<VehicleDto, Vehicle>()
                .ForMember(x => x.VehicleId, opt => opt.MapFrom(y => y.VehicleId));

            CreateMap<Truck, TruckDto>()
                .ForMember(x => x.TruckId, opt => opt.MapFrom(y => y.TruckId))
                .ReverseMap();
            CreateMap<ZipCode, ZipDto>()
              .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
              .ReverseMap();

            CreateMap<SubscriptionPlan, SubscriptionPlanDto>()
             .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
             .ForMember(x => x.CustomerName, opt => opt.MapFrom(y => y.Customer == null ? null : y.Customer.FirstName + " " + y.Customer.LastName))
             .ForMember(x => x.CustomerId, opt => opt.MapFrom(y => y.CustomerId ?? 0));

            CreateMap<SubscriptionPlanDto, SubscriptionPlan>()
             .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id));

            CreateMap<FuelMuleFillUp.Entities.Models.Payment, PaymentDto>()
            .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
            .ForMember(x => x.CustomerName, opt => opt.MapFrom(y => y.AspNetUser.FirstName + " " + y.AspNetUser.LastName))
            .ForMember(x => x.LicensePlateNumber, opt => opt.MapFrom(y => y.Vehicle.LicencePlateNumber));
           
             CreateMap<PaymentDto, FuelMuleFillUp.Entities.Models.Payment>()
            .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id));

            CreateMap<OrderDetail, OrderDetailDto>()
         .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
         .ReverseMap();
            CreateMap<State, StatesDto>()
       .ForMember(x => x.Id, opt => opt.MapFrom(y => y.Id))
       .ReverseMap();
        }
    }
}
