﻿namespace FuleMuleFillUp
{
    internal interface ICustomerDetails
    {
    }
}